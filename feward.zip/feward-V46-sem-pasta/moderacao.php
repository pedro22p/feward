<?php
/**
 * Filtro simples de conteúdo. Retorna true quando encontra uma palavra
 * bloqueada. A lista pode ser ampliada depois conforme as regras da rede.
 */
function bloquearConteudo(string $texto): bool {
    $texto = mb_strtolower($texto, 'UTF-8');
    $palavras_bloqueadas = [
        'conteudo_bloqueado_exemplo'
    ];

    foreach ($palavras_bloqueadas as $palavra) {
        if ($palavra !== '' && mb_stripos($texto, $palavra) !== false) {
            return true;
        }
    }
    return false;
}
