<?php
require_once "auth.php";

header("Content-Type: application/json; charset=utf-8");

$acao = $_POST["acao"] ?? $_GET["acao"] ?? "";

// confirma que o contato existe e retorna os dados dele, ou encerra com erro
function carregar_contato(PDO $pdo, int $id) {
    $stmt = $pdo->prepare("SELECT id, nome_usuario FROM contas WHERE id = ?");
    $stmt->execute([$id]);
    $contato = $stmt->fetch();
    if (!$contato) {
        http_response_code(404);
        echo json_encode(["erro" => "Contato não encontrado."]);
        exit;
    }
    return $contato;
}

// V30: só dá pra mandar mensagem (texto ou áudio) pra quem eu sigo
function exigir_seguindo(PDO $pdo, array $eu, array $contato) {
    if (!feward_sigo($pdo, (int) $eu["id"], (int) $contato["id"])) {
        http_response_code(403);
        echo json_encode(["erro" => "Você precisa seguir " . $contato["nome_usuario"] . " para enviar mensagem."]);
        exit;
    }
}

switch ($acao) {

    // envia uma nova mensagem
    case "enviar":
        $destinatario_id = (int) ($_POST["destinatario_id"] ?? 0);
        $texto = trim($_POST["conteudo"] ?? "");

        $contato_dest = carregar_contato($pdo, $destinatario_id);

        if ($destinatario_id === (int) $usuario_logado["id"]) {
            http_response_code(400);
            echo json_encode(["erro" => "Você não pode enviar uma mensagem para si mesmo."]);
            exit;
        }

        exigir_seguindo($pdo, $usuario_logado, $contato_dest);

        if ($texto === "") {
            http_response_code(400);
            echo json_encode(["erro" => "Mensagem vazia."]);
            exit;
        }

        $stmt = $pdo->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, conteudo) VALUES (?, ?, ?)");
        $stmt->execute([$usuario_logado["id"], $destinatario_id, $texto]);
        $nova_id = (int) $pdo->lastInsertId(); // antes do DELETE abaixo, que zera o lastInsertId

        // ao enviar, já não estou mais "digitando"
        $pdo->prepare("DELETE FROM digitando WHERE usuario_id = ? AND destinatario_id = ?")
            ->execute([$usuario_logado["id"], $destinatario_id]);

        $stmt = $pdo->prepare("SELECT * FROM mensagens WHERE id = ?");
        $stmt->execute([$nova_id]);
        $msg = $stmt->fetch();

        echo json_encode(["ok" => true, "mensagem" => $msg]);
        break;

    // envia uma mensagem de áudio (gravada no navegador)
    case "enviar_audio":
        $destinatario_id = (int) ($_POST["destinatario_id"] ?? 0);
        $duracao = (int) ($_POST["duracao"] ?? 0);

        $contato_dest = carregar_contato($pdo, $destinatario_id);

        if ($destinatario_id === (int) $usuario_logado["id"]) {
            http_response_code(400);
            echo json_encode(["erro" => "Você não pode enviar uma mensagem para si mesmo."]);
            exit;
        }

        exigir_seguindo($pdo, $usuario_logado, $contato_dest);

        if (empty($_FILES["audio"]) || $_FILES["audio"]["error"] === UPLOAD_ERR_NO_FILE) {
            http_response_code(400);
            echo json_encode(["erro" => "Nenhum áudio recebido."]);
            exit;
        }

        $arquivo = $_FILES["audio"];

        $erros_upload = [
            UPLOAD_ERR_INI_SIZE   => "O áudio excede o limite de upload configurado no servidor.",
            UPLOAD_ERR_FORM_SIZE  => "O áudio excede o limite permitido pelo formulário.",
            UPLOAD_ERR_PARTIAL    => "O upload foi enviado apenas parcialmente. Tente novamente.",
            UPLOAD_ERR_NO_TMP_DIR => "O servidor não encontrou a pasta temporária para o upload.",
            UPLOAD_ERR_CANT_WRITE => "O servidor não conseguiu gravar o arquivo temporário.",
            UPLOAD_ERR_EXTENSION  => "Uma extensão do PHP bloqueou o upload.",
        ];

        if ($arquivo["error"] !== UPLOAD_ERR_OK) {
            http_response_code(400);
            echo json_encode(["erro" => $erros_upload[$arquivo["error"]] ?? "Erro desconhecido ao enviar o áudio."]);
            exit;
        }

        if (!is_uploaded_file($arquivo["tmp_name"])) {
            http_response_code(400);
            echo json_encode(["erro" => "O arquivo recebido pelo servidor não é um upload válido."]);
            exit;
        }

        if ($arquivo["size"] > 10 * 1024 * 1024) {
            http_response_code(400);
            echo json_encode(["erro" => "O áudio deve ter no máximo 10 MB (cerca de alguns minutos de gravação)."]);
            exit;
        }

        $mime = "application/octet-stream";
        if (function_exists("finfo_open")) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo !== false) {
                $mime = finfo_file($finfo, $arquivo["tmp_name"]) ?: $mime;
                finfo_close($finfo);
            }
        }

        $extensoes_por_mime = [
            "audio/webm"      => "webm",
            "video/webm"      => "webm", // alguns navegadores marcam áudio-only como video/webm
            "audio/ogg"       => "ogg",
            "application/ogg" => "ogg",
            "audio/mpeg"      => "mp3",
            "audio/mp4"       => "m4a",
            "audio/x-m4a"     => "m4a",
            "audio/wav"       => "wav",
            "audio/x-wav"     => "wav",
        ];

        if (!isset($extensoes_por_mime[$mime])) {
            http_response_code(400);
            echo json_encode(["erro" => "Formato de áudio não suportado."]);
            exit;
        }

        $dir = __DIR__ . "/uploads/audios";
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
            http_response_code(500);
            echo json_encode(["erro" => "Não foi possível criar a pasta de áudios no servidor."]);
            exit;
        }
        if (!is_writable($dir)) {
            http_response_code(500);
            echo json_encode(["erro" => "A pasta de áudios não permite gravação no servidor."]);
            exit;
        }

        try {
            $nome = "audio_" . (int) $usuario_logado["id"] . "_" . bin2hex(random_bytes(8)) . "." . $extensoes_por_mime[$mime];
        } catch (Throwable $e) {
            $nome = "audio_" . (int) $usuario_logado["id"] . "_" . uniqid("a_", true) . "." . $extensoes_por_mime[$mime];
        }

        $destino = $dir . DIRECTORY_SEPARATOR . $nome;

        if (!move_uploaded_file($arquivo["tmp_name"], $destino)) {
            http_response_code(500);
            echo json_encode(["erro" => "O servidor recebeu o áudio, mas não conseguiu salvá-lo."]);
            exit;
        }

        // se o destinatário já está online agora, a mensagem já nasce "entregue"
        $stmt = $pdo->prepare("SELECT ultimo_acesso FROM contas WHERE id = ?");
        $stmt->execute([$destinatario_id]);
        $ja_online = feward_esta_online($stmt->fetchColumn());

        $stmt = $pdo->prepare("
            INSERT INTO mensagens (remetente_id, destinatario_id, conteudo, tipo, audio, duracao_audio, entregue, entregue_em)
            VALUES (?, ?, '', 'audio', ?, ?, ?, ?)
        ");
        $stmt->execute([
            $usuario_logado["id"],
            $destinatario_id,
            $nome,
            $duracao > 0 ? $duracao : null,
            $ja_online ? 1 : 0,
            $ja_online ? gmdate("Y-m-d H:i:s") : null,
        ]);
        $nova_id = (int) $pdo->lastInsertId(); // antes do DELETE abaixo, que zera o lastInsertId

        $pdo->prepare("DELETE FROM digitando WHERE usuario_id = ? AND destinatario_id = ?")
            ->execute([$usuario_logado["id"], $destinatario_id]);

        $stmt = $pdo->prepare("SELECT * FROM mensagens WHERE id = ?");
        $stmt->execute([$nova_id]);
        $msg = $stmt->fetch();

        echo json_encode(["ok" => true, "mensagem" => $msg]);
        break;

    // busca mensagens novas (id maior que $depois_de) e se o outro está digitando
    case "atualizar":
        $com_id = (int) ($_GET["com"] ?? 0);
        $depois_de = (int) ($_GET["depois_de"] ?? 0);

        $contato = carregar_contato($pdo, $com_id);

        $stmt = $pdo->prepare("
            SELECT * FROM mensagens
            WHERE ((remetente_id = ? AND destinatario_id = ?) OR (remetente_id = ? AND destinatario_id = ?))
              AND (id > ?
                   OR (editada = TRUE AND atualizada_em > (UTC_TIMESTAMP() - INTERVAL 10 SECOND))
                   OR (entregue_em IS NOT NULL AND entregue_em > (UTC_TIMESTAMP() - INTERVAL 10 SECOND))
                   OR (lida_em IS NOT NULL AND lida_em > (UTC_TIMESTAMP() - INTERVAL 10 SECOND)))
            ORDER BY criado_em ASC
        ");
        $stmt->execute([$usuario_logado["id"], $com_id, $com_id, $usuario_logado["id"], $depois_de]);
        $novas = $stmt->fetchAll();

        // marca como lidas (e quando) as que o outro me mandou
        if (empty($usuario_logado["modo_fantasma"])) {
            $pdo->prepare("
                UPDATE mensagens SET lida = TRUE, lida_em = UTC_TIMESTAMP()
                WHERE remetente_id = ? AND destinatario_id = ? AND lida = FALSE
            ")->execute([$com_id, $usuario_logado["id"]]);
        }

        // o outro está digitando pra mim agora? (sinal válido por 4 segundos)
        $stmt = $pdo->prepare("
            SELECT 1 FROM digitando
            WHERE usuario_id = ? AND destinatario_id = ? AND atualizado_em > (UTC_TIMESTAMP() - INTERVAL 4 SECOND)
        ");
        $stmt->execute([$com_id, $usuario_logado["id"]]);
        $digitando = (bool) $stmt->fetch();

        // status online/offline/visto-por-último do contato desta conversa
        $stmt = $pdo->prepare("SELECT ultimo_acesso, modo_fantasma FROM contas WHERE id = ?");
        $stmt->execute([$com_id]);
        $status_contato = feward_status_usuario($stmt->fetch());

        echo json_encode([
            "ok" => true,
            "mensagens" => $novas,
            "digitando" => $digitando,
            "contato_online" => $status_contato["online"],
            "contato_visto" => $status_contato["visto_texto"],
        ]);
        break;

    // avisa que estou digitando para $destinatario_id
    case "digitando":
        $destinatario_id = (int) ($_POST["destinatario_id"] ?? 0);
        carregar_contato($pdo, $destinatario_id);

        if ($destinatario_id === (int) $usuario_logado["id"]) {
            echo json_encode(["ok" => true]);
            break;
        }

        $pdo->prepare("
            INSERT INTO digitando (usuario_id, destinatario_id, atualizado_em) VALUES (?, ?, UTC_TIMESTAMP())
            ON DUPLICATE KEY UPDATE atualizado_em = UTC_TIMESTAMP()
        ")->execute([$usuario_logado["id"], $destinatario_id]);

        echo json_encode(["ok" => true]);
        break;

    // edita o texto de uma mensagem que eu mesmo enviei
    case "editar":
        $mensagem_id = (int) ($_POST["mensagem_id"] ?? 0);
        $novo_texto = trim($_POST["conteudo"] ?? "");

        if ($novo_texto === "") {
            http_response_code(400);
            echo json_encode(["erro" => "Mensagem vazia."]);
            exit;
        }

        $stmt = $pdo->prepare("SELECT id FROM mensagens WHERE id = ? AND remetente_id = ?");
        $stmt->execute([$mensagem_id, $usuario_logado["id"]]);
        if (!$stmt->fetch()) {
            http_response_code(404);
            echo json_encode(["erro" => "Mensagem não encontrada."]);
            exit;
        }

        $pdo->prepare("UPDATE mensagens SET conteudo = ?, editada = TRUE, atualizada_em = UTC_TIMESTAMP() WHERE id = ?")
            ->execute([$novo_texto, $mensagem_id]);

        $stmt = $pdo->prepare("SELECT * FROM mensagens WHERE id = ?");
        $stmt->execute([$mensagem_id]);
        echo json_encode(["ok" => true, "mensagem" => $stmt->fetch()]);
        break;

    // apaga uma mensagem que eu mesmo enviei (só o dono pode apagar)
    case "excluir":
        $mensagem_id = (int) ($_POST["mensagem_id"] ?? 0);

        $stmt = $pdo->prepare("SELECT id FROM mensagens WHERE id = ? AND remetente_id = ?");
        $stmt->execute([$mensagem_id, $usuario_logado["id"]]);
        if (!$stmt->fetch()) {
            http_response_code(404);
            echo json_encode(["erro" => "Mensagem não encontrada."]);
            exit;
        }

        $pdo->prepare("DELETE FROM mensagens WHERE id = ?")->execute([$mensagem_id]);
        echo json_encode(["ok" => true]);
        break;

    default:
        http_response_code(400);
        echo json_encode(["erro" => "Ação inválida."]);
}
