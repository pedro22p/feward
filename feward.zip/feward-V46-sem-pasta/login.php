<?php
// Carrega a conexão com o banco de dados.
require_once "conexao.php";

// Inicia a sessão para poder guardar os dados do usuário conectado.
session_start();

// Se o usuário já estiver conectado, manda direto para a página inicial.
if (isset($_SESSION["usuario_id"])) {
    header("Location: inicio.php");
    exit;
}

// Guarda uma mensagem de erro quando houver algum problema no login.
$erro = "";

// Verifica se o formulário foi enviado usando o método POST.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Pega o e-mail enviado pelo formulário e remove espaços extras.
    $email = trim($_POST["email"] ?? "");

    // Pega a senha enviada pelo formulário.
    $senha = $_POST["senha"] ?? "";

    // Confere se os dois campos foram preenchidos.
    if ($email === "" || $senha === "") {
        $erro = "Preencha todos os campos.";
    } else {

        try {
            // Procura no banco uma conta que tenha o e-mail informado.
            // O "?" evita colocar o e-mail diretamente dentro da consulta SQL.
            $stmt = $pdo->prepare(
                "SELECT id, nome_usuario, email, senha_hash
                 FROM contas
                 WHERE email = ?
                 LIMIT 1"
            );

            // Envia o e-mail para substituir o "?" da consulta.
            $stmt->execute([$email]);

            // Pega os dados da conta encontrada.
            $conta = $stmt->fetch();

            // Confere se a conta existe e se a senha informada corresponde à senha salva.
            if ($conta && isset($conta["senha_hash"]) &&
                password_verify($senha, $conta["senha_hash"])) {

                // Cria um novo ID de sessão depois do login.
                session_regenerate_id(true);

                // Guarda o ID do usuário na sessão.
                $_SESSION["usuario_id"] = $conta["id"];

                // Guarda o nome do usuário na sessão.
                $_SESSION["nome_usuario"] = $conta["nome_usuario"];

                // Login realizado: vai para a página inicial.
                header("Location: inicio.php");
                exit;

            } else {
                // Se o e-mail ou a senha estiverem errados, mostra esta mensagem.
                $erro = "Email ou senha incorretos.";
            }

        } catch (PDOException $e) {
            // Não mostra detalhes do banco para o visitante.
            $erro = "Não foi possível acessar o banco de dados. Verifique a tabela contas.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login do Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Login - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">

    <style>
        * {
            box-sizing: border-box;
        }

        html,
        body {
            width: 100%;
            min-height: 100%;
            margin: 0;
        }

        /* Fundo do Feward com a logo em cima e o cartão de login embaixo. */
        body {
            font-family: Arial, Helvetica, sans-serif;
            background:
                linear-gradient(rgba(5, 8, 35, 0.35), rgba(5, 8, 35, 0.55)),
                url("img/fundo.jpeg") center center / cover no-repeat fixed;
            min-height: 100vh;
            color: #ffffff;
            overflow-x: hidden;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 35px 16px 30px;
        }

        /* Botão "Créditos" no canto superior direito. */
        .creditos {
            position: fixed;
            top: 16px;
            right: 16px;
            z-index: 10;
            background: rgba(39, 44, 121, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.8);
            padding: 11px 16px;
            border-radius: 8px;
            color: #ffffff;
            font-size: 13px;
            cursor: pointer;
            transition: 0.2s ease;
        }

        .creditos:hover {
            background: #ffffff;
            color: #111111;
        }

        .logo {
            width: min(300px, 70vw);
            margin-top: 20px;
            flex-shrink: 0;
            text-align: center;
        }

        .logo img {
            display: block;
            width: 100%;
            height: auto;
            max-height: 180px;
            object-fit: contain;
        }

        /* ===== Cartão de login (design Uiverse by Cksunandh) ===== */
        .login-container {
            background-color: #2f2f2f;
            border-radius: 8px;
            box-shadow: rgb(31 31 31 / 17%) 0px -23px 25px 0px inset,
                rgb(108 108 108 / 23%) 0px -36px 30px 0px inset,
                rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset,
                rgba(0, 0, 0, 0.06) 0px 2px 1px,
                rgba(0, 0, 0, 0.09) 0px 4px 2px,
                rgba(0, 0, 0, 0.09) 0px 8px 4px,
                rgba(0, 0, 0, 0.09) 0px 16px 8px,
                rgba(0, 0, 0, 0.09) 0px 32px 16px;
            padding: 40px;
            max-width: 400px;
            width: 100%;
            text-align: center;
            margin: 35px auto 0;
            flex-shrink: 0;
        }

        .login-form {
            display: flex;
            flex-direction: column;
        }

        .heading {
            color: #ffffff;
            font-weight: 500;
            font-size: 40px;
            margin: 0 0 5px;
        }

        .paragraph {
            color: #ffffff;
            font-weight: 400;
            font-size: 15px;
            margin: 0 0 15px;
        }

        /* Mensagem de erro do login. */
        .erro {
            margin: 0 0 15px;
            padding: 11px 12px;
            background: rgba(255, 70, 70, 0.12);
            border: 1px solid rgba(255, 107, 107, 0.45);
            border-radius: 8px;
            color: #ff8585;
            font-size: 14px;
            text-align: center;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group input {
            background: none;
            border: 1px solid #353535;
            padding: 15px 23px;
            font-size: 16px;
            border-radius: 8px;
            color: #979797;
            width: 100%;
            outline: none;
            box-shadow: rgb(136 136 136 / 17%) 0px -23px 25px 0px inset,
                rgb(81 81 81 / 23%) 0px -36px 30px 0px inset,
                rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset,
                rgba(0, 0, 0, 0.06) 0px 2px 1px,
                rgba(0, 0, 0, 0.09) 0px 4px 2px,
                rgba(0, 0, 0, 0.09) 0px 8px 4px,
                rgba(0, 0, 0, 0.09) 0px 16px 8px,
                rgba(0, 0, 0, 0.09) 0px 32px 16px;
        }

        .input-group input::placeholder {
            color: #979797;
        }

        .input-group input:focus {
            border-color: #0173ed;
            outline: none;
        }

        /* Impede o navegador de pintar o campo de branco ao autopreencher. */
        .input-group input:-webkit-autofill,
        .input-group input:-webkit-autofill:focus {
            -webkit-text-fill-color: #979797;
            caret-color: #979797;
            transition: background-color 9999s ease-in-out 0s;
        }

        .login-form button[type="submit"] {
            padding: 15px;
            border: none;
            border-radius: 8px;
            background-color: #0173ed;
            color: #ffffff;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-form button[type="submit"]:hover {
            background-color: #3f95f2;
        }

        .bottom-text {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
            color: #ffffff;
            font-size: 15px;
            font-weight: 400;
        }

        .bottom-text p {
            margin: 0;
        }

        .bottom-text a {
            color: #0173ed;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .bottom-text a:hover {
            color: #3f95f2;
        }

        .versao {
            margin: 18px 0 0;
            text-align: center;
            color: #979797;
            font-size: 12px;
        }

        @media (max-width: 600px) {
            body {
                background-attachment: scroll;
                padding: 25px 15px;
            }

            .creditos {
                top: 10px;
                right: 10px;
                padding: 9px 12px;
                font-size: 11px;
            }

            .logo {
                width: min(230px, 58vw);
                margin-top: 25px;
            }

            .logo img {
                max-height: 130px;
            }

            .login-container {
                margin-top: 25px;
                padding: 30px 22px;
            }

            .heading {
                font-size: 34px;
            }
        }

        @media (max-height: 700px) and (max-width: 600px) {
            body {
                padding-top: 15px;
            }

            .logo {
                margin-top: 15px;
            }

            .logo img {
                max-height: 95px;
            }

            .login-container {
                margin-top: 18px;
                padding: 22px 20px;
            }

            .input-group {
                margin-bottom: 14px;
            }
        }
    </style>
</head>

<body>

    <button
        class="creditos"
        type="button"
        onclick="window.location.href='cretidos.php'"
        aria-label="Abrir página de créditos"
    >
        Créditos
    </button>

    <div class="logo">
        <img src="img/logo.png" alt="Logo do Feward">
    </div>

    <main class="login-container">
        <form class="login-form" method="POST" action="login.php" autocomplete="on">
            <p class="heading">Login</p>
            <p class="paragraph">Entre na sua conta</p>

            <?php if ($erro): ?>
                <p class="erro" role="alert">
                    <?= htmlspecialchars($erro, ENT_QUOTES, "UTF-8") ?>
                </p>
            <?php endif; ?>

            <div class="input-group">
                <input
                    id="email"
                    type="email"
                    name="email"
                    placeholder="Email"
                    aria-label="Email"
                    autocomplete="email"
                    value="<?= htmlspecialchars($_POST["email"] ?? "", ENT_QUOTES, "UTF-8") ?>"
                    required
                >
            </div>

            <div class="input-group">
                <input
                    id="senha"
                    type="password"
                    name="senha"
                    placeholder="Senha"
                    aria-label="Senha"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button type="submit">Entrar</button>

            <div class="bottom-text">
                <p>Não tem uma conta? <a href="criar_conta.php">Criar conta</a></p>
                <p><a href="esqueci_senha.php">Esqueci minha senha</a></p>
                <p><a href="feedback.php">Enviar feedback</a></p>
            </div>

            <p class="versao">Versão 1.0</p>
        </form>
    </main>

</body>
</html>
