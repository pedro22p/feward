<?php
require_once "auth.php";

// envio via formulário tradicional (funciona mesmo sem JavaScript)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["destinatario_id"], $_POST["conteudo"])) {
    $texto = trim($_POST["conteudo"]);
    $destinatario_id = (int) $_POST["destinatario_id"];
    if ($texto !== "" && $destinatario_id !== (int) $usuario_logado["id"] && feward_sigo($pdo, (int) $usuario_logado["id"], $destinatario_id)) {
        $stmt = $pdo->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, conteudo) VALUES (?, ?, ?)");
        $stmt->execute([$usuario_logado["id"], $destinatario_id, $texto]);
    }
    header("Location: mensagem.php?com=" . $destinatario_id);
    exit;
}

// V30: a lista mostra só quem eu sigo + quem já conversou comigo (pra eu ver o que me mandaram).
$eu_id = (int) $usuario_logado["id"];
$contatos = $pdo->prepare("
    SELECT c.id, c.nome_usuario, c.foto_perfil, c.foto_perfil_pos, c.ultimo_acesso, c.modo_fantasma
    FROM contas c
    WHERE c.id != ?
      AND (EXISTS (SELECT 1 FROM amizades a WHERE a.usuario_id = ? AND a.amigo_id = c.id AND a.status = 'aceito')
           OR EXISTS (SELECT 1 FROM mensagens m WHERE (m.remetente_id = c.id AND m.destinatario_id = ?) OR (m.remetente_id = ? AND m.destinatario_id = c.id)))
    ORDER BY c.nome_usuario
");
$contatos->execute([$eu_id, $eu_id, $eu_id, $eu_id]);
$contatos = $contatos->fetchAll();

// V30: grupos dos quais eu participo
try {
    $meus_grupos = $pdo->prepare("SELECT g.id, g.nome FROM grupos g JOIN grupo_membros gm ON gm.grupo_id = g.id WHERE gm.usuario_id = ? ORDER BY g.nome");
    $meus_grupos->execute([$eu_id]);
    $meus_grupos = $meus_grupos->fetchAll();
} catch (PDOException $e) {
    $meus_grupos = []; // falta rodar grupos_seguir_v30.sql
}

$contato_atual = null;
$conversa = [];

if (!empty($_GET["com"])) {
    $com_id = (int) $_GET["com"];
    $stmt = $pdo->prepare("SELECT id, nome_usuario, foto_perfil, foto_perfil_pos, ultimo_acesso, modo_fantasma FROM contas WHERE id = ?");
    $stmt->execute([$com_id]);
    $contato_atual = $stmt->fetch();

    if ($contato_atual) {
        $stmt = $pdo->prepare("
            SELECT * FROM mensagens
            WHERE (remetente_id = ? AND destinatario_id = ?) OR (remetente_id = ? AND destinatario_id = ?)
            ORDER BY criado_em ASC
        ");
        $stmt->execute([$usuario_logado["id"], $com_id, $com_id, $usuario_logado["id"]]);
        $conversa = $stmt->fetchAll();

        if (empty($usuario_logado["modo_fantasma"])) {
            $stmt = $pdo->prepare("UPDATE mensagens SET lida = TRUE WHERE remetente_id = ? AND destinatario_id = ? AND lida = FALSE");
            $stmt->execute([$com_id, $usuario_logado["id"]]);
        }
    }
}

$posso_enviar = $contato_atual ? feward_sigo($pdo, $eu_id, (int) $contato_atual["id"]) : false;
$bloq = $posso_enviar ? "" : " disabled";

$pagina_ativa = "mensagem";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Mensagens da rede Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Mensagens - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .painel-msg { display: flex; gap: 20px; height: 75vh; }
        .lista-contatos { width: 260px; overflow-y: auto; }
        .contato-item { display: block; padding: 12px 15px; border-radius: 12px; margin-bottom: 8px; background: rgba(255,255,255,0.08); }
        .contato-item.ativo { background: #2844e2; }
        .contato-item { display:flex; align-items:center; gap:10px; text-decoration:none; color:inherit; }
        .avatar-contato { width:34px; height:34px; min-width:34px; border-radius:50%; object-fit:cover; display:inline-flex; align-items:center; justify-content:center; background:#3a3d63; }
        .avatar-fallback { font-size:18px; }
        .titulo-chat { display:flex; align-items:center; gap:10px; }
        .avatar-perfil, .avatar-perfil-link { cursor: pointer; text-decoration: none; }
        .avatar-perfil:hover .avatar-contato, .avatar-perfil-link:hover .avatar-contato { box-shadow: 0 0 0 2px #4bbae6; }
        .janela-chat { flex: 1; display: flex; flex-direction: column; min-height: 0; min-width: 0; }
        .mensagens-lista { flex: 1; min-height: 0; overflow-y: auto; overflow-x: hidden; padding: 10px; scroll-behavior: smooth; -webkit-overflow-scrolling: touch; }
        .bolha { max-width: 60%; padding: 10px 15px; border-radius: 15px; margin-bottom: 10px; overflow-wrap: anywhere; word-break: break-word; }
        .bolha.minha { background: #2844e2; margin-left: auto; }
        .bolha.outra { background: rgba(255,255,255,0.15); }
        .bolha-editada { font-size: 11px; opacity: 0.65; font-style: italic; margin-left: 6px; }
        .bolha-acoes-trigger { background: none; border: none; color: inherit; opacity: 0.55; cursor: pointer; font-size: 14px; line-height: 1; padding: 0 0 0 8px; vertical-align: middle; }
        .bolha-acoes-trigger:hover { opacity: 1; }
        .bolha-acoes { display: none; gap: 12px; margin-top: 6px; }
        .bolha-acoes.aberto { display: flex; }
        .bolha-acoes button, .bolha-editar-botoes button { background: none; border: none; color: inherit; opacity: 0.85; text-decoration: underline; cursor: pointer; padding: 0; font-size: 12px; }
        .bolha-acoes button:hover, .bolha-editar-botoes button:hover { opacity: 1; }
        .bolha-editar-campo { display: block; width: 100%; min-width: 180px; box-sizing: border-box; margin-top: 2px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.25); background: rgba(0,0,0,0.2); color: #fff; padding: 6px 8px; font: inherit; font-size: 14px; line-height: 1.4; resize: vertical; }
        .bolha-editar-botoes { display: flex; gap: 12px; margin-top: 6px; justify-content: flex-end; }
        .form-enviar { display: flex; gap: 10px; margin-top: 10px; }
        .aviso-seguir { flex: 0 0 auto; background: rgba(255,200,0,0.12); border: 1px solid rgba(255,200,0,0.35); color: #ffe08a; border-radius: 10px; padding: 8px 12px; font-size: 13px; margin: 0 0 8px; }
        .aviso-seguir a { color: #4bbae6; }
        .contato-item.grupo-novo { background: rgba(75,186,230,0.18); }
        .digitando-indicador { font-size: 13px; color: #aaa; height: 18px; padding: 0 10px; font-style: italic; }

        /* status online/offline nos contatos e no cabeçalho da conversa */
        .status-ponto { width: 9px; height: 9px; min-width: 9px; border-radius: 50%; background: #777; display: inline-block; }
        .status-ponto.online { background: #3ecf5e; box-shadow: 0 0 6px #3ecf5e; }
        .avatar-wrap { position: relative; display: inline-flex; }
        .avatar-wrap .status-ponto { position: absolute; right: -1px; bottom: -1px; border: 2px solid #1a0000; }
        .status-presenca-chat { font-size: 12px; color: #aaa; font-weight: normal; display: flex; align-items: center; gap: 5px; margin-top: 2px; }
        .status-presenca-chat.online { color: #3ecf5e; }

        /* status enviada/entregue/visualizada nas minhas bolhas */
        .bolha-status { font-size: 11px; opacity: 0.7; margin-left: 6px; letter-spacing: -1px; }
        .bolha-status.visualizada { color: #4bbae6; opacity: 1; }

        /* mensagens de áudio */
        .bolha-audio { display: flex; align-items: center; gap: 8px; }
        .bolha-audio audio { height: 34px; max-width: 220px; }

        /* botão de gravar áudio + UI de gravação em andamento */
        .btn-gravar-audio { background: none; border: none; color: inherit; font-size: 20px; cursor: pointer; padding: 0 4px; opacity: 0.85; }
        .btn-gravar-audio:hover { opacity: 1; }
        .btn-gravar-audio.gravando { color: #ff4d4d; opacity: 1; animation: pulsar-gravacao 1s infinite; }
        @keyframes pulsar-gravacao { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .gravacao-info { display: none; align-items: center; gap: 10px; flex: 1; font-size: 13px; color: #ff8a8a; }
        .gravacao-info.ativo { display: flex; }
        .gravacao-info .btn-cancelar-gravacao { background: none; border: none; color: #aaa; text-decoration: underline; cursor: pointer; font-size: 13px; }

        /* A conversa deve rolar por dentro do chat, nunca empurrar a página no celular. */
        .pagina-mensagens {
            overflow-x: hidden;
        }

        /* Layout mobile: contatos ficam sempre em uma faixa própria e o teclado
           reduz somente a área disponível do aplicativo. */
        @media (max-width: 768px) {
            html, body.pagina-mensagens {
                width: 100%;
                height: 100%;
                overflow: hidden;
                overscroll-behavior: none;
            }

            body.pagina-mensagens {
                height: calc(100dvh - 76px);
                min-height: 0;
                padding-bottom: 76px;
                box-sizing: border-box;
            }

            body.pagina-mensagens .conteudo {
                height: calc(100dvh - 76px);
                min-height: 0;
                box-sizing: border-box;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                padding: 16px;
            }

            body.pagina-mensagens .topo-pagina {
                flex: 0 0 auto;
                margin-bottom: 14px;
            }

            body.pagina-mensagens .painel-msg {
                flex: 1 1 auto;
                height: auto;
                min-height: 0;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                gap: 8px;
            }

            body.pagina-mensagens .lista-contatos {
                flex: 0 0 48px;
                width: 100%;
                height: 48px;
                min-height: 48px;
                max-width: 100%;
                display: flex;
                align-items: center;
                gap: 8px;
                overflow-x: auto;
                overflow-y: hidden;
                padding: 2px 2px 5px;
                box-sizing: border-box;
                -webkit-overflow-scrolling: touch;
                overscroll-behavior-x: contain;
                scrollbar-width: none;
            }

            body.pagina-mensagens .lista-contatos::-webkit-scrollbar {
                display: none;
            }

            body.pagina-mensagens .contato-item {
                flex: 0 0 auto;
                margin: 0;
                padding: 9px 13px;
                border-radius: 20px;
                white-space: nowrap;
                font-size: 14px;
            }

            body.pagina-mensagens .janela-chat {
                flex: 1 1 auto;
                width: 100%;
                min-width: 0;
                min-height: 0;
                height: auto;
                box-sizing: border-box;
                padding: 12px;
                border-radius: 18px;
                overflow: hidden;
                display: flex;
                flex-direction: column;
            }

            body.pagina-mensagens .janela-chat > h3 {
                flex: 0 0 auto;
                margin: 0 0 7px;
                font-size: 17px;
                line-height: 1.3;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }

            body.pagina-mensagens .mensagens-lista {
                flex: 1 1 auto;
                min-width: 0;
                min-height: 0;
                height: auto;
                overflow-y: auto;
                overflow-x: hidden;
                padding: 8px 2px;
                overscroll-behavior: contain;
                touch-action: pan-y;
                -webkit-overflow-scrolling: touch;
            }

            body.pagina-mensagens .bolha {
                max-width: 84%;
                padding: 9px 12px;
                margin-bottom: 8px;
                border-radius: 14px;
                overflow-wrap: anywhere;
                word-break: break-word;
                line-height: 1.35;
            }

            body.pagina-mensagens .digitando-indicador {
                flex: 0 0 18px;
                height: 18px;
                min-height: 18px;
                padding: 0 4px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            body.pagina-mensagens .form-enviar {
                flex: 0 0 52px;
                width: 100%;
                min-width: 0;
                height: 52px;
                gap: 7px;
                margin-top: 6px;
                padding: 0;
                box-sizing: border-box;
                position: relative;
                z-index: 5;
                background: #050014;
            }

            body.pagina-mensagens .form-enviar input {
                flex: 1 1 auto;
                min-width: 0;
                width: 0;
                padding: 11px 13px;
                font-size: 16px;
            }

            body.pagina-mensagens .form-enviar .acao {
                flex: 0 0 46px;
                width: 46px;
                min-width: 46px;
                height: 46px;
                padding: 0;
                border-radius: 50%;
                font-size: 18px;
            }
        }

        @media (max-width: 420px) {
            body.pagina-mensagens .janela-chat {
                padding: 10px;
            }

            body.pagina-mensagens .contato-item {
                padding: 9px 11px;
                font-size: 13px;
            }

            body.pagina-mensagens .bolha {
                max-width: 88%;
            }
        }

        /* ===== CORREÇÃO MOBILE V9: barra de mensagem acima da navegação ===== */
        @media (max-width: 768px) {
            html, body.pagina-mensagens {
                width: 100%;
                overflow-x: hidden;
            }

            body.pagina-mensagens {
                height: auto !important;
                min-height: 100dvh;
                padding-bottom: 86px !important;
                box-sizing: border-box;
                overflow-y: hidden;
            }

            body.pagina-mensagens .conteudo {
                height: auto !important;
                min-height: 0 !important;
                padding: 18px 14px 96px !important;
                box-sizing: border-box;
                overflow: visible !important;
            }

            body.pagina-mensagens .painel-msg {
                height: calc(var(--app-height, 100dvh) - 300px) !important;
                min-height: 300px !important;
                max-height: none !important;
                flex: none !important;
                overflow: hidden !important;
            }

            body.pagina-mensagens .lista-contatos {
                flex: 0 0 48px !important;
                height: 48px !important;
                min-height: 48px !important;
            }

            body.pagina-mensagens .janela-chat {
                flex: 1 1 auto !important;
                min-height: 0 !important;
                overflow: hidden !important;
                padding: 10px !important;
            }

            body.pagina-mensagens .mensagens-lista {
                flex: 1 1 auto !important;
                min-height: 0 !important;
                overflow-y: auto !important;
                overflow-x: hidden !important;
            }

            body.pagina-mensagens .form-enviar {
                flex: 0 0 52px !important;
                height: 52px !important;
                min-height: 52px !important;
                width: 100% !important;
                margin: 6px 0 0 !important;
                padding: 0 !important;
                box-sizing: border-box !important;
                position: relative !important;
                z-index: 100 !important;
            }

            body.pagina-mensagens .form-enviar input {
                min-width: 0 !important;
                width: 0 !important;
                flex: 1 1 auto !important;
            }

            body.pagina-mensagens .form-enviar .acao {
                flex: 0 0 46px !important;
                width: 46px !important;
                min-width: 46px !important;
                height: 46px !important;
            }

            body.pagina-mensagens .bottom-nav {
                z-index: 1000 !important;
            }
        }

        .bolha-reel { display: block; }
        .bolha.bolha-so-reel, body.pagina-mensagens .bolha.bolha-so-reel { background: none !important; padding: 0 !important; box-shadow: none !important; max-width: none !important; }
        .bolha-so-reel .bolha-status { display: block; text-align: right; margin-top: 2px; }
        .reel-cartao { position: relative; display: block; width: 200px; max-width: 70vw; aspect-ratio: 9 / 16; background: #1a1a1a; border-radius: 18px; overflow: hidden; color: #fff; text-decoration: none; }
        .reel-cartao video { width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none; }
        .reel-cartao-topo { position: absolute; top: 0; left: 0; right: 0; display: flex; align-items: center; gap: 8px; padding: 10px; background: linear-gradient(rgba(0,0,0,.55), transparent); }
        .reel-cartao-avatar { width: 28px; height: 28px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
        .reel-cartao-nome { font-size: 13px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; text-shadow: 0 1px 3px #000; }
        .reel-cartao-play { position: absolute; left: 10px; bottom: 10px; width: 30px; height: 30px; border-radius: 8px; background: rgba(0,0,0,.6); display: flex; align-items: center; justify-content: center; font-size: 14px; }
        .reel-cartao-msg { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; text-align: center; padding: 12px; font-size: 13px; color: #bbb; }

        /* V41: seletor de emoji */
        .btn-emoji { background: none; border: none; color: inherit; font-size: 22px; cursor: pointer; padding: 0 4px; opacity: .85; flex: 0 0 auto; }
        .btn-emoji:hover { opacity: 1; }
        .emoji-painel { position: fixed; z-index: 2500; display: none; flex-direction: column; background: #15162b; border: 1px solid rgba(255,255,255,.15); border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,.5); height: 260px; max-width: 420px; }
        .emoji-painel.aberto { display: flex; }
        .emoji-abas { display: flex; gap: 2px; padding: 6px; border-bottom: 1px solid rgba(255,255,255,.1); }
        .emoji-abas button { flex: 1; background: none; border: 0; border-radius: 8px; font-size: 18px; padding: 4px 0; cursor: pointer; opacity: .6; }
        .emoji-abas button.ativa { background: #272a4d; opacity: 1; }
        .emoji-grade { flex: 1; overflow-y: auto; display: grid; grid-template-columns: repeat(8, 1fr); gap: 2px; padding: 8px; align-content: start; }
        .emoji-grade button { background: none; border: 0; font-size: 24px; line-height: 1; padding: 5px 0; border-radius: 8px; cursor: pointer; }
        .emoji-grade button:hover { background: #272a4d; }
    </style>
</head>
<body class="pagina-mensagens">

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Mensagem</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="painel-msg">
        <div class="lista-contatos" id="lista-contatos">
            <a class="contato-item grupo-novo" href="grupo.php?novo=1">➕ <span>Novo grupo</span></a>
            <?php foreach ($meus_grupos as $g): ?>
                <a class="contato-item" href="grupo.php?id=<?= (int) $g["id"] ?>">👥 <span><?= htmlspecialchars($g["nome"]) ?></span></a>
            <?php endforeach; ?>
            <?php foreach ($contatos as $c): ?>
                <?php $status_c = feward_status_usuario($c); ?>
                <a class="contato-item <?= ($contato_atual && $contato_atual["id"] == $c["id"]) ? "ativo" : "" ?>" href="mensagem.php?com=<?= (int)$c["id"] ?>" data-contato-id="<?= (int) $c["id"] ?>">
                    <?php $fotoContato = !empty($c["foto_perfil"]) ? __DIR__ . "/" . ltrim($c["foto_perfil"], "/") : ""; ?>
                    <span class="avatar-wrap avatar-perfil" data-perfil-id="<?= (int)$c["id"] ?>" role="link" title="Ver perfil de <?= htmlspecialchars($c["nome_usuario"]) ?>">
                        <?php if ($fotoContato && is_file($fotoContato)): ?>
                            <img class="avatar-contato" src="avatar.php?id=<?= (int)$c["id"] ?>" alt="" style="object-position: <?= htmlspecialchars($c["foto_perfil_pos"] ?? "50% 50%") ?>;">
                        <?php else: ?>
                            <span class="avatar-contato avatar-fallback">👤</span>
                        <?php endif; ?>
                        <?php if (!$status_c["oculto"]): ?>
                            <span class="status-ponto contato-status-ponto<?= $status_c["online"] ? " online" : "" ?>"></span>
                        <?php endif; ?>
                    </span>
                    <span><?= htmlspecialchars($c["nome_usuario"]) ?></span>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="janela-chat card-escuro">
            <?php if (!$contato_atual): ?>
                <p>Selecione um contato para começar a conversar.</p>
            <?php else: ?>
                <?php $status_atual = feward_status_usuario($contato_atual); ?>
                <h3 class="titulo-chat">
                    <a class="avatar-wrap avatar-perfil-link" href="perfil-usuario.php?id=<?= (int)$contato_atual["id"] ?>" title="Ver perfil de <?= htmlspecialchars($contato_atual["nome_usuario"]) ?>">
                        <?php $fotoAtual = !empty($contato_atual["foto_perfil"]) ? __DIR__ . "/" . ltrim($contato_atual["foto_perfil"], "/") : ""; ?>
                        <?php if ($fotoAtual && is_file($fotoAtual)): ?>
                            <img class="avatar-contato" src="avatar.php?id=<?= (int)$contato_atual["id"] ?>" alt="" style="object-position: <?= htmlspecialchars($contato_atual["foto_perfil_pos"] ?? "50% 50%") ?>;">
                        <?php else: ?>
                            <span class="avatar-contato avatar-fallback">👤</span>
                        <?php endif; ?>
                        <?php if (!$status_atual["oculto"]): ?>
                            <span class="status-ponto<?= $status_atual["online"] ? " online" : "" ?>" id="chat-status-ponto"></span>
                        <?php endif; ?>
                    </a>
                    <span>
                        Conversa com <?= htmlspecialchars($contato_atual["nome_usuario"]) ?>
                        <?php if (!$status_atual["oculto"]): ?>
                            <div class="status-presenca-chat<?= $status_atual["online"] ? " online" : "" ?>" id="chat-status-texto">
                                <?= $status_atual["online"] ? "Online" : ($status_atual["visto_texto"] ? "Visto por último " . htmlspecialchars($status_atual["visto_texto"]) : "Offline") ?>
                            </div>
                        <?php endif; ?>
                    </span>
                    <?php if ($posso_enviar): ?>
                    <span class="chat-ligar">
                        <button type="button" aria-label="Chamada de voz" title="Chamada de voz" onclick="FewardLigacao && FewardLigacao.ligar(<?= (int) $contato_atual["id"] ?>, <?= htmlspecialchars(json_encode($contato_atual["nome_usuario"]), ENT_QUOTES) ?>, 'voz')"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg></button>
                        <button type="button" aria-label="Chamada de vídeo" title="Chamada de vídeo" onclick="FewardLigacao && FewardLigacao.ligar(<?= (int) $contato_atual["id"] ?>, <?= htmlspecialchars(json_encode($contato_atual["nome_usuario"]), ENT_QUOTES) ?>, 'video')"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="6" width="12" height="12" rx="3"/><path d="m15 11 6-3v8l-6-3z"/></svg></button>
                    </span>
                    <?php endif; ?>
                </h3>

                <?php if (!$posso_enviar): ?>
                    <div class="aviso-seguir">Você precisa seguir <strong><?= htmlspecialchars($contato_atual["nome_usuario"]) ?></strong> para enviar mensagens. <a href="perfil-usuario.php?id=<?= (int) $contato_atual["id"] ?>">Ver perfil e seguir</a></div>
                <?php endif; ?>

                <div class="mensagens-lista" id="mensagens-lista" data-meu-id="<?= (int) $usuario_logado["id"] ?>">
                    <?php foreach ($conversa as $m): ?>
                        <?php
                            $ehMinha = $m["remetente_id"] == $usuario_logado["id"];
                            $ehAudio = ($m["tipo"] ?? "texto") === "audio";
                            $ehReel = !$ehAudio && preg_match('/^\[\[reel:(\d+)\]\]$/', trim($m["conteudo"] ?? ""), $mr);
                        ?>
                        <div class="bolha <?= $ehMinha ? "minha" : "outra" ?><?= $ehReel ? " bolha-so-reel" : "" ?>" data-id="<?= (int) $m["id"] ?>" data-tipo="<?= $ehAudio ? "audio" : "texto" ?>" data-texto="<?= htmlspecialchars($m["conteudo"] ?? "", ENT_QUOTES, "UTF-8") ?>">
                            <?php if ($ehAudio): ?>
                                <span class="bolha-audio">
                                    <audio controls preload="none" src="audio_mensagem.php?id=<?= (int) $m["id"] ?>"></audio>
                                </span>
                            <?php else: ?>
                                <?php if ($ehReel): ?><span class="bolha-texto" data-reel-id="<?= (int) $mr[1] ?>"></span><?php else: ?><span class="bolha-texto"><?= nl2br(preg_replace('~(https?://[^\s<]+)~', '<a href="$1" target="_blank" rel="noopener" style="color:#7fd0ff;text-decoration:underline;">$1</a>', htmlspecialchars($m["conteudo"]))) ?></span><?php endif; ?>
                            <?php endif; ?>
                            <?php if (!empty($m["editada"])): ?><span class="bolha-editada">(editada)</span><?php endif; ?>
                            <?php if ($ehMinha): ?>
                                <span class="bolha-status <?= !empty($m["lida"]) ? "visualizada" : "" ?>" data-status><?= !empty($m["lida"]) ? "✓✓" : (!empty($m["entregue"]) ? "✓✓" : "✓") ?></span>
                                <button type="button" class="bolha-acoes-trigger">&gt;</button>
                                <span class="bolha-acoes">
                                    <?php if (!$ehAudio && !$ehReel): ?><button type="button" class="btn-editar-msg">Editar</button><?php endif; ?>
                                    <button type="button" class="btn-excluir-msg">Excluir</button>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="emoji-painel" id="emoji-painel">
                    <div class="emoji-abas" id="emoji-abas"></div>
                    <div class="emoji-grade" id="emoji-grade"></div>
                </div>

                <div class="digitando-indicador" id="digitando-indicador"></div>

                <div class="form-enviar" id="form-enviar" data-destinatario="<?= (int) $contato_atual["id"] ?>">
                    <button class="btn-emoji" type="button" id="btn-emoji" title="Emojis" aria-label="Emojis"<?= $bloq ?>>😊</button>
                    <input type="text" name="conteudo" id="campo-mensagem" placeholder="<?= $posso_enviar ? "Escreva uma mensagem..." : "Siga para enviar mensagens" ?>" autocomplete="off"<?= $bloq ?>>
                    <span class="gravacao-info" id="gravacao-info">
                        <span>🔴 Gravando <span id="gravacao-tempo">0:00</span></span>
                        <button type="button" class="btn-cancelar-gravacao" id="btn-cancelar-gravacao">Cancelar</button>
                    </span>
                    <button class="btn-gravar-audio" type="button" id="btn-gravar-audio" title="Gravar mensagem de áudio"<?= $bloq ?>>🎤</button>
                    <button class="acao" type="button" id="btn-enviar"<?= $bloq ?>>➤</button>
                </div>
                <?php if ($posso_enviar): ?>
                <noscript>
                <form class="form-enviar" method="POST">
                    <input type="hidden" name="destinatario_id" value="<?= $contato_atual["id"] ?>">
                    <input type="text" name="conteudo" placeholder="Escreva uma mensagem..." required>
                    <button class="acao" type="submit">➤</button>
                </form>
                </noscript>
                <?php endif; ?>

                <script>
                (function () {
                    function atualizarAlturaAplicativo() {
                        const altura = window.visualViewport ? window.visualViewport.height : window.innerHeight;
                        document.documentElement.style.setProperty("--app-height", altura + "px");
                    }
                    atualizarAlturaAplicativo();
                    window.addEventListener("resize", atualizarAlturaAplicativo);
                    if (window.visualViewport) window.visualViewport.addEventListener("resize", atualizarAlturaAplicativo);
                    // No celular, deixamos o navegador controlar a altura da viewport.
                    // Isso evita que o teclado faça os contatos ou a barra de digitação sumirem.
                    if (window.visualViewport) {
                        window.visualViewport.addEventListener("resize", () => {
                            requestAnimationFrame(() => {
                                const foco = document.activeElement === document.getElementById("campo-mensagem");
                                if (foco) rolarParaFinal();
                            });
                        });
                    }

                    const destinatarioId = <?= (int) $contato_atual["id"] ?>;
                    const meuId = <?= (int) $usuario_logado["id"] ?>;
                    const nomeContato = <?= json_encode($contato_atual["nome_usuario"]) ?>;

                    const lista = document.getElementById("mensagens-lista");
                    const campo = document.getElementById("campo-mensagem");
                    const botaoEnviar = document.getElementById("btn-enviar");
                    const indicador = document.getElementById("digitando-indicador");
                    const btnGravarAudio = document.getElementById("btn-gravar-audio");
                    const gravacaoInfo = document.getElementById("gravacao-info");
                    const gravacaoTempo = document.getElementById("gravacao-tempo");
                    const btnCancelarGravacao = document.getElementById("btn-cancelar-gravacao");
                    const chatStatusPonto = document.getElementById("chat-status-ponto");
                    const chatStatusTexto = document.getElementById("chat-status-texto");

                    let ultimoId = 0;
                    lista.querySelectorAll(".bolha").forEach(b => {
                        ultimoId = Math.max(ultimoId, parseInt(b.dataset.id, 10) || 0);
                    });

                    function estaNoFinal() {
                        return lista.scrollTop + lista.clientHeight >= lista.scrollHeight - 40;
                    }

                    function rolarParaFinal() {
                        if (!lista) return;
                        // Mantém a página no lugar e move somente a área da conversa.
                        const paginaY = window.scrollY;
                        lista.scrollTo({ top: lista.scrollHeight, left: 0, behavior: "auto" });
                        if (window.scrollY !== paginaY) window.scrollTo(0, paginaY);
                    }

                    // V41: seletor de emoji
                    (function () {
                        const btn = document.getElementById("btn-emoji"), painel = document.getElementById("emoji-painel");
                        const abas = document.getElementById("emoji-abas"), grade = document.getElementById("emoji-grade");
                        const campoMsg = document.getElementById("campo-mensagem"), form = document.getElementById("form-enviar");
                        if (!btn || !painel || !campoMsg) return;
                        const CATS = [
                            ["🕘", "Recentes", []],
                            ["😀", "Carinhas", "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🤫 🫠 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖".split(" ")],
                            ["👍", "Gestos", "👍 👎 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 ✍️ 💪 🦾 👏 🙌 🫶 👐 🤲 🫡 🫵 🖕 ✊ 👊 🤛 🤜".split(" ")],
                            ["❤️", "Corações", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❤️‍🔥 ❤️‍🩹 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 💋 💌 💯 💢 💥 💫 💦 💨 🕳️ 💬 💭 🗯️ 💤".split(" ")],
                            ["🐶", "Bichos", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🦈 🐊 🐘 🦒 🦓 🐎 🌵 🌲 🌴 🌱 🍀 🌸 🌹 🌻 🌞 🌙 ⭐ 🌈 ☁️ 🔥 💧 ⚡ ❄️".split(" ")],
                            ["🍕", "Comida", "🍎 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🍞 🧀 🍳 🥞 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🍝 🍜 🍣 🍤 🍙 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍭 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🍹 🍾".split(" ")],
                            ["⚽", "Objetos", "⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🎮 🕹️ 🎲 🎯 🎸 🎹 🎧 🎤 🎬 📷 📱 💻 🖥️ ⌚ 🔋 💡 📚 ✏️ 📌 🔒 🔑 🎁 🎉 🎊 🎈 🏆 🥇 🚗 🏍️ ✈️ 🚀 🏠 💰 💎 ⚙️ 🔧 🧲".split(" ")]
                        ];
                        function lerRecentes() { try { return JSON.parse(localStorage.getItem("feward_emojis_recentes") || "[]"); } catch (e) { return []; } }
                        function salvarRecente(e) { try { const r = [e].concat(lerRecentes().filter(function (x) { return x !== e; })).slice(0, 24); localStorage.setItem("feward_emojis_recentes", JSON.stringify(r)); } catch (x) {} }
                        let aba = 1;
                        function desenhar() {
                            abas.replaceChildren(); grade.replaceChildren();
                            CATS[0][2] = lerRecentes();
                            CATS.forEach(function (c, i) {
                                const b = document.createElement("button"); b.type = "button"; b.textContent = c[0]; b.title = c[1];
                                if (i === aba) b.className = "ativa";
                                b.addEventListener("click", function () { aba = i; desenhar(); });
                                abas.appendChild(b);
                            });
                            const lista = CATS[aba][2];
                            if (!lista.length) { const v = document.createElement("div"); v.style.cssText = "grid-column:1/-1;color:#aaa;font-size:13px;padding:8px;"; v.textContent = "Os emojis que você usar aparecem aqui."; grade.appendChild(v); }
                            lista.forEach(function (e) {
                                const b = document.createElement("button"); b.type = "button"; b.textContent = e;
                                b.addEventListener("click", function () { inserir(e); });
                                grade.appendChild(b);
                            });
                        }
                        function inserir(e) {
                            const ini = campoMsg.selectionStart != null ? campoMsg.selectionStart : campoMsg.value.length;
                            const fim = campoMsg.selectionEnd != null ? campoMsg.selectionEnd : ini;
                            campoMsg.value = campoMsg.value.slice(0, ini) + e + campoMsg.value.slice(fim);
                            const pos = ini + e.length;
                            try { campoMsg.setSelectionRange(pos, pos); } catch (x) {}
                            campoMsg.dispatchEvent(new Event("input", { bubbles: true }));
                            salvarRecente(e);
                        }
                        function posicionar() {
                            const r = form.getBoundingClientRect();
                            const largura = Math.min(r.width, 420);
                            painel.style.width = largura + "px";
                            painel.style.left = Math.max(8, r.left) + "px";
                            painel.style.bottom = (window.innerHeight - r.top + 6) + "px";
                        }
                        btn.addEventListener("click", function (ev) {
                            ev.stopPropagation();
                            if (painel.classList.contains("aberto")) { painel.classList.remove("aberto"); return; }
                            if (lerRecentes().length) aba = 0; else aba = 1;
                            desenhar(); posicionar(); painel.classList.add("aberto");
                        });
                        document.addEventListener("click", function (ev) { if (!painel.contains(ev.target) && ev.target !== btn) painel.classList.remove("aberto"); });
                        window.addEventListener("resize", function () { if (painel.classList.contains("aberto")) posicionar(); });
                        document.addEventListener("keydown", function (ev) { if (ev.key === "Escape") painel.classList.remove("aberto"); });
                    })();

                    // V40: mensagem "[[reel:ID]]" vira um cartão do reel (sem mostrar link)
                    const REEL_RE = /^\[\[reel:(\d+)\]\]$/;
                    function montarCartaoReel(span, id) {
                        span.className = "bolha-texto bolha-reel";
                        span.replaceChildren();
                        const bolha = span.closest(".bolha"); if (bolha) bolha.classList.add("bolha-so-reel");
                        const a = document.createElement("a");
                        a.className = "reel-cartao"; a.href = "reels.php?id=" + id;
                        const vazio = document.createElement("div"); vazio.className = "reel-cartao-msg"; vazio.textContent = "Carregando reel…";
                        a.appendChild(vazio);
                        span.appendChild(a);
                        fetch("reels_api.php?acao=info&video_id=" + id).then(function (r) { return r.json(); }).then(function (d) {
                            a.replaceChildren();
                            if (!d.existe) { vazio.textContent = "Este reel não está mais disponível"; a.appendChild(vazio); a.removeAttribute("href"); return; }
                            const v = document.createElement("video");
                            v.src = d.src + "#t=0.1"; v.muted = true; v.preload = "metadata"; v.playsInline = true;
                            const topo = document.createElement("div"); topo.className = "reel-cartao-topo";
                            let av;
                            if (d.tem_foto) { av = document.createElement("img"); av.src = "avatar.php?id=" + d.autor_id; av.style.objectPosition = d.foto_pos; }
                            else { av = document.createElement("span"); av.textContent = "👤"; }
                            av.className = "reel-cartao-avatar";
                            const nome = document.createElement("span"); nome.className = "reel-cartao-nome"; nome.textContent = d.autor;
                            topo.append(av, nome);
                            const play = document.createElement("span"); play.className = "reel-cartao-play"; play.textContent = "▶";
                            a.append(v, topo, play);
                        }).catch(function () { vazio.textContent = "Reel"; });
                    }
                    function renderTextoBolha(span, conteudo) {
                        const m = REEL_RE.exec(String(conteudo || "").trim());
                        if (m) { montarCartaoReel(span, m[1]); return; }
                        span.className = "bolha-texto";
                        span.innerHTML = linkificar(escaparHtml(conteudo)).replace(/\n/g, "<br>");
                    }
                    document.querySelectorAll("[data-reel-id]").forEach(function (sp) { montarCartaoReel(sp, sp.dataset.reelId); });

                    // V38: transforma http(s)://... em link clicável (texto já escapado)
                    function linkificar(html) {
                        return html.replace(/(https?:\/\/[^\s<]+)/g, function (u) {
                            return '<a href="' + u + '" target="_blank" rel="noopener" style="color:#7fd0ff;text-decoration:underline;">' + u + '</a>';
                        });
                    }

                    function escaparHtml(texto) {
                        const div = document.createElement("div");
                        div.textContent = texto;
                        return div.innerHTML;
                    }

                    // --- editar/excluir mensagem (só aparece nas minhas próprias mensagens) ---
                    function fecharAcoesAbertas() {
                        document.querySelectorAll(".bolha-acoes.aberto").forEach(el => el.classList.remove("aberto"));
                    }

                    function alternarAcoesMensagem(trigger) {
                        const linha = trigger.nextElementSibling;
                        const estavaAberta = linha.classList.contains("aberto");
                        fecharAcoesAbertas();
                        if (!estavaAberta) linha.classList.add("aberto");
                    }

                    function aplicarConteudoNaBolha(bolha, msg) {
                        // mensagem de áudio não tem texto pra atualizar, só o status (ticks) abaixo
                        if (bolha.dataset.tipo !== "audio") {
                            const span = bolha.querySelector(".bolha-texto");
                            renderTextoBolha(span, msg.conteudo);
                            bolha.dataset.texto = msg.conteudo;
                            const foiEditada = parseInt(msg.editada, 10) === 1 || msg.editada === true;
                            if (foiEditada && !bolha.querySelector(".bolha-editada")) {
                                const selo = document.createElement("span");
                                selo.className = "bolha-editada";
                                selo.textContent = "(editada)";
                                span.after(selo);
                            }
                        }
                        aplicarStatusNaBolha(bolha, msg);
                    }

                    // atualiza o indicador enviada (✓) / entregue (✓✓ cinza) / visualizada (✓✓ azul)
                    function aplicarStatusNaBolha(bolha, msg) {
                        const selo = bolha.querySelector(".bolha-status");
                        if (!selo) return; // só existe nas minhas próprias mensagens
                        const lida = parseInt(msg.lida, 10) === 1 || msg.lida === true;
                        const entregue = parseInt(msg.entregue, 10) === 1 || msg.entregue === true;
                        selo.textContent = (lida || entregue) ? "✓✓" : "✓";
                        selo.classList.toggle("visualizada", lida);
                    }

                    function excluirMensagem(bolha) {
                        if (!confirm("Excluir esta mensagem?")) return;
                        const dados = new URLSearchParams();
                        dados.set("acao", "excluir");
                        dados.set("mensagem_id", bolha.dataset.id);
                        fetch("mensagem_api.php", { method: "POST", body: dados })
                            .then(r => r.json())
                            .then(resp => {
                                if (resp.ok) bolha.remove();
                                else alert(resp.erro || "Não foi possível excluir a mensagem.");
                            })
                            .catch(() => alert("Não foi possível excluir a mensagem."));
                    }

                    function editarMensagem(bolha) {
                        if (bolha.querySelector(".bolha-editar-campo")) return; // já editando
                        fecharAcoesAbertas();

                        const span = bolha.querySelector(".bolha-texto");
                        const textoAtual = bolha.dataset.texto;
                        const trigger = bolha.querySelector(".bolha-acoes-trigger");

                        const textarea = document.createElement("textarea");
                        textarea.className = "bolha-editar-campo";
                        textarea.value = textoAtual;

                        const linhaBotoes = document.createElement("div");
                        linhaBotoes.className = "bolha-editar-botoes";
                        const btnSalvar = document.createElement("button");
                        btnSalvar.type = "button";
                        btnSalvar.textContent = "Salvar";
                        const btnCancelar = document.createElement("button");
                        btnCancelar.type = "button";
                        btnCancelar.textContent = "Cancelar";
                        linhaBotoes.append(btnSalvar, btnCancelar);

                        span.style.display = "none";
                        if (trigger) trigger.style.display = "none";
                        span.after(textarea, linhaBotoes);
                        textarea.focus();
                        textarea.setSelectionRange(textarea.value.length, textarea.value.length);

                        function cancelar() {
                            textarea.remove();
                            linhaBotoes.remove();
                            span.style.display = "";
                            if (trigger) trigger.style.display = "";
                        }

                        function salvar() {
                            const novoTexto = textarea.value.trim();
                            if (novoTexto === "" || novoTexto === textoAtual) { cancelar(); return; }

                            const dados = new URLSearchParams();
                            dados.set("acao", "editar");
                            dados.set("mensagem_id", bolha.dataset.id);
                            dados.set("conteudo", novoTexto);

                            btnSalvar.disabled = true;
                            fetch("mensagem_api.php", { method: "POST", body: dados })
                                .then(r => r.json())
                                .then(resp => {
                                    if (resp.ok) {
                                        aplicarConteudoNaBolha(bolha, resp.mensagem);
                                        cancelar();
                                    } else {
                                        alert(resp.erro || "Não foi possível editar a mensagem.");
                                        btnSalvar.disabled = false;
                                    }
                                })
                                .catch(() => {
                                    alert("Não foi possível editar a mensagem.");
                                    btnSalvar.disabled = false;
                                });
                        }

                        btnSalvar.addEventListener("click", salvar);
                        btnCancelar.addEventListener("click", cancelar);
                        textarea.addEventListener("keydown", function (e) {
                            if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); salvar(); }
                            if (e.key === "Escape") cancelar();
                        });
                    }

                    function vincularAcoesBolha(bolha) {
                        const trigger = bolha.querySelector(".bolha-acoes-trigger");
                        if (!trigger || trigger.dataset.vinculado) return;
                        trigger.dataset.vinculado = "1";
                        trigger.addEventListener("click", () => alternarAcoesMensagem(trigger));
                        const btnEditar = bolha.querySelector(".btn-editar-msg");
                        const btnExcluir = bolha.querySelector(".btn-excluir-msg");
                        if (btnEditar) btnEditar.addEventListener("click", () => editarMensagem(bolha));
                        if (btnExcluir) btnExcluir.addEventListener("click", () => excluirMensagem(bolha));
                    }

                    document.addEventListener("click", function (e) {
                        if (!e.target.closest(".bolha-acoes-trigger") && !e.target.closest(".bolha-acoes")) {
                            fecharAcoesAbertas();
                        }
                    });

                    // liga as ações de editar/excluir nas bolhas já renderizadas pelo PHP
                    lista.querySelectorAll(".bolha.minha").forEach(vincularAcoesBolha);

                    function criarBolhaEl(msg) {
                        const ehMinha = parseInt(msg.remetente_id, 10) === meuId;
                        const idReal = /^\d+$/.test(String(msg.id));
                        const ehAudio = msg.tipo === "audio";

                        const bolha = document.createElement("div");
                        bolha.className = "bolha " + (ehMinha ? "minha" : "outra");
                        bolha.dataset.id = msg.id;
                        bolha.dataset.tipo = ehAudio ? "audio" : "texto";
                        bolha.dataset.texto = msg.conteudo || "";

                        if (ehAudio) {
                            const wrap = document.createElement("span");
                            wrap.className = "bolha-audio";
                            const player = document.createElement("audio");
                            player.controls = true;
                            player.preload = "none";
                            player.src = "audio_mensagem.php?id=" + msg.id;
                            wrap.appendChild(player);
                            bolha.appendChild(wrap);
                        } else {
                            const span = document.createElement("span");
                            span.className = "bolha-texto";
                            renderTextoBolha(span, msg.conteudo);
                            bolha.appendChild(span);
                        }

                        if (parseInt(msg.editada, 10) === 1 || msg.editada === true) {
                            const selo = document.createElement("span");
                            selo.className = "bolha-editada";
                            selo.textContent = "(editada)";
                            bolha.appendChild(selo);
                        }

                        if (ehMinha && idReal) {
                            const status = document.createElement("span");
                            status.className = "bolha-status";
                            bolha.appendChild(status);
                            aplicarStatusNaBolha(bolha, msg);

                            const trigger = document.createElement("button");
                            trigger.type = "button";
                            trigger.className = "bolha-acoes-trigger";
                            trigger.textContent = ">";

                            const acoes = document.createElement("span");
                            acoes.className = "bolha-acoes";
                            if (!ehAudio && !REEL_RE.test(String(msg.conteudo || "").trim())) {
                                const btnEditar = document.createElement("button");
                                btnEditar.type = "button";
                                btnEditar.className = "btn-editar-msg";
                                btnEditar.textContent = "Editar";
                                acoes.appendChild(btnEditar);
                            }
                            const btnExcluir = document.createElement("button");
                            btnExcluir.type = "button";
                            btnExcluir.className = "btn-excluir-msg";
                            btnExcluir.textContent = "Excluir";
                            acoes.appendChild(btnExcluir);

                            bolha.append(trigger, acoes);
                            vincularAcoesBolha(bolha);
                        }

                        return bolha;
                    }

                    function adicionarMensagem(msg, forcarRolagem) {
                        const existente = lista.querySelector('[data-id="' + msg.id + '"]');
                        if (existente) {
                            // já estava na tela: se foi editada, só atualiza o conteúdo
                            aplicarConteudoNaBolha(existente, msg);
                            return;
                        }
                        const grudado = estaNoFinal();
                        const bolha = criarBolhaEl(msg);
                        lista.appendChild(bolha);
                        const idNum = parseInt(msg.id, 10);
                        if (!isNaN(idNum)) ultimoId = Math.max(ultimoId, idNum);
                        // só rola automaticamente se o usuário já estava vendo o final da conversa,
                        // ou se foi ele mesmo que acabou de mandar essa mensagem
                        if (grudado || forcarRolagem) rolarParaFinal();
                    }

                    // --- envio (Enter ou botão) sem recarregar a página ---
                    function enviarMensagem() {
                        const texto = campo.value.trim();
                        if (texto === "") return;

                        campo.value = "";
                        // Mostra a mensagem imediatamente no celular/PC, sem esperar o banco.
                        const temporario = {
                            id: "tmp-" + Date.now(),
                            remetente_id: meuId,
                            destinatario_id: destinatarioId,
                            conteudo: texto
                        };
                        adicionarMensagem(temporario, true);
                        // Garante que a conversa fique no final imediatamente.
                        requestAnimationFrame(rolarParaFinal);
                        campo.disabled = true;

                        const dados = new URLSearchParams();
                        dados.set("acao", "enviar");
                        dados.set("destinatario_id", destinatarioId);
                        dados.set("conteudo", texto);

                        fetch("mensagem_api.php", { method: "POST", body: dados })
                            .then(r => r.json())
                            .then(resp => {
                                if (resp.ok) {
                                    const temporaria = lista.querySelector('[data-id="' + temporario.id + '"]');
                                    if (temporaria) temporaria.remove();
                                    adicionarMensagem(resp.mensagem, true);
                                } else {
                                    const temporaria = lista.querySelector('[data-id="' + temporario.id + '"]');
                                    if (temporaria) temporaria.remove();
                                    campo.value = texto;
                                    if (resp.erro) alert(resp.erro);
                                }
                            })
                            .catch(() => {
                                // se falhar, devolve o texto pro campo pra não perder a mensagem
                                campo.value = texto;
                            })
                            .finally(() => {
                                campo.disabled = false;
                                campo.focus();
                            });
                    }

                    botaoEnviar.addEventListener("click", enviarMensagem);
                    campo.addEventListener("keydown", function (e) {
                        if (e.key === "Enter") {
                            e.preventDefault();
                            enviarMensagem();
                        }
                    });

                    // --- avisa "digitando..." enquanto a pessoa escreve ---
                    let timeoutDigitando = null;
                    campo.addEventListener("input", function () {
                        if (timeoutDigitando) return; // já avisou recentemente, não manda de novo a cada tecla
                        avisarDigitando();
                        timeoutDigitando = setTimeout(() => { timeoutDigitando = null; }, 2000);
                    });

                    function avisarDigitando() {
                        const dados = new URLSearchParams();
                        dados.set("acao", "digitando");
                        dados.set("destinatario_id", destinatarioId);
                        fetch("mensagem_api.php", { method: "POST", body: dados });
                    }

                    // --- carregamento automático de mensagens novas + status "digitando"/online ---
                    function atualizar() {
                        fetch("mensagem_api.php?acao=atualizar&com=" + destinatarioId + "&depois_de=" + ultimoId)
                            .then(r => r.json())
                            .then(resp => {
                                if (!resp.ok) return;
                                resp.mensagens.forEach(msg => adicionarMensagem(msg));
                                indicador.textContent = resp.digitando ? (nomeContato + " está digitando...") : "";

                                if (chatStatusPonto && chatStatusTexto) {
                                    chatStatusPonto.classList.toggle("online", !!resp.contato_online);
                                    chatStatusTexto.classList.toggle("online", !!resp.contato_online);
                                    chatStatusTexto.textContent = resp.contato_online
                                        ? "Online"
                                        : (resp.contato_visto ? ("Visto por último " + resp.contato_visto) : "Offline");
                                }
                            })
                            .catch(() => {});
                    }

                    // Ao abrir/trocar de conversa, começa sempre na última mensagem.
                    function iniciarNoFinal() {
                        rolarParaFinal();
                        requestAnimationFrame(rolarParaFinal);
                        setTimeout(rolarParaFinal, 50);
                        setTimeout(rolarParaFinal, 180);
                    }

                    // Ao abrir/trocar de conversa, começa sempre na última mensagem.
                    iniciarNoFinal();

                    setInterval(atualizar, 2000);

                    // --- gravação de mensagem de áudio (microfone do navegador) ---
                    let gravador = null;
                    let pedacosAudio = [];
                    let cronometroGravacao = null;
                    let segundosGravados = 0;
                    let gravacaoCancelada = false;

                    function formatarTempo(seg) {
                        const m = Math.floor(seg / 60);
                        const s = seg % 60;
                        return m + ":" + String(s).padStart(2, "0");
                    }

                    function mimeSuportado() {
                        const candidatos = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"];
                        for (const tipo of candidatos) {
                            if (window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(tipo)) return tipo;
                        }
                        return "";
                    }

                    function iniciarGravacao() {
                        if (!navigator.mediaDevices || !window.MediaRecorder) {
                            alert("Seu navegador não suporta gravação de áudio.");
                            return;
                        }
                        navigator.mediaDevices.getUserMedia({ audio: true })
                            .then(function (stream) {
                                gravacaoCancelada = false;
                                pedacosAudio = [];
                                segundosGravados = 0;
                                const mime = mimeSuportado();
                                gravador = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);

                                gravador.addEventListener("dataavailable", function (e) {
                                    if (e.data && e.data.size > 0) pedacosAudio.push(e.data);
                                });

                                gravador.addEventListener("stop", function () {
                                    stream.getTracks().forEach(t => t.stop());
                                    clearInterval(cronometroGravacao);
                                    campo.style.display = "";
                                    gravacaoInfo.classList.remove("ativo");
                                    btnGravarAudio.classList.remove("gravando");
                                    btnGravarAudio.textContent = "🎤";

                                    if (gravacaoCancelada || pedacosAudio.length === 0 || segundosGravados < 1) return;

                                    const blob = new Blob(pedacosAudio, { type: gravador.mimeType || "audio/webm" });
                                    enviarAudio(blob, segundosGravados);
                                });

                                gravador.start();
                                campo.style.display = "none";
                                gravacaoInfo.classList.add("ativo");
                                btnGravarAudio.classList.add("gravando");
                                btnGravarAudio.textContent = "⏹";
                                gravacaoTempo.textContent = "0:00";

                                cronometroGravacao = setInterval(function () {
                                    segundosGravados++;
                                    gravacaoTempo.textContent = formatarTempo(segundosGravados);
                                    // trava em 5 minutos pra não gerar um arquivo enorme
                                    if (segundosGravados >= 300) pararGravacao(false);
                                }, 1000);
                            })
                            .catch(function () {
                                alert("Não foi possível acessar o microfone. Verifique a permissão do navegador.");
                            });
                    }

                    function pararGravacao(cancelar) {
                        if (!gravador || gravador.state === "inactive") return;
                        gravacaoCancelada = !!cancelar;
                        gravador.stop();
                    }

                    btnGravarAudio.addEventListener("click", function () {
                        if (gravador && gravador.state === "recording") {
                            pararGravacao(false);
                        } else {
                            iniciarGravacao();
                        }
                    });

                    btnCancelarGravacao.addEventListener("click", function () {
                        pararGravacao(true);
                    });

                    function enviarAudio(blob, duracao) {
                        const idTemp = "tmp-" + Date.now();
                        const temporario = {
                            id: idTemp,
                            remetente_id: meuId,
                            destinatario_id: destinatarioId,
                            tipo: "audio",
                            conteudo: ""
                        };
                        adicionarMensagem(temporario, true);
                        const bolhaTemp = lista.querySelector('[data-id="' + idTemp + '"]');
                        if (bolhaTemp) {
                            const player = bolhaTemp.querySelector("audio");
                            if (player) player.src = URL.createObjectURL(blob);
                        }
                        requestAnimationFrame(rolarParaFinal);

                        const extensao = (blob.type || "").includes("ogg") ? "ogg" : "webm";
                        const dados = new FormData();
                        dados.set("acao", "enviar_audio");
                        dados.set("destinatario_id", destinatarioId);
                        dados.set("duracao", duracao);
                        dados.set("audio", blob, "audio." + extensao);

                        fetch("mensagem_api.php", { method: "POST", body: dados })
                            .then(r => r.json())
                            .then(resp => {
                                if (bolhaTemp) bolhaTemp.remove();
                                if (resp.ok) {
                                    adicionarMensagem(resp.mensagem, true);
                                } else {
                                    alert(resp.erro || "Não foi possível enviar o áudio.");
                                }
                            })
                            .catch(() => {
                                if (bolhaTemp) bolhaTemp.remove();
                                alert("Não foi possível enviar o áudio.");
                            });
                    }

                    // --- atualização periódica dos pontos online/offline na lista de contatos ---
                    const listaContatos = document.getElementById("lista-contatos");
                    if (listaContatos) {
                        function atualizarStatusContatos() {
                            const ids = Array.from(listaContatos.querySelectorAll("[data-contato-id]"))
                                .map(a => a.dataset.contatoId);
                            if (ids.length === 0) return;
                            fetch("status_api.php?acao=status&ids=" + ids.join(","))
                                .then(r => r.json())
                                .then(resp => {
                                    if (!resp.ok) return;
                                    listaContatos.querySelectorAll("[data-contato-id]").forEach(function (a) {
                                        const info = resp.status[a.dataset.contatoId];
                                        const ponto = a.querySelector(".contato-status-ponto");
                                        if (!info || info.oculto || !ponto) return;
                                        ponto.classList.toggle("online", !!info.online);
                                    });
                                })
                                .catch(() => {});
                        }
                        atualizarStatusContatos();
                        setInterval(atualizarStatusContatos, 15000);
                    }
                })();
                </script>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Clique na foto de um contato (lista da esquerda) abre o perfil dele, sem abrir a conversa.
document.addEventListener("click", function (e) {
    var alvo = e.target.closest(".avatar-perfil");
    if (!alvo) return;
    e.preventDefault();
    e.stopPropagation();
    window.location.href = "perfil-usuario.php?id=" + encodeURIComponent(alvo.dataset.perfilId);
});
</script>

</body>
</html>
