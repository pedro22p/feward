<?php
// Funções compartilhadas de status online/offline e "visto por último".
// Incluído por auth.php, então já está disponível em qualquer página logada.

// Quantos segundos sem "batida de presença" até considerar a conta offline.
// A batida acontece a cada 20s enquanto o app fica aberto, então 45s dá
// uma margem segura pra uma batida atrasar sem piscar online/offline à toa.
const FEWARD_JANELA_ONLINE_SEGUNDOS = 45;

// Recebe o valor cru de contas.ultimo_acesso (UTC) e diz se a conta está online agora.
function feward_esta_online($ultimo_acesso_utc) {
    if (empty($ultimo_acesso_utc)) return false;
    $ts = strtotime($ultimo_acesso_utc . " UTC");
    if ($ts === false) return false;
    return (time() - $ts) <= FEWARD_JANELA_ONLINE_SEGUNDOS;
}

// Formata "visto por último em ..." de forma amigável (relativo/hoje/ontem/data).
function feward_formatar_ultimo_acesso($ultimo_acesso_utc) {
    if (empty($ultimo_acesso_utc)) return null;
    $ts = strtotime($ultimo_acesso_utc . " UTC");
    if ($ts === false) return null;

    $agora = time();
    $diff = $agora - $ts;

    if ($diff < 60) return "agora mesmo";
    if ($diff < 3600) {
        $min = (int) floor($diff / 60);
        return "há " . $min . " min";
    }

    // Converte pro fuso do servidor só pra decidir "hoje"/"ontem" e montar o horário.
    $hoje = date("Y-m-d");
    $dataTs = date("Y-m-d", $ts);
    $hora = date("H:i", $ts);

    if ($dataTs === $hoje) return "hoje às " . $hora;
    if ($dataTs === date("Y-m-d", $agora - 86400)) return "ontem às " . $hora;

    return date("d/m/Y", $ts) . " às " . $hora;
}

// Monta o "pacote" de status pra mostrar sobre um usuário, já respeitando o
// modo fantasma dele (quem ativou o modo fantasma não aparece online nem
// mostra "visto por último" pra ninguém).
function feward_status_usuario(array $conta) {
    if (!empty($conta["modo_fantasma"])) {
        return ["online" => false, "visto_texto" => null, "oculto" => true];
    }
    $online = feward_esta_online($conta["ultimo_acesso"] ?? null);
    return [
        "online" => $online,
        "visto_texto" => $online ? null : feward_formatar_ultimo_acesso($conta["ultimo_acesso"] ?? null),
        "oculto" => false,
    ];
}
