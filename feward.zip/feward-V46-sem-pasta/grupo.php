<?php
// V30: criar grupo (?novo=1) e conversar no grupo (?id=N).
// Regras: só dá pra colocar no grupo quem EU sigo; quem entrou no grupo pode
// conversar com todos do grupo (não precisa seguir cada um).
require_once "auth.php";
require_once "seguir_util.php";

$eu = (int) $usuario_logado["id"];
$erro = "";

// ---------- criar grupo ----------
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["criar_grupo"])) {
    $nome = trim($_POST["nome"] ?? "");
    $seguidos = feward_ids_seguidos($pdo, $eu);
    $ids = array_values(array_unique(array_map("intval", (array) ($_POST["membros"] ?? []))));
    $ids = array_values(array_filter($ids, function ($i) use ($eu, $seguidos) { return $i !== $eu && isset($seguidos[$i]); }));

    if ($nome === "") {
        $erro = "Dê um nome para o grupo.";
    } elseif (mb_strlen($nome) > 60) {
        $erro = "O nome do grupo pode ter no máximo 60 caracteres.";
    } elseif (count($ids) < 1) {
        $erro = "Escolha pelo menos uma pessoa que você segue.";
    } elseif (count($ids) > 49) {
        $erro = "Um grupo pode ter no máximo 50 pessoas.";
    } else {
        $pdo->beginTransaction();
        $pdo->prepare("INSERT INTO grupos (nome, criador_id) VALUES (?, ?)")->execute([$nome, $eu]);
        $novo_id = (int) $pdo->lastInsertId();
        $ins = $pdo->prepare("INSERT INTO grupo_membros (grupo_id, usuario_id) VALUES (?, ?)");
        $ins->execute([$novo_id, $eu]);
        foreach ($ids as $uid) $ins->execute([$novo_id, $uid]);
        $pdo->commit();
        header("Location: grupo.php?id=" . $novo_id);
        exit;
    }
}

$grupo = null;
$membros = [];
$mensagens = [];
$modo_novo = isset($_GET["novo"]) || $_SERVER["REQUEST_METHOD"] === "POST";

if (!$modo_novo) {
    $stmt = $pdo->prepare("SELECT g.* FROM grupos g JOIN grupo_membros gm ON gm.grupo_id = g.id WHERE g.id = ? AND gm.usuario_id = ?");
    $stmt->execute([(int) ($_GET["id"] ?? 0), $eu]);
    $grupo = $stmt->fetch();
    if (!$grupo) {
        header("Location: mensagem.php");
        exit;
    }

    $stmt = $pdo->prepare("SELECT c.id, c.nome_usuario FROM grupo_membros gm JOIN contas c ON c.id = gm.usuario_id WHERE gm.grupo_id = ? ORDER BY c.nome_usuario");
    $stmt->execute([$grupo["id"]]);
    $membros = $stmt->fetchAll();

    // Pessoas que ainda não estão no grupo podem ser convidadas por qualquer membro.
    $stmt = $pdo->prepare("SELECT c.id, c.nome_usuario, c.foto_perfil FROM contas c WHERE c.id <> ? AND NOT EXISTS (SELECT 1 FROM grupo_membros gm WHERE gm.grupo_id = ? AND gm.usuario_id = c.id) ORDER BY c.nome_usuario LIMIT 200");
    $stmt->execute([$eu, $grupo["id"]]);
    $convidaveis = $stmt->fetchAll();

    // últimas 200 mensagens (as novas chegam pelo polling)
    $stmt = $pdo->prepare("
        SELECT * FROM (
            SELECT gm.id, gm.remetente_id, gm.conteudo, gm.criado_em, c.nome_usuario
            FROM grupo_mensagens gm JOIN contas c ON c.id = gm.remetente_id
            WHERE gm.grupo_id = ? ORDER BY gm.id DESC LIMIT 200
        ) t ORDER BY id ASC
    ");
    $stmt->execute([$grupo["id"]]);
    $mensagens = $stmt->fetchAll();
} else {
    $stmt = $pdo->prepare("
        SELECT c.id, c.nome_usuario, c.foto_perfil FROM amizades a
        JOIN contas c ON c.id = a.amigo_id
        WHERE a.usuario_id = ? AND a.status = 'aceito' ORDER BY c.nome_usuario
    ");
    $stmt->execute([$eu]);
    $seguindo = $stmt->fetchAll();
}

$pagina_ativa = "mensagem";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0b1050">
    <title><?= $grupo ? htmlspecialchars($grupo["nome"]) : "Novo grupo" ?> - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .grupo-janela { display: flex; flex-direction: column; height: calc(100dvh - 180px); min-height: 360px; min-width: 0; }
        .grupo-topo { display: flex; align-items: center; gap: 10px; margin: 0 0 8px; flex: 0 0 auto; }
        .grupo-topo .grupo-nome { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .grupo-topo small { color: #aaa; font-weight: normal; margin-left: 6px; }
        .grupo-topo button, .grupo-form button, .btn-voltar { background: rgba(255,255,255,0.12); border: none; color: #fff; border-radius: 14px; padding: 7px 12px; cursor: pointer; font-size: 13px; text-decoration: none; }
        .grupo-topo .perigo { color: #ff8a8a; }
        .grupo-membros { flex: 0 0 auto; background: rgba(255,255,255,0.08); border-radius: 12px; padding: 8px 12px; margin-bottom: 8px; font-size: 13px; color: #ddd; max-height: 110px; overflow-y: auto; }
        .grupo-membros[hidden] { display: none; }
        .grupo-lista { flex: 1 1 auto; min-height: 0; overflow-y: auto; overflow-x: hidden; padding: 10px; -webkit-overflow-scrolling: touch; }
        .bolha { max-width: 70%; padding: 8px 14px; border-radius: 15px; margin-bottom: 10px; overflow-wrap: anywhere; word-break: break-word; }
        .bolha.minha { background: #2844e2; margin-left: auto; }
        .bolha.outra { background: rgba(255,255,255,0.15); }
        .bolha .autor { display: block; font-size: 12px; font-weight: 600; color: #4bbae6; margin-bottom: 2px; }
        .bolha .hora { display: block; font-size: 10px; opacity: 0.6; text-align: right; margin-top: 2px; }
        .grupo-form { display: flex; gap: 10px; margin-top: 8px; flex: 0 0 auto; }
        .grupo-form input { flex: 1; min-width: 0; font-size: 16px; }
        .grupo-form button { padding: 0 18px; font-size: 18px; }
        .novo-form { display: flex; flex-direction: column; gap: 14px; max-width: 520px; }
        .seguidos-lista { display: flex; flex-direction: column; gap: 6px; max-height: 45vh; overflow-y: auto; }
        .seguidos-lista label { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.08); border-radius: 12px; padding: 8px 12px; cursor: pointer; }
        .seguidos-lista input { width: auto; padding: 0; }
        .seguidos-lista img, .seguidos-lista .sem-foto { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; }
        @media (max-width: 768px) {
            .grupo-janela { height: calc(var(--app-height, 100dvh) - 250px); }
            .bolha { max-width: 86%; }
        }

        /* =========================
           SALA DE CHAMADA - PC + CELULAR
        ========================= */
        .grupo-chamada-barra { display:flex; gap:8px; flex-wrap:wrap; margin:0 0 10px; }
        .grupo-chamada-barra button { background:rgba(255,255,255,.10); border:1px solid rgba(255,255,255,.08); color:#fff; border-radius:12px; padding:9px 12px; cursor:pointer; transition:.18s ease; }
        .grupo-chamada-barra button:hover { background:rgba(255,255,255,.18); transform:translateY(-1px); }
        .grupo-chamada-barra button:disabled { opacity:.45; cursor:not-allowed; transform:none; }

        .chamada-box {
            position:fixed;
            inset:0;
            z-index:1000;
            background:linear-gradient(180deg,#070a18 0%,#0b1024 100%);
            display:flex;
            flex-direction:column;
            padding:16px 18px max(16px, env(safe-area-inset-bottom));
            overflow:hidden;
            overscroll-behavior:contain;
        }
        .chamada-box[hidden] { display:none; }
        .chamada-topo {
            width:min(1180px,100%);
            margin:0 auto 12px;
            display:flex;
            align-items:center;
            gap:10px;
            min-height:42px;
            flex:0 0 auto;
        }
        .chamada-topo strong { flex:1; min-width:0; font-size:18px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
        .chamada-topo #chamada-status { color:#8fe7b1; font-size:13px; background:rgba(68,220,135,.10); border:1px solid rgba(68,220,135,.18); padding:6px 10px; border-radius:999px; white-space:nowrap; }

        .chamada-videos {
            width:min(1180px,100%);
            flex:1 1 auto;
            min-height:0;
            margin:0 auto;
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            grid-auto-rows:minmax(150px,1fr);
            align-content:center;
            gap:12px;
            overflow:auto;
            padding:2px 2px 8px;
            -webkit-overflow-scrolling:touch;
        }
        .video-participante {
            position:relative;
            width:100%;
            min-width:0;
            min-height:0;
            aspect-ratio:16 / 9;
            max-height:calc(100dvh - 170px);
            background:radial-gradient(circle at 50% 45%,#1b2140 0%,#10152c 52%,#090d1d 100%);
            border:1px solid rgba(255,255,255,.09);
            border-radius:18px;
            overflow:hidden;
            display:flex;
            align-items:center;
            justify-content:center;
            box-shadow:0 10px 30px rgba(0,0,0,.25);
        }
        .video-participante video {
            position:absolute;
            inset:0;
            width:100%;
            height:100%;
            object-fit:cover;
            background:#080a15;
        }
        .video-participante .avatar-fallback {
            position:absolute;
            left:50%;
            top:50%;
            transform:translate(-50%,-50%);
            width:clamp(64px,10vw,120px);
            height:clamp(64px,10vw,120px);
            border-radius:50%;
            object-fit:cover;
            background:#303754;
            border:3px solid rgba(255,255,255,.12);
            box-shadow:0 8px 25px rgba(0,0,0,.3);
            z-index:2;
        }
        .video-participante.sem-camera video { display:none; }
        .video-participante.sem-camera .avatar-fallback { display:block !important; }
        .video-participante .nome {
            position:absolute;
            left:10px;
            bottom:10px;
            max-width:calc(100% - 20px);
            overflow:hidden;
            text-overflow:ellipsis;
            white-space:nowrap;
            z-index:4;
            background:rgba(0,0,0,.58);
            backdrop-filter:blur(8px);
            border:1px solid rgba(255,255,255,.08);
            border-radius:9px;
            padding:6px 9px;
            font-size:12px;
        }
        .video-participante .falando-anel {
            position:absolute;
            left:50%;
            top:50%;
            width:clamp(84px,12vw,138px);
            height:clamp(84px,12vw,138px);
            transform:translate(-50%,-50%);
            border:3px solid #54e38e;
            border-radius:50%;
            opacity:0;
            pointer-events:none;
            box-sizing:border-box;
            z-index:3;
        }
        .video-participante.falando .falando-anel { opacity:1; animation:falandoPulse 1s infinite; }
        .chamada-controles {
            width:min(1180px,100%);
            margin:0 auto;
            display:flex;
            justify-content:center;
            align-items:center;
            gap:9px;
            flex-wrap:wrap;
            padding:10px 0 max(0px, env(safe-area-inset-bottom));
            flex:0 0 auto;
        }
        .chamada-controles button {
            min-height:44px;
            border:1px solid rgba(255,255,255,.08);
            border-radius:13px;
            padding:10px 14px;
            cursor:pointer;
            background:rgba(255,255,255,.11);
            color:#fff;
            font-size:14px;
            transition:.18s ease;
        }
        .chamada-controles button:hover { background:rgba(255,255,255,.18); transform:translateY(-1px); }
        .chamada-controles .encerrar { background:#b52f3d; border-color:rgba(255,255,255,.08); }
        .chamada-controles .encerrar:hover { background:#d13b4b; }

        .chamada-entrada { background:rgba(35,58,130,.35); border:1px solid rgba(130,155,255,.10); border-radius:12px; padding:10px; margin-bottom:8px; display:flex; align-items:center; gap:10px; }
        .chamada-entrada span { flex:1; min-width:0; }
        .chamada-entrada button { border:0; border-radius:10px; padding:8px 12px; cursor:pointer; background:#2844e2; color:#fff; font-weight:600; }

        .convite-box { background:rgba(255,255,255,.08); border-radius:14px; padding:12px; margin-bottom:8px; }
        .convite-box[hidden] { display:none; }
        .convite-topo { display:flex; align-items:center; gap:8px; margin-bottom:8px; }
        .convite-topo strong { flex:1; }
        .convite-topo button { background:transparent; color:#fff; border:0; cursor:pointer; font-size:18px; }
        .convite-box input[type=search] { width:100%; box-sizing:border-box; margin-bottom:8px; }
        .convite-lista { max-height:260px; overflow:auto; display:flex; flex-direction:column; gap:5px; }
        .convite-pessoa { display:flex; align-items:center; gap:9px; padding:7px 9px; border-radius:10px; background:rgba(0,0,0,.12); cursor:pointer; }
        .convite-pessoa img,.convite-sem-foto { width:34px;height:34px;border-radius:50%;object-fit:cover;background:#353852;display:inline-flex;align-items:center;justify-content:center; }

        .em-chamada { overflow:hidden !important; }

        @keyframes falandoPulse { 0%,100% { transform:translate(-50%,-50%) scale(1); } 50% { transform:translate(-50%,-50%) scale(1.08); } }

        @media (min-width:1100px) {
            .chamada-videos { grid-template-columns:repeat(3,minmax(0,1fr)); grid-auto-rows:auto; }
            .chamada-videos:has(.video-participante:only-child) { grid-template-columns:minmax(320px,760px); justify-content:center; }
        }
        @media (max-width:700px) {
            .chamada-box { padding:8px 8px max(8px,env(safe-area-inset-bottom)); }
            .chamada-topo { margin-bottom:7px; min-height:38px; }
            .chamada-topo strong { font-size:15px; }
            .chamada-topo #chamada-status { font-size:11px; padding:5px 8px; }
            .chamada-videos {
                width:100%;
                grid-template-columns:repeat(2,minmax(0,1fr));
                grid-auto-rows:auto;
                gap:7px;
                padding-bottom:4px;
            }
            .video-participante { border-radius:12px; aspect-ratio:9 / 7; max-height:none; }
            .video-participante .nome { left:6px; bottom:6px; font-size:11px; padding:5px 7px; max-width:calc(100% - 12px); }
            .chamada-controles { gap:6px; padding-top:7px; }
            .chamada-controles button { flex:1 1 calc(50% - 6px); min-width:0; padding:9px 7px; font-size:12px; }
        }
        @media (max-width:380px) {
            .chamada-videos { grid-template-columns:1fr; }
            .video-participante { aspect-ratio:16 / 9; }
            .chamada-controles button { font-size:11px; }
        }
    </style>
    <link rel="stylesheet" href="chamada.css?v=48">
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1><?= $grupo ? "Grupo" : "Novo grupo" ?></h1>
        <a class="btn-voltar" href="mensagem.php">← Mensagens</a>
    </div>

<?php if ($modo_novo): ?>
    <div class="card-escuro">
        <?php if ($erro): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>

        <?php if (empty($seguindo)): ?>
            <p>Você ainda não segue ninguém. Siga pessoas (e espere elas aceitarem o pedido) para poder criar um grupo com elas.</p>
            <p><a href="explorar.php" style="color:#4bbae6;">Ir para Explorar →</a></p>
        <?php else: ?>
            <form class="novo-form" method="POST">
                <input type="hidden" name="criar_grupo" value="1">
                <input type="text" name="nome" maxlength="60" placeholder="Nome do grupo" value="<?= htmlspecialchars($_POST["nome"] ?? "") ?>" required>
                <div>Escolha quem entra (só aparecem pessoas que você segue):</div>
                <div class="seguidos-lista">
                    <?php $marcados = array_map("intval", (array) ($_POST["membros"] ?? [])); ?>
                    <?php foreach ($seguindo as $p): ?>
                        <label>
                            <input type="checkbox" name="membros[]" value="<?= (int) $p["id"] ?>" <?= in_array((int) $p["id"], $marcados, true) ? "checked" : "" ?>>
                            <?php if (!empty($p["foto_perfil"])): ?>
                                <img src="avatar.php?id=<?= (int) $p["id"] ?>" alt="">
                            <?php else: ?>
                                <span class="sem-foto">👤</span>
                            <?php endif; ?>
                            <span><?= htmlspecialchars($p["nome_usuario"]) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <button class="acao" type="submit">Criar grupo</button>
            </form>
        <?php endif; ?>
    </div>

<?php else: ?>
    <div class="card-escuro grupo-janela">
        <h3 class="grupo-topo">
            <span class="grupo-nome">👥 <?= htmlspecialchars($grupo["nome"]) ?><small><?= count($membros) ?> membros</small></span>
            <button type="button" id="btn-membros">Membros</button>
            <button type="button" id="btn-convidar">➕ Convidar</button>
            <button type="button" class="perigo" id="btn-sair">Sair</button>
        </h3>
        <div class="grupo-membros" id="grupo-membros" hidden>
            <?= implode(", ", array_map(function ($m) use ($grupo) { return htmlspecialchars($m["nome_usuario"]) . ((int) $m["id"] === (int) $grupo["criador_id"] ? " (criador)" : ""); }, $membros)) ?>
        </div>

        <div id="convite-box" class="convite-box" hidden>
            <div class="convite-topo"><strong>Convidar pessoas</strong><button type="button" id="btn-fechar-convite">✕</button></div>
            <input type="search" id="convite-busca" placeholder="Pesquisar pessoa..." autocomplete="off">
            <div id="convite-lista" class="convite-lista">
                <?php foreach ($convidaveis as $p): ?>
                    <label class="convite-pessoa" data-nome="<?= htmlspecialchars(mb_strtolower($p["nome_usuario"])) ?>">
                        <input type="checkbox" name="convidar_ids[]" value="<?= (int)$p["id"] ?>">
                        <?php if (!empty($p["foto_perfil"])): ?><img src="avatar.php?id=<?= (int)$p["id"] ?>" alt=""><?php else: ?><span class="convite-sem-foto">👤</span><?php endif; ?>
                        <span><?= htmlspecialchars($p["nome_usuario"]) ?></span>
                    </label>
                <?php endforeach; ?>
                <?php if (!$convidaveis): ?><p>Nenhuma pessoa disponível para convite.</p><?php endif; ?>
            </div>
            <button type="button" class="acao" id="btn-enviar-convites">Enviar convites</button>
        </div>

        <div id="chamada-entrada" class="chamada-entrada" hidden>
            <span id="chamada-entrada-texto">📞 Chamada ativa no grupo</span>
            <button type="button" id="btn-entrar-chamada">Entrar</button>
        </div>
        <div class="grupo-chamada-barra">
            <button type="button" id="btn-voz">📞 Voz</button>
            <button type="button" id="btn-video">🎥 Vídeo</button>
        </div>

        <div class="grupo-lista" id="grupo-lista">
            <?php foreach ($mensagens as $m): ?>
                <?php $minha = (int) $m["remetente_id"] === $eu; ?>
                <div class="bolha <?= $minha ? "minha" : "outra" ?>" data-id="<?= (int) $m["id"] ?>">
                    <?php if (!$minha): ?><span class="autor"><?= htmlspecialchars($m["nome_usuario"]) ?></span><?php endif; ?>
                    <?= nl2br(htmlspecialchars($m["conteudo"])) ?>
                    <span class="hora"><?= htmlspecialchars(substr($m["criado_em"], 11, 5)) ?></span>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="grupo-form">
            <input type="text" id="grupo-campo" placeholder="Escreva no grupo..." autocomplete="off" maxlength="2000">
            <button type="button" id="grupo-enviar">➤</button>
        </div>
    </div>

    <div class="chamada-box" id="chamada-box" hidden>
        <div class="chamada-topo">
            <strong id="chamada-titulo">Chamada do grupo</strong>
            <span id="chamada-status">Conectando...</span>
        </div>
        <div class="chamada-videos" id="chamada-videos"></div>
        <div class="chamada-controles">
            <button type="button" id="btn-mudo">🎙️ Microfone</button>
            <button type="button" id="btn-camera">📷 Câmera</button>
            <button type="button" id="btn-tela">🖥️ Compartilhar tela</button>
            <button type="button" id="btn-fechar-chamada" class="encerrar">☎️ Sair</button>
        </div>
    </div>

    <script>
    (function () {
        const grupoId = <?= (int) $grupo["id"] ?>;
        const meuId = <?= $eu ?>;
        const lista = document.getElementById("grupo-lista");
        const campo = document.getElementById("grupo-campo");
        let ultimoId = 0;
        lista.querySelectorAll(".bolha").forEach(b => { ultimoId = Math.max(ultimoId, parseInt(b.dataset.id, 10) || 0); });

        function esc(t) { const d = document.createElement("div"); d.textContent = t; return d.innerHTML; }
        function noFinal() { return lista.scrollTop + lista.clientHeight >= lista.scrollHeight - 40; }
        function rolar() { lista.scrollTop = lista.scrollHeight; }

        function adicionar(m, forcar) {
            if (lista.querySelector('[data-id="' + m.id + '"]')) return;
            const grudado = noFinal();
            const minha = parseInt(m.remetente_id, 10) === meuId;
            const div = document.createElement("div");
            div.className = "bolha " + (minha ? "minha" : "outra");
            div.dataset.id = m.id;
            div.innerHTML = (minha ? "" : '<span class="autor">' + esc(m.nome_usuario) + "</span>")
                + esc(m.conteudo).replace(/\n/g, "<br>")
                + '<span class="hora">' + esc(String(m.criado_em).substring(11, 16)) + "</span>";
            lista.appendChild(div);
            ultimoId = Math.max(ultimoId, parseInt(m.id, 10) || 0);
            if (grudado || forcar) rolar();
        }

        function enviar() {
            const texto = campo.value.trim();
            if (!texto) return;
            campo.disabled = true;
            const d = new URLSearchParams({ acao: "enviar", grupo_id: grupoId, conteudo: texto });
            fetch("grupo_api.php", { method: "POST", body: d })
                .then(r => r.json())
                .then(resp => {
                    if (resp.ok) { campo.value = ""; adicionar(resp.mensagem, true); }
                    else alert(resp.erro || "Não foi possível enviar.");
                })
                .catch(() => alert("Não foi possível enviar."))
                .finally(() => { campo.disabled = false; campo.focus(); });
        }

        function atualizar() {
            fetch("grupo_api.php?acao=atualizar&grupo=" + grupoId + "&depois_de=" + ultimoId)
                .then(r => r.json())
                .then(resp => { if (resp.ok) resp.mensagens.forEach(m => adicionar(m)); })
                .catch(() => {});
        }

        document.getElementById("grupo-enviar").addEventListener("click", enviar);
        campo.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); enviar(); } });
        document.getElementById("btn-membros").addEventListener("click", () => {
            const box = document.getElementById("grupo-membros");
            box.hidden = !box.hidden;
        });
        document.getElementById("btn-sair").addEventListener("click", () => {
            if (!confirm("Sair deste grupo?")) return;
            fetch("grupo_api.php", { method: "POST", body: new URLSearchParams({ acao: "sair", grupo_id: grupoId }) })
                .then(r => r.json())
                .then(resp => { if (resp.ok) location.href = "mensagem.php"; else alert(resp.erro || "Não foi possível sair."); })
                .catch(() => alert("Não foi possível sair."));
        });

        setInterval(atualizar, 2500);

        // ================= CHAMADAS WEBRTC DOS GRUPOS =================
        const btnVoz = document.getElementById("btn-voz");
        const btnVideo = document.getElementById("btn-video");
        const entrada = document.getElementById("chamada-entrada");
        const entradaTexto = document.getElementById("chamada-entrada-texto");
        const btnEntrar = document.getElementById("btn-entrar-chamada");
        const box = document.getElementById("chamada-box");
        const videos = document.getElementById("chamada-videos");
        const statusCall = document.getElementById("chamada-status");
        const tituloCall = document.getElementById("chamada-titulo");
        const btnMudo = document.getElementById("btn-mudo");
        const btnCamera = document.getElementById("btn-camera");
        const btnTela = document.getElementById("btn-tela");
        const btnFechar = document.getElementById("btn-fechar-chamada");
        let chamadaId = 0, chamadaTipo = "video", chamadaEntrei = false, ultimoSinal = 0;
        let streamLocal = null, compartilhandoTela = false;
        const peers = new Map();
        const participantes = new Map();
        const candidatosPendentes = new Map();
        const ICE = [{urls:"stun:stun.l.google.com:19302"},{urls:"stun:stun.cloudflare.com:3478"}];

        function chamadaPost(acao, dados={}) {
            const d = new URLSearchParams({acao, grupo_id:String(grupoId), ...Object.fromEntries(Object.entries(dados).map(([k,v])=>[k,String(v)]))});
            return fetch("grupo_api.php", {method:"POST", body:d}).then(async r=>{ const x=await r.json(); if(!x.ok) throw new Error(x.erro||"Erro"); return x; });
        }
        function chamadaGet(url) { return fetch(url).then(async r=>{const x=await r.json(); if(!x.ok) throw new Error(x.erro||"Erro"); return x;}); }
        function nomeUsuario(id){ return participantes.get(Number(id))?.nome_usuario || (Number(id)===meuId ? "Você" : "Participante"); }
        const estadosMidia = new Map();
        const analisadores = new Map();
        function avatarUrl(id){ return "avatar.php?id=" + encodeURIComponent(id); }
        function criarVideo(id, stream, local=false){
            let wrap=document.getElementById("video-part-"+id);
            if(!wrap){
                wrap=document.createElement("div"); wrap.className="video-participante"; wrap.id="video-part-"+id;
                const v=document.createElement("video"); v.autoplay=true; v.playsInline=true; if(local)v.muted=true;
                const img=document.createElement("img"); img.className="avatar-fallback"; img.src=avatarUrl(id); img.alt="Foto de perfil"; img.onerror=()=>{img.style.display="none";};
                const anel=document.createElement("span"); anel.className="falando-anel";
                const n=document.createElement("span"); n.className="nome"; n.textContent=nomeUsuario(id)+(local?" (você)":"");
                wrap.append(v,img,anel,n); videos.appendChild(wrap);
                iniciarDeteccaoVoz(id,stream);
            }
            const v=wrap.querySelector("video"); if(v.srcObject!==stream) v.srcObject=stream;
            const estado=estadosMidia.get(Number(id)) || {camera: stream?.getVideoTracks?.().some(t=>t.enabled) ?? false};
            aplicarEstadoMidia(id,estado.camera,estado.microfone);
            iniciarDeteccaoVoz(id,stream);
        }
        function aplicarEstadoMidia(id,camera,microfone){
            id=Number(id); estadosMidia.set(id,{camera:camera!==false,microfone:microfone!==false});
            const wrap=document.getElementById("video-part-"+id); if(!wrap)return;
            wrap.classList.toggle("sem-camera", camera===false || !wrap.querySelector("video")?.srcObject?.getVideoTracks?.().some(t=>t.enabled));
        }
        function iniciarDeteccaoVoz(id,stream){
            id=Number(id); if(!stream || analisadores.has(id) || !stream.getAudioTracks().length) return;
            try {
                const AC=window.AudioContext||window.webkitAudioContext; if(!AC)return;
                const ctx=new AC(), src=ctx.createMediaStreamSource(stream), analyser=ctx.createAnalyser(); analyser.fftSize=512; src.connect(analyser);
                const dados=new Uint8Array(analyser.fftSize); analisadores.set(id,{ctx,analyser,dados});
                const loop=()=>{
                    if(!analisadores.has(id)) return; analyser.getByteTimeDomainData(dados); let soma=0;
                    for(let i=0;i<dados.length;i++){const x=(dados[i]-128)/128;soma+=x*x;}
                    const rms=Math.sqrt(soma/dados.length); const ativo=rms>.035 && (estadosMidia.get(id)?.microfone!==false);
                    document.getElementById("video-part-"+id)?.classList.toggle("falando",ativo); requestAnimationFrame(loop);
                }; loop();
            } catch(e) {}
        }
        function removerVideo(id){ const a=analisadores.get(Number(id)); if(a){try{a.ctx.close();}catch(e){} analisadores.delete(Number(id));} document.getElementById("video-part-"+id)?.remove(); }
        function atualizarParticipantes(lista){
            lista.forEach(p=>participantes.set(Number(p.id),p));
            [...participantes.keys()].forEach(id=>{ if(id!==meuId && !lista.some(p=>Number(p.id)===id)) participantes.delete(id); });
        }
        async function obterStream(tipo){
            if(streamLocal) return streamLocal;
            const constraints=tipo==="voz" ? {audio:true,video:false} : {audio:true,video:{facingMode:"user",width:{ideal:1280},height:{ideal:720}}};
            streamLocal=await navigator.mediaDevices.getUserMedia(constraints);
            criarVideo(meuId,streamLocal,true);
            return streamLocal;
        }
        function pcPara(id){
            id=Number(id); if(peers.has(id)) return peers.get(id);
            const pc=new RTCPeerConnection({iceServers:ICE});
            if(streamLocal) streamLocal.getTracks().forEach(t=>pc.addTrack(t,streamLocal));
            pc.onicecandidate=e=>{ if(e.candidate) enviarSinal(id,"ice",JSON.stringify(e.candidate)); };
            pc.ontrack=e=>criarVideo(id,e.streams[0] || new MediaStream([e.track]));
            pc.onconnectionstatechange=()=>{ if(["failed","closed","disconnected"].includes(pc.connectionState)){ if(pc.connectionState!=="disconnected") removerPeer(id); } };
            peers.set(id,pc); return pc;
        }
        async function enviarSinal(destino,tipo,dados){
            if(!chamadaId) return;
            try{ await chamadaPost("sinal",{chamada_id:chamadaId,destinatario_id:destino,tipo,dados}); }catch(e){}
        }
        async function enviarEstadoMidia(destino){
            const camera=!!streamLocal?.getVideoTracks?.().some(t=>t.enabled); const microfone=!!streamLocal?.getAudioTracks?.().some(t=>t.enabled);
            await enviarSinal(destino,"media",JSON.stringify({camera,microfone}));
            aplicarEstadoMidia(meuId,camera,microfone);
        }
        async function fazerOferta(id){
            id=Number(id); if(id===meuId || meuId>id) return;
            const pc=pcPara(id); const offer=await pc.createOffer(); await pc.setLocalDescription(offer); await enviarSinal(id,"offer",JSON.stringify(pc.localDescription)); await enviarEstadoMidia(id);
        }
        async function processarSinal(s){
            const id=Number(s.remetente_id), pc=pcPara(id);
            try{
                if(s.tipo==="offer"){
                    await pc.setRemoteDescription(JSON.parse(s.dados));
                    for(const c of (candidatosPendentes.get(id)||[])) await pc.addIceCandidate(c).catch(()=>{});
                    candidatosPendentes.delete(id);
                    const answer=await pc.createAnswer(); await pc.setLocalDescription(answer); await enviarSinal(id,"answer",JSON.stringify(pc.localDescription));
                } else if(s.tipo==="answer"){
                    await pc.setRemoteDescription(JSON.parse(s.dados));
                    for(const c of (candidatosPendentes.get(id)||[])) await pc.addIceCandidate(c).catch(()=>{});
                    candidatosPendentes.delete(id);
                } else if(s.tipo==="ice"){
                    const c=JSON.parse(s.dados);
                    if(pc.remoteDescription) await pc.addIceCandidate(c).catch(()=>{}); else { if(!candidatosPendentes.has(id)) candidatosPendentes.set(id,[]); candidatosPendentes.get(id).push(c); }
                } else if(s.tipo==="media"){
                    const estado=JSON.parse(s.dados); aplicarEstadoMidia(id,estado.camera,estado.microfone);
                }
            }catch(e){}
        }
        function removerPeer(id){ const pc=peers.get(Number(id)); if(pc) pc.close(); peers.delete(Number(id)); removerVideo(Number(id)); candidatosPendentes.delete(Number(id)); }
        async function sincronizarPeers(lista){
            atualizarParticipantes(lista);
            const ids=lista.map(p=>Number(p.id)).filter(id=>id!==meuId);
            [...peers.keys()].filter(id=>!ids.includes(id)).forEach(removerPeer);
            if(!chamadaEntrei) return;
            for(const id of ids){ pcPara(id); if(meuId<id && !peers.get(id).__ofertaFeita){ peers.get(id).__ofertaFeita=true; await fazerOferta(id); } }
        }
        async function entrarChamada(cid, tipo){
            if(chamadaEntrei && Number(cid)===chamadaId) return;
            try{
                const resp=await chamadaPost("chamada_entrar",{chamada_id:cid});
                chamadaId=Number(cid); chamadaTipo=resp.tipo||tipo||"video"; chamadaEntrei=true; ultimoSinal=0;
                tituloCall.textContent=chamadaTipo==="voz"?"📞 Chamada de voz do grupo":"🎥 Chamada de vídeo do grupo";
                box.hidden=false; entrada.hidden=true; document.body.classList.add("em-chamada");
                btnCamera.hidden = chamadaTipo === "voz";
                btnTela.hidden = chamadaTipo === "voz";
                statusCall.textContent="Conectando…";
                await obterStream(chamadaTipo); await sincronizarPeers(resp.participantes||[]); for(const p of (resp.participantes||[])){ if(Number(p.id)!==meuId) enviarEstadoMidia(Number(p.id)); } statusCall.textContent="Conectado";
            }catch(e){ alert(e.message); }
        }
        async function iniciarChamada(tipo){
            if(!navigator.mediaDevices?.getUserMedia){ alert("Seu navegador não liberou câmera/microfone. Abra o Feward por HTTPS."); return; }
            try{
                const r=await chamadaPost("chamada_criar",{tipo});
                await entrarChamada(Number(r.chamada_id),r.tipo||tipo);
            }catch(e){ alert(e.message); }
        }
        async function verificarChamada(){
            try{
                const r=await chamadaGet("grupo_api.php?acao=chamada_estado&grupo="+grupoId+"&chamada_id=0");
            }catch(e){}
            // Descobre uma chamada ativa do grupo sem expor dados de outros grupos.
            fetch("grupo_api.php?acao=chamada_ativa&grupo="+grupoId).then(r=>r.json()).then(async r=>{
                if(!r.ok || !r.ativa) { if(!chamadaEntrei) entrada.hidden=true; return; }
                const cid=Number(r.chamada.id); chamadaId=chamadaId||cid;
                if(!chamadaEntrei){ entrada.hidden=false; entradaTexto.textContent=(r.chamada.tipo==="voz"?"📞":"🎥")+" Chamada ativa no grupo"; btnEntrar.onclick=()=>entrarChamada(cid,r.chamada.tipo); }
                if(chamadaEntrei && cid===chamadaId){ await sincronizarPeers(r.participantes||[]); }
            }).catch(()=>{});
        }
        async function buscarSinais(){
            if(!chamadaEntrei || !chamadaId) return;
            try{ const r=await chamadaGet("grupo_api.php?acao=sinais&grupo="+grupoId+"&chamada_id="+chamadaId+"&depois_de="+ultimoSinal); for(const s of r.sinais){ ultimoSinal=Math.max(ultimoSinal,Number(s.id)); await processarSinal(s); } }catch(e){}
        }
        async function atualizarEstadoChamada(){
            if(!chamadaEntrei || !chamadaId) return;
            try{ const r=await chamadaGet("grupo_api.php?acao=chamada_estado&grupo="+grupoId+"&chamada_id="+chamadaId); await sincronizarPeers(r.participantes||[]); if(r.chamada.status!=="ativa") sairDaChamada(false); }catch(e){}
        }
        async function sairDaChamada(enviar=true){
            const cid=chamadaId; chamadaEntrei=false; chamadaId=0; entrada.hidden=true; box.hidden=true; document.body.classList.remove("em-chamada");
            peers.forEach((pc,id)=>{pc.close(); removerVideo(id);}); peers.clear(); candidatosPendentes.clear(); participantes.clear();
            if(streamLocal){ streamLocal.getTracks().forEach(t=>t.stop()); streamLocal=null; }
            if(enviar && cid){ try{ await chamadaPost("chamada_sair",{chamada_id:cid}); }catch(e){} }
        }
        btnVoz.onclick=()=>iniciarChamada("voz");
        btnVideo.onclick=()=>iniciarChamada("video");
        btnFechar.onclick=()=>sairDaChamada(true);
        btnMudo.onclick=()=>{ const t=streamLocal?.getAudioTracks()[0]; if(!t)return; t.enabled=!t.enabled; btnMudo.textContent=t.enabled?"🎙️ Microfone":"🔇 Microfone"; for(const id of peers.keys()) enviarEstadoMidia(id); aplicarEstadoMidia(meuId,!!streamLocal?.getVideoTracks?.().some(t=>t.enabled),t.enabled); };
        btnCamera.onclick=()=>{ const t=streamLocal?.getVideoTracks()[0]; if(!t)return; t.enabled=!t.enabled; btnCamera.textContent=t.enabled?"📷 Câmera":"🚫 Câmera"; aplicarEstadoMidia(meuId,t.enabled,!!streamLocal?.getAudioTracks?.().some(x=>x.enabled)); for(const id of peers.keys()) enviarEstadoMidia(id); };
        btnTela.onclick=async()=>{
            if(!chamadaEntrei || chamadaTipo!=="video") return;
            try{
                if(!compartilhandoTela){
                    const tela=await navigator.mediaDevices.getDisplayMedia({video:true}); const track=tela.getVideoTracks()[0];
                    for(const pc of peers.values()){ const sender=pc.getSenders().find(s=>s.track&&s.track.kind==="video"); if(sender) await sender.replaceTrack(track); }
                    const old=streamLocal?.getVideoTracks()[0]; if(old) old.enabled=false;
                    criarVideo(meuId,new MediaStream([track]),true); compartilhandoTela=true; btnTela.textContent="🛑 Parar tela";
                    track.onended=()=>pararTela();
                } else await pararTela();
            }catch(e){ if(e.name!=="NotAllowedError") alert("Não foi possível compartilhar a tela."); }
        };
        async function pararTela(){
            if(!compartilhandoTela) return; compartilhandoTela=false; btnTela.textContent="🖥️ Compartilhar tela";
            const cam=streamLocal?.getVideoTracks()[0]; if(!cam) return;
            for(const pc of peers.values()){ const sender=pc.getSenders().find(s=>s.track&&s.track.kind==="video"); if(sender) await sender.replaceTrack(cam); }
            cam.enabled=true; criarVideo(meuId,streamLocal,true);
        }

        // Convites de membros
        const conviteBox=document.getElementById("convite-box"), conviteLista=document.getElementById("convite-lista"), conviteBusca=document.getElementById("convite-busca");
        document.getElementById("btn-convidar").onclick=()=>{conviteBox.hidden=false; conviteBusca.focus();};
        document.getElementById("btn-fechar-convite").onclick=()=>{conviteBox.hidden=true;};
        conviteBusca.addEventListener("input",()=>{const q=conviteBusca.value.trim().toLowerCase(); conviteLista.querySelectorAll(".convite-pessoa").forEach(x=>x.style.display=x.dataset.nome.includes(q)?"flex":"none");});
        document.getElementById("btn-enviar-convites").onclick=async()=>{
            const ids=[...conviteLista.querySelectorAll('input[name="convidar_ids[]"]:checked')].map(x=>x.value);
            if(!ids.length){alert("Escolha pelo menos uma pessoa.");return;}
            try{const r=await chamadaPost("convidar",{usuario_ids:JSON.stringify(ids)}); alert(r.mensagem||"Convites enviados."); conviteLista.querySelectorAll('input[name="convidar_ids[]"]').forEach(x=>x.checked=false); conviteBox.hidden=true;}catch(e){alert(e.message);}
        };
        setInterval(buscarSinais,900); setInterval(verificarChamada,2500); setInterval(atualizarEstadoChamada,3500); verificarChamada();
    })();
    </script>
<?php endif; ?>
</div>

</body>
</html>
