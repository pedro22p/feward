<?php
$pagina_ativa = $pagina_ativa ?? '';
function navAtivo($pagina, $atual) {
    return $pagina === $atual ? ' ativo' : '';
}
?>
<header class="mobile-header">
    <div class="mobile-esq">
        <button class="menu-toggle" type="button" aria-label="Abrir menu" onclick="document.body.classList.toggle('menu-aberto')">☰</button>
        <div class="mobile-logo">FEWARD</div>
    </div>
    <a class="mobile-bell" href="notificacao.php" aria-label="Notificações">🔔</a>
</header>

<div class="menu-overlay" onclick="document.body.classList.remove('menu-aberto')"></div>

<aside class="sidebar">
    <div class="sidebar-top">
        <div class="logo"><img class="logo-few" src="img/few-icone.png" alt="FEW"></div>
        <button class="menu-close" type="button" aria-label="Fechar menu" onclick="document.body.classList.remove('menu-aberto')">×</button>
    </div>

    <a class="nav-btn<?= navAtivo('inicio', $pagina_ativa) ?>" href="inicio.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg><span>Início</span></a>
    <a class="nav-btn<?= navAtivo('comunidade', $pagina_ativa) ?>" href="comunidade.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg><span>Comunidade</span></a>
    <a class="nav-btn<?= navAtivo('explorar', $pagina_ativa) ?>" href="explorar.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg><span>Explorar</span></a>
    <a class="nav-btn<?= navAtivo('videos', $pagina_ativa) ?>" href="video.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/></svg><span>Vídeos</span></a>
    <a class="nav-btn<?= navAtivo('reels', $pagina_ativa) ?>" href="reels.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 1H7a2 2 0 00-2 2v18a2 2 0 002 2h10a2 2 0 002-2V3a2 2 0 00-2-2zm-7 14V8l6 3.5-6 3.5z"/></svg><span>Reels</span></a>
    <a class="nav-btn<?= navAtivo('mensagem', $pagina_ativa) ?>" href="mensagem.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg><span>Mensagens</span></a>
    <a class="nav-btn<?= navAtivo('notificacao', $pagina_ativa) ?>" href="notificacao.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/></svg><span>Notificações</span></a>
    <a class="nav-btn<?= navAtivo('salvos', $pagina_ativa) ?>" href="salvos.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg><span>Salvos</span></a>
    <a class="nav-btn<?= navAtivo('perfil', $pagina_ativa) ?>" href="perfil.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg><span>Perfil</span></a>
    <a class="nav-btn<?= navAtivo('configuracao', $pagina_ativa) ?>" href="configuracao.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 00.12-.61l-1.92-3.32a.488.488 0 00-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 00-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 00-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/></svg><span>Configurações</span></a>
    <a class="nav-btn sair" href="logout.php"><svg class="nav-ico" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z"/></svg><span>Sair</span></a>

    <div class="sidebar-footer">Feward<br><small>Compartilhe. Crie. Conecte.</small></div>
</aside>

<!-- V45: barra inferior do celular estilo Instagram (5 ícones, avatar no fim) -->
<nav class="insta-nav" aria-label="Navegação mobile">
    <a class="insta-item<?= $pagina_ativa === 'inicio' ? ' ativo' : '' ?>" href="inicio.php" aria-label="Início">
        <?php if ($pagina_ativa === 'inicio'): ?><svg width="26" height="26" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10.5V20h5.5v-6h5v6H20v-9.5L12 4z"/></svg><?php else: ?><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10.5V20h5.5v-6h5v6H20v-9.5L12 4z"/></svg><?php endif; ?>
    </a>
    <a class="insta-item<?= in_array($pagina_ativa, ['reels','videos']) ? ' ativo' : '' ?>" href="reels.php" aria-label="Reels">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5"/><path d="M10 8.5v7l6-3.5z" fill="currentColor"/></svg>
    </a>
    <a class="insta-item<?= $pagina_ativa === 'mensagem' ? ' ativo' : '' ?>" href="mensagem.php" aria-label="Mensagens">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 4 3 10.5l7 3 3 7z"/><path d="m10 13.5 11-9.5"/></svg>
    </a>
    <a class="insta-item<?= $pagina_ativa === 'explorar' ? ' ativo' : '' ?>" href="explorar.php" aria-label="Explorar">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>
    </a>
    <a class="insta-item<?= $pagina_ativa === 'perfil' ? ' ativo' : '' ?>" href="perfil.php" aria-label="Perfil">
        <?php if (!empty($usuario_logado["foto_perfil"])): ?>
            <img class="insta-avatar" src="avatar.php" alt="" style="object-position: <?= htmlspecialchars($usuario_logado["foto_perfil_pos"] ?? "50% 50%") ?>;">
        <?php else: ?>
            <span class="insta-avatar vazio">👤</span>
        <?php endif; ?>
    </a>
</nav>

<script src="ligacao.js?v=48" defer></script>
<script>
// V47: gaveta arrastável no celular. Arraste o menu pra esquerda pra fechar
// (ele acompanha o dedo) e deslize da borda esquerda da tela pra abrir.
(function () {
    var side = document.querySelector('.sidebar');
    if (!side) return;
    var body = document.body, x0 = null, y0 = 0, dx = 0, modo = null, trava = false;
    function mobile() { return window.innerWidth <= 768; }
    function largura() { return side.offsetWidth || 300; }
    document.addEventListener('touchstart', function (e) {
        if (!mobile() || e.touches.length !== 1) return;
        var t = e.touches[0], aberto = body.classList.contains('menu-aberto');
        if (aberto && (side.contains(e.target) || e.target.classList.contains('menu-overlay'))) modo = 'fechar';
        else if (!aberto && t.clientX < 22) modo = 'abrir';
        else { modo = null; return; }
        x0 = t.clientX; y0 = t.clientY; dx = 0; trava = false;
    }, { passive: true });
    document.addEventListener('touchmove', function (e) {
        if (!modo) return;
        var t = e.touches[0]; dx = t.clientX - x0;
        if (!trava) {
            if (Math.abs(t.clientY - y0) > Math.abs(dx) && Math.abs(t.clientY - y0) > 8) { modo = null; return; }
            if (Math.abs(dx) > 8) trava = true; else return;
        }
        side.style.transition = 'none';
        var w = largura(), pos = modo === 'fechar' ? Math.max(-w, Math.min(0, dx)) : Math.min(0, -w + Math.max(0, dx));
        side.style.transform = 'translateX(' + pos + 'px)';
        if (modo === 'abrir') body.classList.add('menu-arrastando');
    }, { passive: true });
    document.addEventListener('touchend', function () {
        if (!modo) return;
        var m = modo; modo = null;
        side.style.transition = ''; side.style.transform = '';
        body.classList.remove('menu-arrastando');
        if (!trava) return;
        if (m === 'fechar' && dx < -70) body.classList.remove('menu-aberto');
        if (m === 'abrir' && dx > 70) body.classList.add('menu-aberto');
    }, { passive: true });
})();

// Batida de presença: avisa o servidor que o app segue aberto, pra manter a
// conta como "online" e marcar como entregues as mensagens que estavam
// esperando eu aparecer. Roda em toda página logada (nav.php é incluído
// em todas elas).
(function () {
    function bater() {
        fetch("status_api.php?acao=ping", { method: "POST" }).catch(() => {});
    }
    bater();
    setInterval(bater, 20000);
    document.addEventListener("visibilitychange", function () {
        if (document.visibilityState === "visible") bater();
    });
})();
</script>
