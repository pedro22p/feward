<?php
require_once "conexao.php";
require_once "status_util.php";
require_once "seguir_util.php";
session_start();

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM contas WHERE id = ?");
$stmt->execute([$_SESSION["usuario_id"]]);
$usuario_logado = $stmt->fetch();

if (!$usuario_logado) {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Toda página logada conta como "presença": marca o último acesso agora.
// (avatar.php/midia.php de propósito não passam por auth.php, então essa
// atualização não se multiplica por cada avatar/imagem mostrado na página.)
$pdo->prepare("UPDATE contas SET ultimo_acesso = UTC_TIMESTAMP() WHERE id = ?")
    ->execute([$usuario_logado["id"]]);
$usuario_logado["ultimo_acesso"] = gmdate("Y-m-d H:i:s");
?>