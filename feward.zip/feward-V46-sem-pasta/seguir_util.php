<?php
// V30: regra "só interage com quem eu sigo".
// Devolve true se $eu segue $outro (pedido já aceito). Você sempre "segue" você mesmo.
function feward_sigo(PDO $pdo, int $eu, int $outro): bool {
    if ($eu === $outro) return true;
    $stmt = $pdo->prepare("SELECT 1 FROM amizades WHERE usuario_id = ? AND amigo_id = ? AND status = 'aceito'");
    $stmt->execute([$eu, $outro]);
    return (bool) $stmt->fetchColumn();
}

// IDs de todas as contas que $eu segue (pedido aceito), como [id => true].
function feward_ids_seguidos(PDO $pdo, int $eu): array {
    $stmt = $pdo->prepare("SELECT amigo_id FROM amizades WHERE usuario_id = ? AND status = 'aceito'");
    $stmt->execute([$eu]);
    return array_fill_keys(array_map("intval", $stmt->fetchAll(PDO::FETCH_COLUMN)), true);
}

// V30: só acessa um story (ver, curtir, comentar) quem é o dono ou quem segue o dono.
function feward_pode_ver_story(PDO $pdo, int $story_id, int $eu): bool {
    $stmt = $pdo->prepare("SELECT usuario_id FROM stories WHERE id = ?");
    $stmt->execute([$story_id]);
    $dono = $stmt->fetchColumn();
    return $dono !== false && feward_sigo($pdo, $eu, (int) $dono);
}
