-- Feward V48 - ligações 1 a 1 (voz/vídeo) pelo chat de Mensagens
CREATE TABLE IF NOT EXISTS ligacoes (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    de_id INT UNSIGNED NOT NULL,
    para_id INT UNSIGNED NOT NULL,
    tipo ENUM('voz','video') NOT NULL DEFAULT 'voz',
    status ENUM('chamando','ativa','recusada','encerrada','perdida') NOT NULL DEFAULT 'chamando',
    criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atendida_em TIMESTAMP NULL DEFAULT NULL,
    encerrada_em TIMESTAMP NULL DEFAULT NULL,
    batida_em TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_lig_para (para_id, status),
    KEY idx_lig_de (de_id, status),
    FOREIGN KEY (de_id) REFERENCES contas(id) ON DELETE CASCADE,
    FOREIGN KEY (para_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ligacao_sinais (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ligacao_id BIGINT UNSIGNED NOT NULL,
    remetente_id INT UNSIGNED NOT NULL,
    destinatario_id INT UNSIGNED NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    dados LONGTEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_ls_destino (ligacao_id, destinatario_id, id),
    FOREIGN KEY (ligacao_id) REFERENCES ligacoes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
