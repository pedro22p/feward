-- Feward V29 - status online/offline, "visto por último", status de mensagem
-- (enviada/entregue/visualizada) e mensagens de áudio.
-- Execute depois de melhorias_stories_v28.sql (ou a última migração já rodada).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.

-- Quando a conta foi vista pela última vez (atualizado a cada página aberta
-- e a cada "batida de presença" enquanto o app fica aberto no navegador).
ALTER TABLE contas ADD COLUMN IF NOT EXISTS ultimo_acesso TIMESTAMP NULL DEFAULT NULL;

-- Status "entregue" (chegou no aparelho do destinatário, mesmo sem ele ter
-- aberto a conversa ainda) e o horário de cada mudança de status, usados
-- para o outro lado do chat perceber a atualização durante o polling.
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS entregue BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS entregue_em TIMESTAMP NULL DEFAULT NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS lida_em TIMESTAMP NULL DEFAULT NULL;

-- Mensagens de áudio: tipo da mensagem, arquivo gravado e duração (segundos).
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS tipo ENUM('texto','audio') NOT NULL DEFAULT 'texto';
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS audio VARCHAR(255) NULL DEFAULT NULL;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS duracao_audio SMALLINT UNSIGNED NULL DEFAULT NULL;

-- conteudo pode ficar vazio numa mensagem de áudio (era NOT NULL sem default).
ALTER TABLE mensagens MODIFY COLUMN conteudo TEXT NULL;
