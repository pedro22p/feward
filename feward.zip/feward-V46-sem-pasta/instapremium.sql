-- Feward "InstaPremium de graça"
ALTER TABLE stories ADD COLUMN duracao_horas SMALLINT UNSIGNED NOT NULL DEFAULT 24;
ALTER TABLE contas ADD COLUMN modo_fantasma TINYINT(1) NOT NULL DEFAULT 0;
