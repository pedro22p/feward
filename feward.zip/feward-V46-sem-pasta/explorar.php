<?php
require_once "auth.php";

$busca = trim($_GET["q"] ?? "");

if ($busca !== "") {
    $stmt = $pdo->prepare("SELECT * FROM posts WHERE imagem IS NOT NULL AND conteudo LIKE ? ORDER BY criado_em DESC LIMIT 30");
    $stmt->execute(["%$busca%"]);

    $stmt_com = $pdo->prepare("
        SELECT comunidades.*,
            (SELECT COUNT(*) FROM comunidade_membros WHERE comunidade_membros.comunidade_id = comunidades.id) AS total_membros
        FROM comunidades
        WHERE nome LIKE ? OR descricao LIKE ?
        ORDER BY nome
        LIMIT 12
    ");
    $stmt_com->execute(["%$busca%", "%$busca%"]);
    $comunidades_encontradas = $stmt_com->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM posts WHERE imagem IS NOT NULL ORDER BY criado_em DESC LIMIT 30");
    $comunidades_encontradas = [];
}
$posts = $stmt->fetchAll();

$pagina_ativa = "explorar";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore conteúdos e imagens no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Explorar - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .grade-explorar { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
        .grade-explorar img { width: 100%; height: 160px; object-fit: cover; border-radius: 10px; }
        .busca-form { margin-bottom: 20px; }
        .grade-comunidades { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .card-comunidade { background: linear-gradient(160deg, #060030, #1a1a70); border-radius: 15px; padding: 20px; text-align: center; text-decoration: none; color: inherit; display: block; }
        .card-comunidade h3 { margin: 0 0 8px; font-size: 20px; }
        .card-comunidade p { margin: 0 0 10px; font-size: 13px; color: #ccc; min-height: 18px; }
        .card-comunidade .contagem { font-size: 12px; color: #9aa0e0; }
        .subtitulo-secao { font-size: 16px; color: #ccc; margin: 0 0 12px; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Explorar</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <form class="busca-form" method="GET">
        <input type="text" name="q" placeholder="Pesquisar..." value="<?= htmlspecialchars($busca) ?>">
    </form>

    <?php if ($busca !== "" && $comunidades_encontradas): ?>
        <h2 class="subtitulo-secao">Comunidades</h2>
        <div class="grade-comunidades">
            <?php foreach ($comunidades_encontradas as $c): ?>
                <a class="card-comunidade" href="comunidade-ver.php?id=<?= (int) $c["id"] ?>">
                    <h3><?= htmlspecialchars($c["nome"]) ?></h3>
                    <p><?= htmlspecialchars($c["descricao"] ?? "") ?></p>
                    <span class="contagem"><?= (int) $c["total_membros"] ?> membro(s)</span>
                </a>
            <?php endforeach; ?>
        </div>
        <h2 class="subtitulo-secao">Posts</h2>
    <?php endif; ?>

    <div class="grade-explorar">
        <?php foreach ($posts as $p): ?>
            <?php $explorar_img_src = "midia.php?pasta=posts&arquivo=" . urlencode($p["imagem"]); ?>
            <img src="<?= htmlspecialchars($explorar_img_src) ?>" alt="post" onclick="abrirLightbox(this.src)">
        <?php endforeach; ?>
        <?php if (empty($posts) && ($busca === "" || empty($comunidades_encontradas))): ?>
            <p>Nada encontrado.</p>
        <?php endif; ?>
    </div>
</div>

<div class="lightbox-overlay" id="lightbox-overlay" onclick="fecharLightbox()">
    <button class="lightbox-fechar" type="button" onclick="fecharLightbox()">&times;</button>
    <img id="lightbox-img" src="" alt="Imagem ampliada" onclick="event.stopPropagation()">
</div>
<script src="midia.js"></script>

</body>
</html>
