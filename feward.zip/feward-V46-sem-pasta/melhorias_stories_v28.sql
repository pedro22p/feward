-- Feward V28 - sticker e música de fundo em stories
-- Execute depois de story_curtidas_comentarios.sql (ou a última migração que você já rodou).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.

ALTER TABLE stories
    ADD COLUMN musica VARCHAR(255) DEFAULT NULL,
    ADD COLUMN stickers TEXT DEFAULT NULL;
