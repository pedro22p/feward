<?php
require_once "conexao.php";
session_start();

if (isset($_SESSION["usuario_id"])) {
    header("Location: inicio.php");
    exit;
}

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");

    // A resposta é igual mesmo quando o e-mail não existe.
    // Isso evita revelar quais contas estão cadastradas.
    $mensagem = "Se esse e-mail estiver cadastrado, enviaremos um link para redefinir sua senha. O link vale por 1 hora.";

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
            $stmt = $pdo->prepare("SELECT id, nome_usuario, email FROM contas WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $conta = $stmt->fetch();

            if ($conta) {
                // Remove tokens anteriores dessa conta.
                $pdo->prepare("DELETE FROM recuperacao_senha WHERE usuario_id = ? OR expira_em < NOW()")
                    ->execute([$conta["id"]]);

                // O token real vai no e-mail; apenas o hash é salvo no banco.
                $token = bin2hex(random_bytes(32));
                $tokenHash = hash("sha256", $token);
                $expira = date("Y-m-d H:i:s", time() + 3600);

                $stmt = $pdo->prepare(
                    "INSERT INTO recuperacao_senha (usuario_id, token_hash, expira_em) VALUES (?, ?, ?)"
                );
                $stmt->execute([$conta["id"], $tokenHash, $expira]);

                // Em produção, troque APP_URL pela URL pública do Feward.
                $appUrl = defined("FEWARD_URL") ? FEWARD_URL : ((isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off") ? "https://" : "http://") . ($_SERVER["HTTP_HOST"] ?? "localhost") . rtrim(dirname($_SERVER["SCRIPT_NAME"] ?? "/"), "/");
                $link = rtrim($appUrl, "/") . "/redefinir_senha.php?token=" . urlencode($token);

                $assunto = "Redefinição de senha - Feward";
                $nome = $conta["nome_usuario"];
                $corpo = "Olá, {$nome}!\n\nRecebemos uma solicitação para redefinir a senha da sua conta no Feward.\n\nAbra este link para escolher uma nova senha:\n{$link}\n\nEste link expira em 1 hora e só pode ser usado uma vez.\n\nSe você não solicitou isso, ignore este e-mail.\n\nEquipe Feward";
                $headers = "From: Feward <noreply@feward.local>\r\n" .
                           "Content-Type: text/plain; charset=UTF-8\r\n";

                // mail() depende da configuração de e-mail do servidor.
                @mail($conta["email"], $assunto, $corpo, $headers);
            }
        } catch (PDOException $e) {
            // Mantém a mensagem genérica para não expor informações internas.
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0b1050">
    <title>Esqueci minha senha - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <style>
        *{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:Arial,Helvetica,sans-serif}
        body{min-height:100vh;background:linear-gradient(rgba(5,8,35,.45),rgba(5,8,35,.65)),url("img/fundo.jpeg") center/cover fixed;color:#fff;display:flex;flex-direction:column;align-items:center;padding:35px 16px}
        .logo img{max-width:180px;max-height:120px;object-fit:contain}.caixa{width:100%;max-width:420px;margin-top:30px;padding:28px 22px;background:rgba(0,0,0,.88);border-radius:18px;box-shadow:0 15px 45px rgba(0,0,0,.4)}
        h1{text-align:center;font-size:27px;margin:0 0 12px}.descricao{text-align:center;color:#ccc;line-height:1.5;margin:0 0 22px}.mensagem{background:rgba(40,180,100,.15);border:1px solid rgba(100,220,150,.35);padding:12px;border-radius:10px;line-height:1.45;margin-bottom:18px}
        label{display:block;margin-bottom:7px;color:#ddd;font-size:14px}input{width:100%;min-height:50px;padding:14px 15px;border:1px solid transparent;border-radius:10px;font-size:16px;outline:none}input:focus{border-color:#2844e2;box-shadow:0 0 0 3px rgba(40,68,226,.2)}button{width:100%;min-height:50px;margin-top:15px;background:#2844e2;border:0;border-radius:10px;color:#fff;font-size:16px;font-weight:bold;cursor:pointer}.voltar{display:block;text-align:center;margin-top:15px;color:#9cacff;text-decoration:none;font-size:14px}
    </style>
</head>
<body>
    <div class="logo"><img src="img/logo.png" alt="Logo do Feward"></div>
    <main class="caixa">
        <h1>Esqueci minha senha</h1>
        <p class="descricao">Digite o e-mail da sua conta. Se ele estiver cadastrado, você receberá um link para criar uma nova senha.</p>
        <?php if ($mensagem): ?><div class="mensagem" role="status"><?= htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8") ?></div><?php endif; ?>
        <form method="POST" autocomplete="on">
            <label for="email">E-mail</label>
            <input id="email" type="email" name="email" placeholder="Digite seu e-mail" autocomplete="email" required value="<?= htmlspecialchars($_POST["email"] ?? "", ENT_QUOTES, "UTF-8") ?>">
            <button type="submit">Enviar link de redefinição</button>
        </form>
        <a class="voltar" href="login.php">Voltar para o login</a>
    </main>
</body>
</html>
