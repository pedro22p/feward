-- Feward V30 - grupos de mensagem
-- Execute depois de status_mensagens_v29.sql (ou a última migração já rodada).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.
-- (Seguir-para-mandar-mensagem e seguir-para-ver-story não precisam de SQL novo:
--  usam a tabela amizades que já existe. Visualizações de story usam story_visualizacoes.)

CREATE TABLE IF NOT EXISTS grupos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(60) NOT NULL,
    criador_id INT UNSIGNED NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    FOREIGN KEY (criador_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS grupo_membros (
    grupo_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    entrou_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (grupo_id, usuario_id),
    KEY idx_grupo_membros_usuario (usuario_id),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS grupo_mensagens (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    grupo_id INT UNSIGNED NOT NULL,
    remetente_id INT UNSIGNED NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_grupo_mensagens_grupo (grupo_id, id),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (remetente_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
