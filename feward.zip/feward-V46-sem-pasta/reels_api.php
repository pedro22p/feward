<?php
// V38 - API dos reels (JSON). Só para quem está logado (auth.php).
require_once "auth.php";
require_once "moderacao.php";

header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");

function resp($dados, int $codigo = 200): void {
    http_response_code($codigo);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

$eu = (int) $usuario_logado["id"];
$acao = $_GET["acao"] ?? ($_POST["acao"] ?? "");
$post = $_SERVER["REQUEST_METHOD"] === "POST";

try {
    // ---- lista de reels (mais novos primeiro; "depois" = último id já carregado)
    if ($acao === "lista") {
        $depois = (int) ($_GET["depois"] ?? 0);
        $inicial = (int) ($_GET["inicial"] ?? 0); // abrir direto num reel específico
        $limite = 5;

        $sql = "SELECT v.id, v.titulo, v.arquivo, v.usuario_id, c.nome_usuario, c.foto_perfil, c.foto_perfil_pos,
                    (SELECT COUNT(*) FROM curtidas_video cv WHERE cv.video_id = v.id) AS curtidas,
                    (SELECT COUNT(*) FROM curtidas_video cv WHERE cv.video_id = v.id AND cv.usuario_id = :eu) AS curti,
                    (SELECT COUNT(*) FROM comentarios_video cm WHERE cm.video_id = v.id) AS comentarios
                FROM videos v
                JOIN contas c ON c.id = v.usuario_id
                WHERE v.tipo = 'curto' AND v.arquivo IS NOT NULL AND v.arquivo <> ''";
        $params = [":eu" => $eu];
        if ($inicial > 0 && $depois === 0) {
            $sql .= " AND v.id <= :ini";
            $params[":ini"] = $inicial;
        } elseif ($depois > 0) {
            $sql .= " AND v.id < :dep";
            $params[":dep"] = $depois;
        }
        $sql .= " ORDER BY v.id DESC LIMIT " . $limite;

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $itens = [];
        foreach ($stmt->fetchAll() as $v) {
            $itens[] = [
                "id" => (int) $v["id"],
                "titulo" => $v["titulo"],
                "src" => "midia.php?pasta=videos&arquivo=" . urlencode($v["arquivo"]),
                "autor_id" => (int) $v["usuario_id"],
                "autor" => $v["nome_usuario"],
                "tem_foto" => !empty($v["foto_perfil"]),
                "foto_pos" => $v["foto_perfil_pos"] ?: "50% 50%",
                "curtidas" => (int) $v["curtidas"],
                "curti" => (int) $v["curti"] > 0,
                "comentarios" => (int) $v["comentarios"],
                "meu" => (int) $v["usuario_id"] === $eu,
            ];
        }
        resp(["itens" => $itens, "fim" => count($itens) < $limite]);
    }

    // ---- dados de um reel (para o cartão dentro da conversa)
    if ($acao === "info") {
        $vid = (int) ($_GET["video_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT v.id, v.titulo, v.arquivo, v.usuario_id, c.nome_usuario, c.foto_perfil, c.foto_perfil_pos FROM videos v JOIN contas c ON c.id = v.usuario_id WHERE v.id = ? AND v.arquivo IS NOT NULL AND v.arquivo <> ''");
        $stmt->execute([$vid]);
        $v = $stmt->fetch();
        if (!$v) resp(["existe" => false]);
        resp(["existe" => true, "id" => (int) $v["id"], "titulo" => $v["titulo"], "autor" => $v["nome_usuario"], "autor_id" => (int) $v["usuario_id"], "tem_foto" => !empty($v["foto_perfil"]), "foto_pos" => $v["foto_perfil_pos"] ?: "50% 50%",
              "src" => "midia.php?pasta=videos&arquivo=" . urlencode($v["arquivo"])]);
    }

    // ---- pessoas que eu sigo (para enviar o reel por mensagem)
    if ($acao === "seguidos") {
        $stmt = $pdo->prepare(
            "SELECT c.id, c.nome_usuario, c.foto_perfil, c.foto_perfil_pos
             FROM amizades a JOIN contas c ON c.id = a.amigo_id
             WHERE a.usuario_id = ? AND a.status = 'aceito' AND c.id <> ?
             ORDER BY c.nome_usuario ASC LIMIT 300"
        );
        $stmt->execute([$eu, $eu]);
        $lista = [];
        foreach ($stmt->fetchAll() as $c) {
            $lista[] = ["id" => (int) $c["id"], "nome" => $c["nome_usuario"], "tem_foto" => !empty($c["foto_perfil"]), "foto_pos" => $c["foto_perfil_pos"] ?: "50% 50%"];
        }
        resp(["pessoas" => $lista]);
    }

    // ---- curtir / descurtir
    if ($acao === "curtir" && $post) {
        $vid = (int) ($_POST["video_id"] ?? 0);
        $existe = $pdo->prepare("SELECT 1 FROM videos WHERE id = ? AND tipo = 'curto'");
        $existe->execute([$vid]);
        if (!$existe->fetchColumn()) resp(["erro" => "Reel não encontrado."], 404);

        $jaCurti = $pdo->prepare("SELECT id FROM curtidas_video WHERE video_id = ? AND usuario_id = ?");
        $jaCurti->execute([$vid, $eu]);
        if ($jaCurti->fetchColumn()) {
            $pdo->prepare("DELETE FROM curtidas_video WHERE video_id = ? AND usuario_id = ?")->execute([$vid, $eu]);
            $curti = false;
        } else {
            $pdo->prepare("INSERT IGNORE INTO curtidas_video (video_id, usuario_id) VALUES (?, ?)")->execute([$vid, $eu]);
            $curti = true;
        }
        $n = $pdo->prepare("SELECT COUNT(*) FROM curtidas_video WHERE video_id = ?");
        $n->execute([$vid]);
        resp(["curti" => $curti, "curtidas" => (int) $n->fetchColumn()]);
    }

    // ---- comentários de um reel
    if ($acao === "comentarios") {
        $vid = (int) ($_GET["video_id"] ?? 0);
        $stmt = $pdo->prepare(
            "SELECT cm.conteudo, cm.criado_em, c.id AS autor_id, c.nome_usuario, c.foto_perfil, c.foto_perfil_pos
             FROM comentarios_video cm JOIN contas c ON c.id = cm.usuario_id
             WHERE cm.video_id = ? ORDER BY cm.criado_em ASC LIMIT 200"
        );
        $stmt->execute([$vid]);
        $lista = [];
        foreach ($stmt->fetchAll() as $c) {
            $lista[] = [
                "autor_id" => (int) $c["autor_id"],
                "autor" => $c["nome_usuario"],
                "tem_foto" => !empty($c["foto_perfil"]),
                "foto_pos" => $c["foto_perfil_pos"] ?: "50% 50%",
                "texto" => $c["conteudo"],
            ];
        }
        resp(["comentarios" => $lista]);
    }

    // ---- comentar
    if ($acao === "comentar" && $post) {
        $vid = (int) ($_POST["video_id"] ?? 0);
        $texto = trim($_POST["texto"] ?? "");
        if ($texto === "") resp(["erro" => "Escreva um comentário."], 400);
        if (mb_strlen($texto) > 500) resp(["erro" => "O comentário pode ter no máximo 500 caracteres."], 400);
        if (bloquearConteudo($texto)) resp(["erro" => "Comentário bloqueado por conter palavras proibidas."], 400);

        $existe = $pdo->prepare("SELECT 1 FROM videos WHERE id = ? AND tipo = 'curto'");
        $existe->execute([$vid]);
        if (!$existe->fetchColumn()) resp(["erro" => "Reel não encontrado."], 404);

        $pdo->prepare("INSERT INTO comentarios_video (video_id, usuario_id, conteudo) VALUES (?, ?, ?)")
            ->execute([$vid, $eu, $texto]);
        $n = $pdo->prepare("SELECT COUNT(*) FROM comentarios_video WHERE video_id = ?");
        $n->execute([$vid]);
        resp(["ok" => true, "comentarios" => (int) $n->fetchColumn()]);
    }

    // ---- excluir (só o dono)
    if ($acao === "excluir" && $post) {
        $vid = (int) ($_POST["video_id"] ?? 0);
        $stmt = $pdo->prepare("SELECT arquivo FROM videos WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$vid, $eu]);
        $v = $stmt->fetch();
        if (!$v) resp(["erro" => "Você só pode excluir os seus reels."], 403);

        $pdo->prepare("DELETE FROM comentarios_video WHERE video_id = ?")->execute([$vid]);
        $pdo->prepare("DELETE FROM curtidas_video WHERE video_id = ?")->execute([$vid]);
        $pdo->prepare("DELETE FROM videos WHERE id = ?")->execute([$vid]);
        if (!empty($v["arquivo"]) && preg_match('#^[A-Za-z0-9._-]+$#', $v["arquivo"])) {
            $f = __DIR__ . "/uploads/videos/" . $v["arquivo"];
            if (is_file($f)) @unlink($f);
        }
        resp(["ok" => true]);
    }

    resp(["erro" => "Ação inválida."], 400);
} catch (PDOException $e) {
    resp(["erro" => "Erro no banco de dados. Você rodou o reels.sql?"], 500);
}
