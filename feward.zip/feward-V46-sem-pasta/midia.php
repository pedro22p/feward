<?php
// Serve arquivos de uploads/posts e uploads/videos SOMENTE para quem está logado.
// Checagem leve (só sessão, sem consultar o banco nem abrir conexão): midia.php
// é chamado uma vez por imagem/vídeo mostrado, então cada consulta extra aqui
// se multiplica pela quantidade de mídia na página.
session_start();

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(404);
    exit;
}

$pasta = $_GET["pasta"] ?? "";
$arquivo = $_GET["arquivo"] ?? "";

$pastas_permitidas = ["posts", "videos", "stories"];
if (!in_array($pasta, $pastas_permitidas, true)) {
    http_response_code(404);
    exit;
}

// Só aceita nomes de arquivo "limpos" (sem ../ nem caminhos).
if (!preg_match('#^[A-Za-z0-9._-]+$#', $arquivo)) {
    http_response_code(404);
    exit;
}

$caminho = __DIR__ . "/uploads/" . $pasta . "/" . $arquivo;

if (!is_file($caminho) || !is_readable($caminho)) {
    http_response_code(404);
    exit;
}

// V30: arquivo de story (foto/vídeo/música) só pro dono e pra quem segue o dono.
// (Só stories consultam o banco; posts e vídeos continuam com checagem leve.)
if ($pasta === "stories") {
    require_once __DIR__ . "/conexao.php";
    require_once __DIR__ . "/seguir_util.php";
    try {
        $q = $pdo->prepare("SELECT usuario_id FROM stories WHERE arquivo = ? OR musica = ? LIMIT 1");
        $q->execute([$arquivo, $arquivo]);
    } catch (PDOException $e) {
        // banco sem a coluna musica (falta melhorias_stories_v28.sql)
        $q = $pdo->prepare("SELECT usuario_id FROM stories WHERE arquivo = ? LIMIT 1");
        $q->execute([$arquivo]);
    }
    $dono_arquivo = $q->fetchColumn();
    if ($dono_arquivo === false || !feward_sigo($pdo, (int) $_SESSION["usuario_id"], (int) $dono_arquivo)) {
        http_response_code(404);
        exit;
    }
}

$tamanho = filesize($caminho);

$mime = "application/octet-stream";
if (function_exists("finfo_open")) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo !== false) {
        $mime = finfo_file($finfo, $caminho) ?: $mime;
        finfo_close($finfo);
    }
}

header("Content-Type: " . $mime);
header("Cache-Control: private, max-age=3600");
header("Accept-Ranges: bytes");

// Suporte a Range (necessário para adiantar/voltar vídeos no player).
if (isset($_SERVER["HTTP_RANGE"])) {
    if ($tamanho <= 0 || !preg_match('/bytes=(\d*)-(\d*)/i', $_SERVER["HTTP_RANGE"], $m)) {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    }

    // Aceita tanto 100-500 quanto 100- e -500.
    if ($m[1] === "" && $m[2] === "") {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    } elseif ($m[1] === "") {
        $quantidade = (int) $m[2];
        if ($quantidade <= 0) {
            header("Content-Range: bytes */$tamanho");
            http_response_code(416);
            exit;
        }
        $inicio = max(0, $tamanho - $quantidade);
        $fim = $tamanho - 1;
    } else {
        $inicio = (int) $m[1];
        $fim = ($m[2] === "") ? ($tamanho - 1) : (int) $m[2];
        $fim = min($fim, $tamanho - 1);
    }

    if ($inicio < 0 || $inicio > $fim || $inicio >= $tamanho) {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    }

    http_response_code(206);
    header("Content-Range: bytes $inicio-$fim/$tamanho");
    header("Content-Length: " . ($fim - $inicio + 1));

    $handle = fopen($caminho, "rb");
    if ($handle === false) {
        http_response_code(500);
        exit;
    }
    fseek($handle, $inicio);
    $restante = $fim - $inicio + 1;
    while ($restante > 0 && !feof($handle)) {
        $pedaco = min(8192, $restante);
        echo fread($handle, $pedaco);
        $restante -= $pedaco;
        flush();
    }
    fclose($handle);
    exit;
}

header("Content-Length: " . $tamanho);
readfile($caminho);
exit;
