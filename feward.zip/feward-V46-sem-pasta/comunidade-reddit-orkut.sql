-- Feward - Comunidade estilo Reddit/Orkut
ALTER TABLE comunidades ADD COLUMN descricao TEXT NULL;
ALTER TABLE comunidades ADD COLUMN criador_id INT UNSIGNED NULL;
ALTER TABLE comunidades ADD CONSTRAINT fk_comunidades_criador FOREIGN KEY (criador_id) REFERENCES contas(id) ON DELETE SET NULL;
ALTER TABLE posts ADD COLUMN comunidade_id INT UNSIGNED NULL;
ALTER TABLE posts ADD CONSTRAINT fk_posts_comunidade FOREIGN KEY (comunidade_id) REFERENCES comunidades(id) ON DELETE CASCADE;
ALTER TABLE posts ADD KEY idx_posts_comunidade (comunidade_id, criado_em);
