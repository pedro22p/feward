-- Feward V16 - posição de exibição da foto de perfil
-- Execute depois de videos.sql (mesma ordem do LEIA-ME-BANCO.txt).
-- Guarda algo como "50% 30%" (equivalente a object-position no CSS).

ALTER TABLE contas ADD COLUMN IF NOT EXISTS foto_perfil_pos VARCHAR(20) NOT NULL DEFAULT '50% 50%';
