-- Feward V36 - card de perfil estilo Orkut (perfil.php)
-- Execute uma vez no banco "feward" (phpMyAdmin ou: mysql -u feward -p feward < perfil_orkut_v36.sql)

CREATE TABLE IF NOT EXISTS perfil_orkut (
    usuario_id INT UNSIGNED NOT NULL,
    relacionamento VARCHAR(30) NOT NULL DEFAULT '',
    aniversario DATE NULL,
    interesses VARCHAR(200) NOT NULL DEFAULT '',
    filhos VARCHAR(30) NOT NULL DEFAULT '',
    etnia VARCHAR(40) NOT NULL DEFAULT '',
    humor VARCHAR(60) NOT NULL DEFAULT '',
    orientacao VARCHAR(40) NOT NULL DEFAULT '',
    estilo VARCHAR(40) NOT NULL DEFAULT '',
    bebo VARCHAR(30) NOT NULL DEFAULT '',
    fumo VARCHAR(30) NOT NULL DEFAULT '',
    animais VARCHAR(100) NOT NULL DEFAULT '',
    mora VARCHAR(60) NOT NULL DEFAULT '',
    cidade_natal VARCHAR(80) NOT NULL DEFAULT '',
    pagina_web VARCHAR(255) NOT NULL DEFAULT '',
    paixoes VARCHAR(200) NOT NULL DEFAULT '',
    esportes VARCHAR(150) NOT NULL DEFAULT '',
    atividades VARCHAR(200) NOT NULL DEFAULT '',
    atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id),
    CONSTRAINT fk_perfil_orkut_conta FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
