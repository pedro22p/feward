<?php
require_once "auth.php";
require_once "card_orkut.php";

// upload da foto de perfil
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["foto_perfil"])) {
    $arquivo = $_FILES["foto_perfil"];

    // Mensagens mais claras para os erros de upload do PHP.
    $erros_upload = [
        UPLOAD_ERR_INI_SIZE   => "A foto excede o limite de upload configurado no servidor.",
        UPLOAD_ERR_FORM_SIZE  => "A foto excede o limite permitido pelo formulário.",
        UPLOAD_ERR_PARTIAL    => "O upload foi enviado apenas parcialmente. Tente novamente.",
        UPLOAD_ERR_NO_FILE    => "Nenhuma foto foi selecionada.",
        UPLOAD_ERR_NO_TMP_DIR => "O servidor não encontrou a pasta temporária para o upload.",
        UPLOAD_ERR_CANT_WRITE => "O servidor não conseguiu gravar o arquivo temporário.",
        UPLOAD_ERR_EXTENSION  => "Uma extensão do PHP bloqueou o upload.",
    ];

    if ($arquivo["error"] !== UPLOAD_ERR_OK) {
        $erro_foto = $erros_upload[$arquivo["error"]] ?? "Erro desconhecido ao enviar a foto.";
    } elseif (!is_uploaded_file($arquivo["tmp_name"])) {
        $erro_foto = "O arquivo recebido pelo servidor não é um upload válido.";
    } elseif ($arquivo["size"] > 5 * 1024 * 1024) {
        $erro_foto = "A foto deve ter no máximo 5 MB.";
    } else {
        $info = @getimagesize($arquivo["tmp_name"]);
        $tipos = [
            IMAGETYPE_JPEG => "jpg",
            IMAGETYPE_PNG  => "png",
            IMAGETYPE_WEBP => "webp"
        ];

        if (!$info || !isset($tipos[$info[2]])) {
            $erro_foto = "Escolha uma imagem JPG, PNG ou WEBP válida.";
        } else {
            $dir = __DIR__ . "/uploads/perfis";

            // Cria a pasta caso ela ainda não exista.
            if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
                $erro_foto = "Não foi possível criar a pasta de fotos de perfil.";
            } elseif (!is_writable($dir)) {
                $erro_foto = "A pasta de fotos de perfil não permite gravação no servidor.";
            } else {
                try {
                    $nome = "perfil_" . (int)$usuario_logado["id"] . "_" . bin2hex(random_bytes(8)) . "." . $tipos[$info[2]];
                } catch (Throwable $e) {
                    $nome = "perfil_" . (int)$usuario_logado["id"] . "_" . uniqid("foto_", true) . "." . $tipos[$info[2]];
                }

                $destino = $dir . DIRECTORY_SEPARATOR . $nome;

                // move_uploaded_file é a forma correta de finalizar um upload HTTP.
                if (move_uploaded_file($arquivo["tmp_name"], $destino)) {
                    // Só apaga a foto anterior depois que a nova foi salva.
                    if (!empty($usuario_logado["foto_perfil"])) {
                        $antiga = __DIR__ . "/" . ltrim(str_replace('\\', '/', $usuario_logado["foto_perfil"]), "/");
                        if (is_file($antiga) && $antiga !== $destino) {
                            @unlink($antiga);
                        }
                    }

                    $caminho = "uploads/perfis/" . $nome;
                    $stmt = $pdo->prepare("UPDATE contas SET foto_perfil = ? WHERE id = ?");
                    $stmt->execute([$caminho, $usuario_logado["id"]]);

                    header("Location: perfil.php");
                    exit;
                }

                // Mensagem útil em vez do genérico "Não foi possível salvar".
                $erro_foto = "O servidor recebeu a foto, mas não conseguiu salvá-la na pasta uploads/perfis. Verifique as permissões da pasta e a configuração de upload do PHP.";
            }
        }
    }
}

// atualizar bio
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["bio"])) {
    $bio = trim($_POST["bio"]);
    $stmt = $pdo->prepare("UPDATE contas SET bio = ? WHERE id = ?");
    $stmt->execute([$bio, $usuario_logado["id"]]);
    header("Location: perfil.php");
    exit;
}

// escolher onde a foto de perfil vai mostrar (posição dentro do círculo)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["pos_x"], $_POST["pos_y"])) {
    $pos_x = max(0, min(100, (int) $_POST["pos_x"]));
    $pos_y = max(0, min(100, (int) $_POST["pos_y"]));
    $posicao = $pos_x . "% " . $pos_y . "%";
    $stmt = $pdo->prepare("UPDATE contas SET foto_perfil_pos = ? WHERE id = ?");
    $stmt->execute([$posicao, $usuario_logado["id"]]);
    header("Location: perfil.php");
    exit;
}

// salvar as informações do card estilo Orkut
$erro_card = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["card_orkut"])) {
    try {
        card_orkut_salvar($pdo, (int) $usuario_logado["id"], $_POST);
        header("Location: perfil.php#card-orkut");
        exit;
    } catch (Throwable $e) {
        $erro_card = "Não foi possível salvar o card. Rode o arquivo perfil_orkut_v36.sql no banco de dados e tente de novo.";
    }
}

$imagens = $pdo->prepare("
    SELECT imagem FROM posts
    WHERE usuario_id = ? AND imagem IS NOT NULL
    ORDER BY criado_em DESC
    LIMIT 30
");
$imagens->execute([$usuario_logado["id"]]);
$imagens = $imagens->fetchAll();

$posicao_atual = $usuario_logado["foto_perfil_pos"] ?? "50% 50%";

$total_seguidores = $pdo->prepare("SELECT COUNT(*) FROM amizades WHERE amigo_id = ? AND status = 'aceito'");
$total_seguidores->execute([$usuario_logado["id"]]);
$total_seguidores = (int) $total_seguidores->fetchColumn();
$sou_verificado = $total_seguidores >= 1000;
$total_seguindo = $pdo->prepare("SELECT COUNT(*) FROM amizades WHERE usuario_id = ? AND status = 'aceito'");
$total_seguindo->execute([$usuario_logado["id"]]);
$total_seguindo = (int) $total_seguindo->fetchColumn();
$total_posts = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE usuario_id = ?");
$total_posts->execute([$usuario_logado["id"]]);
$total_posts = (int) $total_posts->fetchColumn();
$dados_card = card_orkut_carregar($pdo, (int) $usuario_logado["id"]);
$contagens_card = card_orkut_contagens($pdo, (int) $usuario_logado["id"], $total_seguidores);
$partes_pos = explode(" ", $posicao_atual);
$pos_x_atual = isset($partes_pos[0]) ? (int) $partes_pos[0] : 50;
$pos_y_atual = isset($partes_pos[1]) ? (int) $partes_pos[1] : 50;

$pagina_ativa = "perfil";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Perfil do usuário no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Perfil - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .perfil-topo { display: flex; align-items: center; gap: 20px; margin-bottom: 20px; }
        .perfil-nome { font-size: 26px; font-weight: bold; }
        .selo-verificado { display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; background: #2196f3; color: #fff; border-radius: 50%; font-size: 12px; vertical-align: middle; margin-left: 4px; }
        .bio-form textarea { min-height: 70px; margin-top: 8px; }
        .galeria { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-top: 20px; }
        .galeria img { width: 100%; height: 130px; object-fit: cover; border-radius: 10px; }
        .zona-perigo { margin-top: 30px; }
        .perfil-mobile { display: none; }
        .pm-linha { display: flex; align-items: center; gap: 22px; }
        .pm-foto { width: 86px; height: 86px; border-radius: 50%; object-fit: cover; background: #222; flex: none; display: flex; align-items: center; justify-content: center; font-size: 34px; }
        .pm-stats { flex: 1; display: flex; justify-content: space-around; text-align: center; }
        .pm-stats strong { display: block; font-size: 18px; }
        .pm-stats span { font-size: 13px; color: #e5e5e5; }
        .pm-nome { margin: 12px 0 2px; font-weight: bold; font-size: 15px; }
        .pm-user { color: #aaa; font-size: 13px; }
        .pm-bio { margin: 6px 0 0; font-size: 14px; line-height: 1.35; white-space: pre-line; overflow-wrap: anywhere; }
        .pm-botoes { display: flex; gap: 8px; margin: 14px 0 6px; }
        .pm-botoes button { flex: 1; border: 0; border-radius: 10px; padding: 9px 0; background: #262a33; color: #fff; font-weight: bold; font-size: 14px; cursor: pointer; }
        .pm-abas { display: flex; border-top: 1px solid rgba(255,255,255,.1); margin: 10px -14px 0; }
        .pm-abas div { flex: 1; text-align: center; padding: 10px 0; font-size: 22px; border-top: 2px solid transparent; margin-top: -1px; }
        .pm-abas div.ativa { border-top-color: #fff; }
        .btn-deletar { background: #b30000; border: none; color: white; padding: 10px 18px; border-radius: 15px; cursor: pointer; }
        .avatar-perfil { width: 90px; height: 90px; border-radius: 50%; object-fit: cover; background: #222; }
        .foto-form { display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin: 10px 0 20px; }
        .foto-form label { width:100%; font-weight:bold; }
        .foto-form input[type=file] { max-width:100%; }
        .erro-foto { width:100%; color:#ff7777; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="perfil-mobile">
        <div class="pm-linha">
            <?php if (!empty($usuario_logado["foto_perfil"]) && is_file(__DIR__ . "/" . ltrim($usuario_logado["foto_perfil"], "/"))): ?>
                <img class="pm-foto" src="avatar.php" alt="Foto de perfil" style="object-position: <?= htmlspecialchars($posicao_atual) ?>;" onclick="abrirLightbox(this.src)">
            <?php else: ?>
                <div class="pm-foto">👤</div>
            <?php endif; ?>
            <div class="pm-stats">
                <div><strong><?= $total_posts ?></strong><span>posts</span></div>
                <div><strong><?= $total_seguidores ?></strong><span>seguidores</span></div>
                <div><strong><?= $total_seguindo ?></strong><span>seguindo</span></div>
            </div>
        </div>
        <div class="pm-nome"><?= htmlspecialchars($usuario_logado["nome_usuario"]) ?><?php if ($sou_verificado): ?> <span class="selo-verificado">✔</span><?php endif; ?></div>
        <?php if (!empty($usuario_logado["bio"])): ?><p class="pm-bio"><?= htmlspecialchars($usuario_logado["bio"]) ?></p><?php endif; ?>
        <div class="pm-botoes">
            <button type="button" onclick="document.getElementById('editar-bloco').classList.toggle('aberto')">Editar perfil</button>
            <button type="button" onclick="compartilharPerfil()">Compartilhar perfil</button>
        </div>
        <div class="pm-abas"><div class="ativa">▦</div><div>▶</div><div>🔖</div></div>
    </div>

    <div class="topo-pagina">
        <h1>Perfil</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="card-escuro">
        <div class="perfil-topo">
            <?php if (!empty($usuario_logado["foto_perfil"]) && is_file(__DIR__ . "/" . ltrim($usuario_logado["foto_perfil"], "/"))): ?>
                <img class="avatar-perfil" src="avatar.php" alt="Foto de perfil" style="object-position: <?= htmlspecialchars($posicao_atual) ?>; cursor: zoom-in;" onclick="abrirLightbox(this.src)">
            <?php else: ?>
                <div class="avatar-vazio">👤</div>
            <?php endif; ?>
            <div>
                <div class="perfil-nome">
                    <?= htmlspecialchars($usuario_logado["nome_usuario"]) ?>
                    <?php if ($sou_verificado): ?><span class="selo-verificado" title="Verificado - 1000+ seguidores">✔</span><?php endif; ?>
                </div>
                <div class="perfil-stats"><strong><?= $total_seguidores ?></strong> seguidores<?php if (!$sou_verificado): ?><span style="color:#aaa;"> (faltam <?= max(0, 1000 - $total_seguidores) ?> para o selo verificado)</span><?php endif; ?></div>
                <div style="color:#ccc;">Conta criada em <?= date("d/m/Y", strtotime($usuario_logado["criado_em"])) ?></div>
            </div>
        </div>

        <div class="editar-bloco<?= (!empty($erro_foto) || $erro_card !== "") ? " aberto" : "" ?>" id="editar-bloco">
        <form class="foto-form" method="POST" enctype="multipart/form-data">
            <label for="foto_perfil">Foto de perfil</label>
            <input type="file" id="foto_perfil" name="foto_perfil" accept="image/jpeg,image/png,image/webp" required>
            <button class="acao" type="submit">Salvar foto</button>
            <?php if (!empty($erro_foto)): ?><div class="erro-foto"><?= htmlspecialchars($erro_foto) ?></div><?php endif; ?>
        </form>

        <?php if (!empty($usuario_logado["foto_perfil"])): ?>
        <form class="posicao-form" method="POST">
            <label>Posição da foto de perfil</label>
            <div class="posicao-preview-wrap">
                <img id="posicao-preview" class="posicao-preview" src="avatar.php" alt="Prévia da posição" style="object-position: <?= htmlspecialchars($posicao_atual) ?>;">
            </div>
            <label style="font-weight:normal;">Horizontal</label>
            <input type="range" min="0" max="100" name="pos_x" id="pos_x" value="<?= $pos_x_atual ?>" oninput="atualizarPosicaoFoto()">
            <label style="font-weight:normal;">Vertical</label>
            <input type="range" min="0" max="100" name="pos_y" id="pos_y" value="<?= $pos_y_atual ?>" oninput="atualizarPosicaoFoto()">
            <button class="acao" type="submit" style="margin-top:8px;">Salvar posição</button>
        </form>
        <?php endif; ?>

        <form class="bio-form" method="POST">
            <label>Bio</label>
            <textarea name="bio" placeholder="Fale um pouco sobre você..."><?= htmlspecialchars($usuario_logado["bio"] ?? "") ?></textarea>
            <button class="acao" type="submit" style="margin-top:8px;">Salvar bio</button>
        </form>

        <h2 id="card-orkut" style="margin-top:30px;">Meu card</h2>
        <?php if ($erro_card !== ""): ?><div class="erro-foto"><?= htmlspecialchars($erro_card) ?></div><?php endif; ?>
        <?php card_orkut_exibir($usuario_logado["nome_usuario"], $dados_card, (string) ($usuario_logado["bio"] ?? ""), $contagens_card); ?>
        <?php card_orkut_formulario($dados_card); ?>

        <div class="zona-perigo">
            <form method="POST" action="deletar_conta.php" onsubmit="return confirm('Tem certeza que quer deletar sua conta? Essa ação não pode ser desfeita.');">
                <button class="btn-deletar" type="submit">Deletar conta</button>
            </form>
        </div>
        </div>

        <h2 class="perfil-galeria-titulo" style="margin-top:30px;">Imagens</h2>
        <div class="galeria">
            <?php foreach ($imagens as $img): ?>
                <?php $img_src = "midia.php?pasta=posts&arquivo=" . urlencode($img["imagem"]); ?>
                <img src="<?= htmlspecialchars($img_src) ?>" alt="imagem" onclick="abrirLightbox(this.src)">
            <?php endforeach; ?>
            <?php if (empty($imagens)): ?>
                <p>Nenhuma imagem publicada ainda.</p>
            <?php endif; ?>
        </div>

    </div>
</div>

<div class="lightbox-overlay" id="lightbox-overlay" onclick="fecharLightbox()">
    <button class="lightbox-fechar" type="button" onclick="fecharLightbox()">&times;</button>
    <img id="lightbox-img" src="" alt="Imagem ampliada" onclick="event.stopPropagation()">
</div>
<script src="midia.js"></script>
<script>
function compartilharPerfil() {
    var url = location.href;
    if (navigator.share) { navigator.share({ title: "Feward", url: url }).catch(function () {}); }
    else if (navigator.clipboard) { navigator.clipboard.writeText(url).then(function () { alert("Link copiado!"); }); }
}
</script>

</body>
</html>
