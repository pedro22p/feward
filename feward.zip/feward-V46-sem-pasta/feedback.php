<?php
// feedback.php — Página onde o usuário envia feedback para o dono do Feward.
// O texto digitado chega no e-mail feward295@gmail.com usando a função mail().

// Empilha uma variável pra controlar mensagem de erro/sucesso.
$aviso = "";

// Verifica se o formulário foi enviado.
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Lê os campos preenchidos (com valor padrão vazio se não vierem).
    $nome  = trim($_POST["nome"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $mensagem = trim($_POST["mensagem"] ?? "");

    // Valida os campos antes de enviar.
    if ($nome === "" || $mensagem === "") {
        $aviso = "Preencha o nome e o feedback para poder enviar.";
    } elseif (mb_strlen($mensagem) < 10) {
        $aviso = "Escreva um feedback um pouco mais completo (mínimo 10 caracteres).";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $aviso = "Digite um e-mail válido para podermos responder.";
    } else {

        // Monta o corpo e o cabeçalho do e-mail.
        $destino   = "feward295@gmail.com";
        $assunto   = "Novo feedback no Feward";
        $corpo     = "Novo feedback recebido pelo Feward!\n\n"
                   . "Nome:   {$nome}\n"
                   . "E-mail: {$email}\n"
                   . "----------------------------------------\n"
                   . $mensagem . "\n"
                   . "----------------------------------------\n";
        $headers   = "From: {$email}\r\n" .
                     "Reply-To: {$email}\r\n" .
                     "Content-Type: text/plain; charset=UTF-8\r\n";

        // Tenta enviar e guarda o resultado (1 = enviado).
        $enviado = @mail($destino, $assunto, $corpo, $headers);

        if ($enviado) {
            $aviso = "Feedback enviado! Obrigado por ajudar a melhorar o Feward. 💜";
        } else {
            $aviso = "Não foi possível enviar agora. Tente de novo em instantes.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0b1050">
    <title>Feedback - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <style>
        * { box-sizing: border-box; }
        html, body {
            width: 100%;
            min-height: 100%;
            margin: 0;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background:
                linear-gradient(rgba(5, 8, 35, 0.35), rgba(5, 8, 35, 0.55)),
                url("img/fundo.jpeg") center center / cover no-repeat fixed;
            min-height: 100vh;
            color: white;
            overflow-x: hidden;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 35px 16px 30px;
        }
        .creditos {
            position: fixed;
            top: 16px;
            right: 16px;
            z-index: 10;
            background: rgba(39, 44, 121, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.8);
            padding: 11px 16px;
            border-radius: 8px;
            color: white;
            font-size: 13px;
            cursor: pointer;
            transition: 0.2s ease;
        }
        .creditos:hover { background: white; color: #111; }
        .logo { position: relative; z-index: 1; width: min(300px, 70vw); margin-top: 20px; flex-shrink: 0; text-align: center; }
        .logo img { display: block; width: 100%; height: auto; }
        .caixa {
            width: 100%;
            max-width: 460px;
            margin-top: 26px;
            padding: 28px 24px;
            background: rgba(0, 0, 0, 0.88);
            border-radius: 18px;
            box-shadow: 0 15px 45px rgba(0, 0, 0, 0.4);
        }
        h1 {
            text-align: center;
            font-size: 27px;
            margin: 0 0 8px;
        }
        .descricao {
            text-align: center;
            color: #ccc;
            line-height: 1.5;
            margin: 0 0 4px;
        }
        .dica {
            text-align: center;
            color: #8ea2ff;
            font-size: 13px;
            margin: 5px 0 18px;
        }
        .aviso {
            background: rgba(40, 180, 100, 0.15);
            border: 1px solid rgba(100, 220, 150, 0.35);
            padding: 11px 13px;
            border-radius: 10px;
            line-height: 1.45;
            margin: 12px 0 16px;
            color: #c8f5d6;
        }
        label { display: block; margin-bottom: 7px; color: #ddd; font-size: 14px; }
        input, textarea {
            width: 100%;
            padding: 13px 14px;
            border: 1px solid transparent;
            border-radius: 10px;
            font-size: 15px;
            outline: none;
            font-family: inherit;
            color: #fff;
            background: rgba(255, 255, 255, 0.07);
        }
        input:focus, textarea:focus {
            border-color: #2844e2;
            box-shadow: 0 0 0 3px rgba(40, 68, 226, 0.2);
        }
        textarea { min-height: 130px; resize: vertical; }
        button {
            width: 100%;
            min-height: 50px;
            margin-top: 16px;
            background: #2844e2;
            border: 0;
            border-radius: 10px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        .voltar {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #9cacff;
            text-decoration: none;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <!-- Botão que volta para o login. -->
    <button class="creditos" type="button" onclick="window.location.href='login.php'">
        Voltar
    </button>

    <!-- Logo do Feward. -->
    <div class="logo">
        <img src="img/logo.png" alt="Logo do Feward">
    </div>

    <!-- Caixa principal com o formulário de feedback. -->
    <main class="caixa">
        <h1>Feedback</h1>
        <p class="descricao">Conte o que você achou do Feward, sugira melhorias ou reporte um problema.</p>
        <p class="dica">Seu texto vai direto para o e-mail do criador.</p>

        <?php if ($aviso): ?>
            <div class="aviso" role="status"><?= htmlspecialchars($aviso, ENT_QUOTES, "UTF-8") ?></div>
        <?php endif; ?>

        <form method="POST" action="feedback.php" autocomplete="on">
            <div>
                <label for="nome">Seu nome</label>
                <input id="nome" type="text" name="nome" placeholder="Opcional, mas ajuda"
                    value="<?= htmlspecialchars($nome ?? "", ENT_QUOTES, "UTF-8") ?>" required>
            </div>

            <div style="margin-top:14px;">
                <label for="email">Seu e-mail</label>
                <input id="email" type="email" name="email" placeholder="Para podermos responder"
                    value="<?= htmlspecialchars($email ?? "", ENT_QUOTES, "UTF-8") ?>" required>
            </div>

            <div style="margin-top:14px;">
                <label for="mensagem">Seu feedback</label>
                <textarea id="mensagem" name="mensagem" placeholder="Escreva aqui o que você quer mandar..." required><?= htmlspecialchars($mensagem ?? "", ENT_QUOTES, "UTF-8") ?></textarea>
            </div>

            <button type="submit">Enviar feedback</button>
        </form>

        <a class="voltar" href="login.php">Voltar para o login</a>
    </main>

</body>
</html>
