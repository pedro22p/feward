-- Feward V16 - tabela de contas
-- Execute SOMENTE em um banco novo.
-- Se sua tabela contas já existe e contém sua conta, NÃO execute este arquivo.

CREATE TABLE IF NOT EXISTS contas (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome_usuario VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    bio TEXT NULL,
    foto_perfil VARCHAR(255) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_contas_email (email),
    UNIQUE KEY uq_contas_nome_usuario (nome_usuario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
