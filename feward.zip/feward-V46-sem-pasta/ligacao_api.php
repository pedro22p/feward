<?php
// V48: API das ligações 1 a 1 (sinalização WebRTC por polling).
// De propósito só confere a sessão (sem auth.php) pra o "tick" de 3 em 3 s ficar leve.
require_once "conexao.php";
require_once "seguir_util.php";
session_start();
header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store");

function falhar(int $c, string $m) { http_response_code($c); echo json_encode(["ok"=>false,"erro"=>$m], JSON_UNESCAPED_UNICODE); exit; }
function responder(array $d) { echo json_encode($d + ["ok"=>true], JSON_UNESCAPED_UNICODE); exit; }

if (empty($_SESSION["usuario_id"])) falhar(401, "Sessão expirada.");
$eu = (int) $_SESSION["usuario_id"];
session_write_close(); // não trava outras abas enquanto faz polling
$acao = $_POST["acao"] ?? $_GET["acao"] ?? "";
$id = (int) ($_POST["id"] ?? $_GET["id"] ?? 0);
const TEMPO_TOCANDO = 45; // segundos tocando antes de virar "perdida"

// ligações que tocaram demais viram "perdida"
$pdo->exec("UPDATE ligacoes SET status='perdida', encerrada_em=NOW() WHERE status='chamando' AND TIMESTAMPDIFF(SECOND, criada_em, NOW()) > " . (TEMPO_TOCANDO + 5));

// ligação "ativa" sem batida há 25 s (aba fechada/queda) é encerrada sozinha
$pdo->exec("UPDATE ligacoes SET status='encerrada', encerrada_em=NOW() WHERE status='ativa' AND TIMESTAMPDIFF(SECOND, COALESCE(batida_em, atendida_em), NOW()) > 25");

function minhaLigacao(PDO $pdo, int $id, int $eu) {
    $s = $pdo->prepare("SELECT * FROM ligacoes WHERE id=? AND (de_id=? OR para_id=?)");
    $s->execute([$id, $eu, $eu]);
    return $s->fetch();
}

switch ($acao) {
    case "ligar":
        $para = (int) ($_POST["para_id"] ?? 0);
        $tipo = ($_POST["tipo"] ?? "voz") === "video" ? "video" : "voz";
        if ($para <= 0 || $para === $eu) falhar(400, "Contato inválido.");
        if (!feward_sigo($pdo, $eu, $para)) falhar(403, "Você precisa seguir essa pessoa para ligar.");
        $s = $pdo->prepare("SELECT 1 FROM ligacoes WHERE status IN ('chamando','ativa') AND (de_id IN (?,?) OR para_id IN (?,?)) LIMIT 1");
        $s->execute([$eu, $para, $eu, $para]);
        if ($s->fetchColumn()) falhar(409, "Você ou essa pessoa já está em uma ligação.");
        $pdo->prepare("INSERT INTO ligacoes (de_id, para_id, tipo) VALUES (?,?,?)")->execute([$eu, $para, $tipo]);
        responder(["id" => (int) $pdo->lastInsertId(), "tempo" => TEMPO_TOCANDO]);

    case "tick": // ligação chegando pra mim (se houver)
        $s = $pdo->prepare("SELECT l.id, l.tipo, l.de_id, c.nome_usuario FROM ligacoes l JOIN contas c ON c.id=l.de_id
                            WHERE l.para_id=? AND l.status='chamando' AND TIMESTAMPDIFF(SECOND, l.criada_em, NOW()) <= " . TEMPO_TOCANDO . " ORDER BY l.id DESC LIMIT 1");
        $s->execute([$eu]);
        responder(["entrada" => $s->fetch() ?: null]);

    case "estado":
        $l = minhaLigacao($pdo, $id, $eu);
        if (!$l) falhar(404, "Ligação não encontrada.");
        responder(["status" => $l["status"]]);

    case "atender":
        $s = $pdo->prepare("UPDATE ligacoes SET status='ativa', atendida_em=NOW() WHERE id=? AND para_id=? AND status='chamando'");
        $s->execute([$id, $eu]);
        if (!$s->rowCount()) falhar(410, "A ligação não está mais disponível.");
        responder([]);

    case "recusar":
        $pdo->prepare("UPDATE ligacoes SET status='recusada', encerrada_em=NOW() WHERE id=? AND para_id=? AND status='chamando'")->execute([$id, $eu]);
        responder([]);

    case "encerrar":
        $l = minhaLigacao($pdo, $id, $eu);
        if (!$l) falhar(404, "Ligação não encontrada.");
        if ($l["status"] === "chamando") {
            $novo = ((int) $l["de_id"] === $eu) ? "perdida" : "recusada";
            $pdo->prepare("UPDATE ligacoes SET status=?, encerrada_em=NOW() WHERE id=?")->execute([$novo, $id]);
        } elseif ($l["status"] === "ativa") {
            $pdo->prepare("UPDATE ligacoes SET status='encerrada', encerrada_em=NOW() WHERE id=?")->execute([$id]);
        }
        $pdo->prepare("DELETE FROM ligacao_sinais WHERE ligacao_id=?")->execute([$id]);
        responder([]);

    case "sinal":
        $l = minhaLigacao($pdo, $id, $eu);
        if (!$l || !in_array($l["status"], ["chamando","ativa"], true)) falhar(404, "Ligação não está ativa.");
        $dest = ((int) $l["de_id"] === $eu) ? (int) $l["para_id"] : (int) $l["de_id"];
        $tipo = substr(preg_replace("/[^a-z]/", "", $_POST["tipo"] ?? ""), 0, 20);
        $dados = (string) ($_POST["dados"] ?? "");
        if ($tipo === "" || strlen($dados) > 60000) falhar(400, "Sinal inválido.");
        $pdo->prepare("INSERT INTO ligacao_sinais (ligacao_id, remetente_id, destinatario_id, tipo, dados) VALUES (?,?,?,?,?)")->execute([$id, $eu, $dest, $tipo, $dados]);
        responder([]);

    case "sinais":
        $l = minhaLigacao($pdo, $id, $eu);
        if (!$l) falhar(404, "Ligação não encontrada.");
        $pdo->prepare("UPDATE ligacoes SET batida_em=NOW() WHERE id=? AND status='ativa'")->execute([$id]);
        $depois = (int) ($_GET["depois_de"] ?? 0);
        $s = $pdo->prepare("SELECT id, tipo, dados FROM ligacao_sinais WHERE ligacao_id=? AND destinatario_id=? AND id>? ORDER BY id ASC LIMIT 100");
        $s->execute([$id, $eu, $depois]);
        responder(["status" => $l["status"], "sinais" => $s->fetchAll()]);

    default:
        falhar(400, "Ação inválida.");
}
