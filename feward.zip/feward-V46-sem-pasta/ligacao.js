/* Feward V48 - ligações 1 a 1 (voz/vídeo), estilo Instagram/WhatsApp.
   Carregado por nav.php em toda página logada: recebe chamadas em qualquer tela
   e expõe window.FewardLigacao.ligar(idDoContato, nome, "voz" | "video").
   Pra funcionar em redes de celular (4G/5G) quase sempre precisa de um servidor TURN:
   defina antes deste arquivo  window.FEWARD_ICE = [{urls:"turn:...", username:"..", credential:".."}, ...]  */
(function () {
    if (window.FewardLigacao) return;
    var ICE = window.FEWARD_ICE || [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun.cloudflare.com:3478" }];

    var css = document.createElement("link");
    css.rel = "stylesheet"; css.href = "chamada.css?v=48";
    document.head.appendChild(css);

    function el(html) { var d = document.createElement("div"); d.innerHTML = html.trim(); return d.firstChild; }
    var entradaEl = el('<div id="lig-entrada" hidden><div class="lig-ent-card">' +
        '<img class="lig-ent-foto" alt=""><div class="lig-ent-info"><strong class="lig-ent-nome"></strong><span class="lig-ent-tipo"></span></div>' +
        '<button type="button" class="lig-btn recusar" aria-label="Recusar">✕</button>' +
        '<button type="button" class="lig-btn atender" aria-label="Atender">✓</button></div></div>');
    var telaEl = el('<div id="lig-tela" hidden>' +
        '<video id="lig-remoto" autoplay playsinline></video>' +
        '<div class="lig-voz"><img class="lig-voz-foto" alt=""><div class="lig-voz-nome"></div><div class="lig-voz-status"></div></div>' +
        '<div class="lig-topo"><span class="lig-topo-nome"></span><span class="lig-topo-status"></span></div>' +
        '<video id="lig-local" autoplay playsinline muted></video>' +
        '<div class="lig-controles">' +
        '<button type="button" class="lig-ctl" data-a="mic" aria-label="Microfone"></button>' +
        '<button type="button" class="lig-ctl so-video" data-a="cam" aria-label="Câmera"></button>' +
        '<button type="button" class="lig-ctl so-video" data-a="flip" aria-label="Virar câmera"></button>' +
        '<button type="button" class="lig-ctl desligar" data-a="fim" aria-label="Desligar"></button></div></div>');
    document.addEventListener("DOMContentLoaded", function () { document.body.append(entradaEl, telaEl); });
    if (document.body) document.body.append(entradaEl, telaEl);

    var ICONES = {
        mic: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
        micOff: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M3 3l18 18"/></svg>',
        cam: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="3" y="6" width="12" height="12" rx="3"/><path d="m15 11 6-3v8l-6-3z"/></svg>',
        camOff: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"><rect x="3" y="6" width="12" height="12" rx="3"/><path d="m15 11 6-3v8l-6-3zM3 3l18 18"/></svg>',
        flip: '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8V5h3M20 16v3h-3M4 5a9 9 0 0 1 15 3M20 19a9 9 0 0 1-15-3"/></svg>',
        fim: '<svg viewBox="0 0 24 24" width="28" height="28" fill="currentColor"><path d="M12 9c-3 0-5.7.7-8 2.2-.6.4-.8 1.1-.5 1.8l.9 1.9c.3.6 1 .9 1.6.7l2.4-.9c.5-.2.8-.6.8-1.1v-1.4c1.1-.3 2.2-.4 2.8-.4s1.7.1 2.8.4v1.4c0 .5.3.9.8 1.1l2.4.9c.6.2 1.3-.1 1.6-.7l.9-1.9c.3-.7.1-1.4-.5-1.8C17.700 9.700 15 9 12 9z"/></svg>'
    };
    var $ = function (s, r) { return (r || telaEl).querySelector(s); };

    var L = null, ringTimer = null, ringCtx = null, entradaId = 0, tickT = null;

    function api(acao, dados, get) {
        var qs = new URLSearchParams(Object.assign({ acao: acao }, dados || {}));
        var p = get ? fetch("ligacao_api.php?" + qs, { cache: "no-store" })
                    : fetch("ligacao_api.php", { method: "POST", body: qs });
        return p.then(function (r) { return r.json(); }).then(function (j) { if (!j.ok) throw new Error(j.erro || "Erro"); return j; });
    }
    function avatar(id) { return "avatar.php?id=" + encodeURIComponent(id); }
    function fmt(s) { var m = Math.floor(s / 60), x = s % 60; return (m < 10 ? "0" : "") + m + ":" + (x < 10 ? "0" : "") + x; }

    /* ---------- toque ---------- */
    function tocar() {
        pararToque();
        function bipe() {
            try {
                ringCtx = ringCtx || new (window.AudioContext || window.webkitAudioContext)();
                [0, 0.35].forEach(function (d) {
                    var o = ringCtx.createOscillator(), g = ringCtx.createGain();
                    o.frequency.value = 440; o.connect(g); g.connect(ringCtx.destination);
                    var t = ringCtx.currentTime + d; g.gain.setValueAtTime(0.0001, t);
                    g.gain.exponentialRampToValueAtTime(0.25, t + 0.03); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
                    o.start(t); o.stop(t + 0.3);
                });
            } catch (e) {}
            if (navigator.vibrate) navigator.vibrate([400, 200, 400]);
        }
        bipe(); ringTimer = setInterval(bipe, 2500);
    }
    function pararToque() { if (ringTimer) clearInterval(ringTimer); ringTimer = null; if (navigator.vibrate) navigator.vibrate(0); }

    /* ---------- ligação chegando ---------- */
    function mostrarEntrada(e) {
        if (entradaId === Number(e.id)) return;
        entradaId = Number(e.id);
        $(".lig-ent-foto", entradaEl).src = avatar(e.de_id);
        $(".lig-ent-nome", entradaEl).textContent = e.nome_usuario;
        $(".lig-ent-tipo", entradaEl).textContent = e.tipo === "video" ? "Chamada de vídeo do Feward" : "Chamada de voz do Feward";
        entradaEl.hidden = false; tocar();
        $(".atender", entradaEl).onclick = function () { atender(e); };
        $(".recusar", entradaEl).onclick = function () { api("recusar", { id: e.id }).catch(function () {}); esconderEntrada(); };
    }
    function esconderEntrada() { entradaEl.hidden = true; entradaId = 0; pararToque(); }
    function tick() {
        if (L || document.visibilityState === "hidden") return;
        api("tick", {}, true).then(function (r) { if (r.entrada) mostrarEntrada(r.entrada); else if (entradaId) esconderEntrada(); }).catch(function () {});
    }
    tickT = setInterval(tick, 3000); setTimeout(tick, 800);
    document.addEventListener("visibilitychange", function () { if (document.visibilityState === "visible") tick(); });

    /* ---------- mídia ---------- */
    function pegarMidia(tipo, facing) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { alert("Seu navegador não liberou câmera/microfone. Abra o Feward por HTTPS."); return Promise.reject(); }
        var c = tipo === "video" ? { audio: true, video: { facingMode: facing || "user", width: { ideal: 1280 }, height: { ideal: 720 } } } : { audio: true, video: false };
        return navigator.mediaDevices.getUserMedia(c).catch(function () { alert("Não consegui acessar o microfone/câmera. Libere a permissão no navegador."); throw 0; });
    }

    /* ---------- tela da ligação ---------- */
    function abrirTela() {
        $(".lig-topo-nome").textContent = L.nome; $(".lig-voz-nome").textContent = L.nome;
        $(".lig-voz-foto").src = avatar(L.outroId);
        telaEl.className = "tipo-" + L.tipo; telaEl.hidden = false;
        document.body.classList.add("em-ligacao");
        $("#lig-local").srcObject = L.stream;
        $("#lig-remoto").srcObject = null;
        $('[data-a="mic"]').innerHTML = ICONES.mic; $('[data-a="cam"]').innerHTML = ICONES.cam;
        $('[data-a="flip"]').innerHTML = ICONES.flip; $('[data-a="fim"]').innerHTML = ICONES.fim;
        $('[data-a="mic"]').classList.remove("off"); $('[data-a="cam"]').classList.remove("off");
        status(L.papel === "ligando" ? "Chamando…" : "Conectando…");
    }
    function status(t) { $(".lig-topo-status").textContent = t; $(".lig-voz-status").textContent = t; }
    function remotoSemCamera(sem) { telaEl.classList.toggle("remoto-sem-camera", !!sem); }

    function enviar(tipo, dados) { if (L) api("sinal", { id: L.id, tipo: tipo, dados: dados }).catch(function () {}); }
    function enviarMidia() {
        if (!L) return;
        var a = L.stream.getAudioTracks()[0], v = L.stream.getVideoTracks()[0];
        enviar("media", JSON.stringify({ camera: L.tipo === "video" && !!v && v.enabled, mic: !!a && a.enabled }));
    }

    function criarPeer() {
        var pc = new RTCPeerConnection({ iceServers: ICE });
        L.stream.getTracks().forEach(function (t) { pc.addTrack(t, L.stream); });
        pc.onicecandidate = function (e) { if (e.candidate) enviar("ice", JSON.stringify(e.candidate)); };
        pc.ontrack = function (e) { var v = $("#lig-remoto"); var s = e.streams[0] || new MediaStream([e.track]); if (v.srcObject !== s) v.srcObject = s; };
        pc.onconnectionstatechange = function () {
            if (!L || L.pc !== pc) return;
            var s = pc.connectionState;
            if (s === "connected") { clearTimeout(L.queda); if (!L.inicio) { L.inicio = Date.now(); telaEl.classList.add("conectada"); } enviarMidia(); }
            else if (s === "disconnected") { status("Reconectando…"); L.queda = setTimeout(function () { if (L && L.pc === pc && pc.connectionState !== "connected") terminar("Conexão perdida", true); }, 10000); }
            else if (s === "failed") terminar("Não foi possível conectar. Pode faltar um servidor TURN.", true);
        };
        L.pc = pc; return pc;
    }
    function aplicarCandidatos() {
        var fila = L.pend.splice(0);
        fila.forEach(function (c) { L.pc.addIceCandidate(c).catch(function () {}); });
    }
    async function processar(s) {
        var d; try { d = JSON.parse(s.dados); } catch (e) { return; }
        if (s.tipo === "offer" && L.papel === "atendendo") {
            var pc = L.pc || criarPeer();
            await pc.setRemoteDescription(d); L.remotoOk = true; aplicarCandidatos();
            var ans = await pc.createAnswer(); await pc.setLocalDescription(ans);
            enviar("answer", JSON.stringify(pc.localDescription));
        } else if (s.tipo === "answer" && L.papel === "ligando" && L.pc) {
            await L.pc.setRemoteDescription(d); L.remotoOk = true; aplicarCandidatos();
        } else if (s.tipo === "ice") {
            if (L.remotoOk && L.pc) L.pc.addIceCandidate(d).catch(function () {}); else L.pend.push(d);
        } else if (s.tipo === "media") {
            remotoSemCamera(L.tipo !== "video" || !d.camera);
            telaEl.classList.toggle("remoto-mudo", !d.mic);
        }
    }
    async function ciclo() {
        if (!L) return;
        var meu = L;
        try {
            var r = await api("sinais", { id: meu.id, depois_de: meu.ultimo }, true);
            if (L !== meu) return;
            for (var i = 0; i < r.sinais.length; i++) { meu.ultimo = Math.max(meu.ultimo, Number(r.sinais[i].id)); await processar(r.sinais[i]); }
            if (r.status === "ativa" && meu.papel === "ligando" && !meu.pc) {
                status("Conectando…");
                var pc = criarPeer(); var off = await pc.createOffer(); await pc.setLocalDescription(off);
                enviar("offer", JSON.stringify(pc.localDescription));
            } else if (r.status === "recusada") { terminar("Ligação recusada", false); return; }
            else if (r.status === "perdida" || r.status === "encerrada") { terminar(meu.papel === "ligando" && r.status === "perdida" ? "Sem resposta" : "Ligação encerrada", false); return; }
            if (meu.papel === "ligando" && r.status === "chamando" && Date.now() - meu.criada > (meu.tempo || 45) * 1000) { terminar("Sem resposta", true); return; }
        } catch (e) { if (L === meu && /encontrad|Sess/i.test(e.message || "")) { terminar("Ligação encerrada", false); return; } }
        if (L === meu) meu.t = setTimeout(ciclo, meu.pc ? 800 : 1000);
    }
    var relogio = setInterval(function () { if (L && L.inicio) status(fmt(Math.floor((Date.now() - L.inicio) / 1000))); }, 1000);

    function terminar(msg, avisarServidor) {
        if (!L) return;
        var x = L; L = null;
        clearTimeout(x.t); clearTimeout(x.queda);
        if (avisarServidor) api("encerrar", { id: x.id }).catch(function () {});
        if (x.pc) try { x.pc.close(); } catch (e) {}
        x.stream.getTracks().forEach(function (t) { t.stop(); });
        status(msg);
        setTimeout(function () { if (!L) { telaEl.hidden = true; document.body.classList.remove("em-ligacao"); $("#lig-remoto").srcObject = null; $("#lig-local").srcObject = null; telaEl.classList.remove("conectada", "remoto-sem-camera", "remoto-mudo"); } }, 1600);
    }

    /* ---------- ações ---------- */
    function ligar(outroId, nome, tipo) {
        if (L) return;
        tipo = tipo === "video" ? "video" : "voz";
        pegarMidia(tipo).then(function (stream) {
            return api("ligar", { para_id: outroId, tipo: tipo }).then(function (r) {
                L = { id: Number(r.id), tipo: tipo, outroId: outroId, nome: nome, papel: "ligando", stream: stream, pc: null, pend: [], ultimo: 0, criada: Date.now(), tempo: r.tempo };
                abrirTela(); tocar(); ciclo();
                var ant = L; var check = setInterval(function () { if (L !== ant || ant.pc) { clearInterval(check); pararToque(); } }, 500);
            }).catch(function (e) { stream.getTracks().forEach(function (t) { t.stop(); }); alert(e.message || "Não foi possível ligar."); });
        }).catch(function () {});
    }
    function atender(e) {
        esconderEntrada();
        pegarMidia(e.tipo).then(function (stream) {
            return api("atender", { id: e.id }).then(function () {
                L = { id: Number(e.id), tipo: e.tipo, outroId: Number(e.de_id), nome: e.nome_usuario, papel: "atendendo", stream: stream, pc: null, pend: [], ultimo: 0, criada: Date.now() };
                abrirTela(); criarPeer(); ciclo();
            }).catch(function (er) { stream.getTracks().forEach(function (t) { t.stop(); }); alert(er.message || "Não foi possível atender."); });
        }).catch(function () { api("recusar", { id: e.id }).catch(function () {}); });
    }

    telaEl.addEventListener("click", function (ev) {
        var b = ev.target.closest("[data-a]"); if (!b || !L) return;
        var a = b.dataset.a;
        if (a === "fim") { terminar("Ligação encerrada", true); return; }
        if (a === "mic") { var t = L.stream.getAudioTracks()[0]; if (!t) return; t.enabled = !t.enabled; b.classList.toggle("off", !t.enabled); b.innerHTML = t.enabled ? ICONES.mic : ICONES.micOff; enviarMidia(); }
        if (a === "cam") { var v = L.stream.getVideoTracks()[0]; if (!v) return; v.enabled = !v.enabled; b.classList.toggle("off", !v.enabled); b.innerHTML = v.enabled ? ICONES.cam : ICONES.camOff; telaEl.classList.toggle("local-sem-camera", !v.enabled); enviarMidia(); }
        if (a === "flip") {
            var atual = L.stream.getVideoTracks()[0]; if (!atual) return;
            var usa = (atual.getSettings().facingMode === "environment") ? "user" : "environment";
            navigator.mediaDevices.getUserMedia({ video: { facingMode: { exact: usa } } }).then(function (n) {
                var nt = n.getVideoTracks()[0], snd = L.pc && L.pc.getSenders().find(function (s) { return s.track && s.track.kind === "video"; });
                if (snd) snd.replaceTrack(nt);
                L.stream.removeTrack(atual); atual.stop(); L.stream.addTrack(nt);
                $("#lig-local").srcObject = L.stream; $("#lig-local").classList.toggle("traseira", usa === "environment");
            }).catch(function () {});
        }
    });
    // miniatura da câmera arrastável
    (function () {
        var m = $("#lig-local"), dx = 0, dy = 0, arr = false;
        m.addEventListener("pointerdown", function (e) { arr = true; var r = m.getBoundingClientRect(); dx = e.clientX - r.left; dy = e.clientY - r.top; m.setPointerCapture(e.pointerId); });
        m.addEventListener("pointermove", function (e) { if (!arr) return; m.style.left = Math.max(4, Math.min(innerWidth - m.offsetWidth - 4, e.clientX - dx)) + "px"; m.style.top = Math.max(4, Math.min(innerHeight - m.offsetHeight - 4, e.clientY - dy)) + "px"; m.style.right = "auto"; m.style.bottom = "auto"; });
        m.addEventListener("pointerup", function () { arr = false; });
    })();

    window.addEventListener("beforeunload", function (e) {
        if (!L) return;
        try { var f = new FormData(); f.append("acao", "encerrar"); f.append("id", L.id); navigator.sendBeacon("ligacao_api.php", f); } catch (x) {}
        e.preventDefault(); e.returnValue = "";
    });
    window.FewardLigacao = { ligar: ligar, emLigacao: function () { return !!L; } };
})();
