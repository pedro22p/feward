<?php
require_once "auth.php";

$id_visitado = isset($_GET["id"]) ? (int) $_GET["id"] : 0;

// Se a pessoa tentar visitar o próprio perfil por aqui, manda pro perfil normal.
if ($id_visitado === (int) $usuario_logado["id"]) {
    header("Location: perfil.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM contas WHERE id = ?");
$stmt->execute([$id_visitado]);
$perfil = $stmt->fetch();

if (!$perfil) {
    http_response_code(404);
    $pagina_ativa = "";
    ?>
    <!DOCTYPE html>
    <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Usuário não encontrado - Feward</title>
        <link rel="icon" href="img/logo.png" type="image/png">
        <link rel="stylesheet" href="estilo.css">
    </head>
    <body>
    <?php include "nav.php"; ?>
    <div class="conteudo">
        <div class="topo-pagina"><h1>Usuário não encontrado</h1></div>
        <p>Essa conta não existe ou foi removida.</p>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// enviar pedido para seguir
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["seguir"])) {
    $stmt = $pdo->prepare("INSERT IGNORE INTO amizades (usuario_id, amigo_id, status) VALUES (?, ?, 'pendente')");
    $stmt->execute([$usuario_logado["id"], $id_visitado]);

    if ($stmt->rowCount() > 0) {
        $amizade_id = (int) $pdo->lastInsertId();
        $notif = $pdo->prepare("INSERT INTO notificacoes_seguir (amizade_id, de_usuario_id, para_usuario_id) VALUES (?, ?, ?)");
        $notif->execute([$amizade_id, $usuario_logado["id"], $id_visitado]);
    }

    header("Location: perfil-usuario.php?id=" . $id_visitado);
    exit;
}

// cancelar o pedido / deixar de seguir
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["deixar_de_seguir"])) {
    // Primeiro removemos a notificação do pedido pendente, se existir.
    $pdo->prepare("DELETE ns FROM notificacoes_seguir ns
                   INNER JOIN amizades a ON a.id = ns.amizade_id
                   WHERE a.usuario_id = ? AND a.amigo_id = ?")
        ->execute([$usuario_logado["id"], $id_visitado]);

    $del = $pdo->prepare("DELETE FROM amizades WHERE usuario_id = ? AND amigo_id = ?");
    $del->execute([$usuario_logado["id"], $id_visitado]);
    header("Location: perfil-usuario.php?id=" . $id_visitado);
    exit;
}

// status atual da relação (eu -> visitado)
$stmt = $pdo->prepare("SELECT status FROM amizades WHERE usuario_id = ? AND amigo_id = ?");
$stmt->execute([$usuario_logado["id"], $id_visitado]);
$relacao = $stmt->fetchColumn();

// esse usuário me segue? (visitado -> eu)
$stmt = $pdo->prepare("SELECT status FROM amizades WHERE usuario_id = ? AND amigo_id = ?");
$stmt->execute([$id_visitado, $usuario_logado["id"]]);
$ele_me_segue = $stmt->fetchColumn() === "aceito";

$total_seguidores = $pdo->prepare("SELECT COUNT(*) FROM amizades WHERE amigo_id = ? AND status = 'aceito'");
$total_seguidores->execute([$id_visitado]);
$total_seguidores = (int) $total_seguidores->fetchColumn();
$eh_verificado = $total_seguidores >= 1000;

$total_seguindo = $pdo->prepare("SELECT COUNT(*) FROM amizades WHERE usuario_id = ? AND status = 'aceito'");
$total_seguindo->execute([$id_visitado]);
$total_seguindo = (int) $total_seguindo->fetchColumn();

$imagens = $pdo->prepare("
    SELECT imagem FROM posts
    WHERE usuario_id = ? AND imagem IS NOT NULL
    ORDER BY criado_em DESC
    LIMIT 6
");
$imagens->execute([$id_visitado]);
$imagens = $imagens->fetchAll();

$posicao_atual = $perfil["foto_perfil_pos"] ?? "50% 50%";
$status_perfil = feward_status_usuario($perfil);
$pagina_ativa = "";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Perfil de <?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?> no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title><?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?> - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .perfil-topo { display: flex; align-items: center; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }
        .perfil-nome { font-size: 26px; font-weight: bold; }
        .selo-verificado { display: inline-flex; align-items: center; justify-content: center; width: 18px; height: 18px; background: #2196f3; color: #fff; border-radius: 50%; font-size: 12px; vertical-align: middle; margin-left: 4px; }
        .perfil-bio { color: #ddd; margin-top: 6px; max-width: 480px; }
        .perfil-stats { display: flex; gap: 18px; margin-top: 8px; color: #ccc; font-size: 14px; }
        .perfil-stats strong { color: #fff; }
        .galeria { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-top: 20px; }
        .galeria img { width: 100%; height: 130px; object-fit: cover; border-radius: 10px; }
        .avatar-perfil { width: 90px; height: 90px; border-radius: 50%; object-fit: cover; background: #222; }
        .btn-seguir { background-color: #2844e2; }
        .btn-pendente { background-color: #555; cursor: default; }
        .btn-seguindo { background-color: #333; border: 1px solid rgba(255,255,255,0.3); }
        .selo-me-segue { display:inline-block; background: rgba(255,255,255,0.12); color:#ccc; font-size:12px; padding:3px 10px; border-radius:10px; margin-left:8px; }
        .status-presenca { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #aaa; margin-top: 4px; }
        .status-ponto { width: 9px; height: 9px; border-radius: 50%; background: #777; display: inline-block; }
        .status-ponto.online { background: #3ecf5e; box-shadow: 0 0 6px #3ecf5e; }
        .status-presenca.online { color: #3ecf5e; }
        .acao-seguir-form { margin-top: 4px; }
        .acao-seguir-form button { width: auto; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1><?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?><?php if ($eh_verificado): ?> <span class="selo-verificado" title="Verificado - 1000+ seguidores">✔</span><?php endif; ?></h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="card-escuro">
        <div class="perfil-topo">
            <?php if (!empty($perfil["foto_perfil"])): ?>
                <img class="avatar-perfil" src="avatar.php?id=<?= (int) $perfil["id"] ?>" alt="Foto de perfil" style="object-position: <?= htmlspecialchars($posicao_atual, ENT_QUOTES, "UTF-8") ?>; cursor: zoom-in;" onclick="abrirLightbox(this.src)">
            <?php else: ?>
                <div class="avatar-vazio">👤</div>
            <?php endif; ?>
            <div>
                <div class="perfil-nome">
                    <?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?>
                    <?php if ($eh_verificado): ?><span class="selo-verificado" title="Verificado - 1000+ seguidores">✔</span><?php endif; ?>
                    <?php if ($ele_me_segue): ?><span class="selo-me-segue">Segue você</span><?php endif; ?>
                </div>
                <?php if (!$status_perfil["oculto"]): ?>
                    <div class="status-presenca<?= $status_perfil["online"] ? " online" : "" ?>">
                        <span class="status-ponto<?= $status_perfil["online"] ? " online" : "" ?>"></span>
                        <?= $status_perfil["online"] ? "Online" : ($status_perfil["visto_texto"] ? "Visto por último " . htmlspecialchars($status_perfil["visto_texto"]) : "Offline") ?>
                    </div>
                <?php endif; ?>
                <?php if (!empty($perfil["bio"])): ?>
                    <div class="perfil-bio"><?= nl2br(htmlspecialchars($perfil["bio"], ENT_QUOTES, "UTF-8")) ?></div>
                <?php endif; ?>
                <div class="perfil-stats">
                    <span><strong><?= $total_seguidores ?></strong> seguidores</span>
                    <span><strong><?= $total_seguindo ?></strong> seguindo</span>
                </div>

                <?php if ($relacao === "aceito"): ?>
                    <form class="acao-seguir-form" method="POST" onsubmit="return confirm('Deixar de seguir <?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?>?');">
                        <input type="hidden" name="deixar_de_seguir" value="1">
                        <button class="acao btn-seguindo" type="submit">✓ Seguindo</button>
                    </form>
                <?php elseif ($relacao === "pendente"): ?>
                    <form class="acao-seguir-form" method="POST">
                        <input type="hidden" name="deixar_de_seguir" value="1">
                        <button class="acao btn-pendente" type="submit">Pedido enviado — cancelar</button>
                    </form>
                <?php else: ?>
                    <form class="acao-seguir-form" method="POST">
                        <input type="hidden" name="seguir" value="1">
                        <button class="acao btn-seguir" type="submit">+ Seguir</button>
                    </form>
                <?php endif; ?>

                <?php if ($relacao === "aceito"): ?>
                    <div class="acao-seguir-form">
                        <button class="acao" style="width:auto;background-color:#4bbae6;" onclick="window.location.href='mensagem.php?com=<?= (int) $perfil["id"] ?>'">✉️ Mensagem</button>
                    </div>
                <?php else: ?>
                    <div class="acao-seguir-form" style="color:#aaa;font-size:13px;max-width:320px;">
                        Siga <?= htmlspecialchars($perfil["nome_usuario"], ENT_QUOTES, "UTF-8") ?> (e espere aceitar o pedido) para enviar mensagem e ver os stories.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <h2 style="margin-top:30px;">Imagens</h2>
        <div class="galeria">
            <?php foreach ($imagens as $img): ?>
                <?php $img_src = "midia.php?pasta=posts&arquivo=" . urlencode($img["imagem"]); ?>
                <img src="<?= htmlspecialchars($img_src, ENT_QUOTES, "UTF-8") ?>" alt="imagem" onclick="abrirLightbox(this.src)">
            <?php endforeach; ?>
            <?php if (empty($imagens)): ?>
                <p>Nenhuma imagem publicada ainda.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="lightbox-overlay" id="lightbox-overlay" onclick="fecharLightbox()">
    <button class="lightbox-fechar" type="button" onclick="fecharLightbox()">&times;</button>
    <img id="lightbox-img" src="" alt="Imagem ampliada" onclick="event.stopPropagation()">
</div>
<script src="midia.js"></script>

</body>
</html>
