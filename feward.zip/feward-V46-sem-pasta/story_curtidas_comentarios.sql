-- Feward V36 - curtidas e comentários em stories
-- Execute depois de v18_melhorias.sql (ou a última migração que você já rodou).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.

CREATE TABLE IF NOT EXISTS story_curtidas (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    story_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_story_curtida (story_id, usuario_id),
    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_comentarios (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    story_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_story_comentarios_story (story_id, criado_em),
    FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
