<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Créditos da rede Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Créditos - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">

    <style>
        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background-image: url("img/fundo2.png");
            background-size: cover;
            background-position: center;
            color: white;
        }

        .creditos-container {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);

            background: rgba(0, 0, 0, 0.9);
            padding: 50px;
            text-align: center;
            width: 700px;
            max-width: 90vw;
        }

        .logo img {
            width: 200px;
        }

        .creditos-colunas {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            text-align: left;
            margin-top: 30px;
            gap: 30px;
        }

        .apoiadores {
            flex: 1;
        }

        .principais {
            flex: 1;
            text-align: center;
        }

        .creditos-colunas h3 {
            margin-bottom: 10px;
            color: #2844e2;
        }

        .apoiadores ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .apoiadores li {
            margin-bottom: 8px;
        }

        .principal-item {
            margin-bottom: 25px;
        }

        .principal-item .cargo {
            display: block;
            font-size: 13px;
            color: #cccccc;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 3px;
        }

        .principal-item .nome {
            font-size: 18px;
            font-weight: bold;
        }

        .voltar {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background: #2844e2;
            color: white;
            text-decoration: none;
            border-radius: 10px;
        }
    </style>
</head>

<body>

    <div class="creditos-container">

        <div class="logo">
            <img src="img/logo.png" alt="Logo Feward">
        </div>

        <h1>Créditos</h1>

        <h2>Feward</h2>

        <div class="creditos-colunas">

            <div class="apoiadores">
                <h3>Apoiadores</h3>
                <ul>
                    <li>Ana Luiza | Cary</li>
                    <li>Maria Eduarda</li>
                    <br>
                    <li>Arthur Pereira</li>
                </ul>
            </div>

            <div class="principais">
                <div class="principal-item">
                    <span class="nome">Pedro (DDRK)</span>
                    <span class="cargo">Criador do Projeto</span>
                </div>

                <div class="principal-item">
                    <span class="nome">Chris (Nullirã)</span>
                    <span class="cargo">Administrador e analista do design</span>
                </div>

                 <div class="principal-item">
                    <span class="nome">tony</span>
                    <span class="cargo">Admin ele ajudou a fazer o primeiro visual da feward</span>
                </div>
            </div>

        </div>

        <a class="voltar" href="login.php">Voltar</a>

    </div>

</body>
</html>