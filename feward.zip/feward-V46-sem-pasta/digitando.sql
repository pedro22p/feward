-- Feward V16 - indicador de digitação
-- Execute depois de curtidas_amizades.sql.

CREATE TABLE IF NOT EXISTS digitando (
    usuario_id INT UNSIGNED NOT NULL,
    destinatario_id INT UNSIGNED NOT NULL,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (usuario_id, destinatario_id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id),
    FOREIGN KEY (destinatario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
