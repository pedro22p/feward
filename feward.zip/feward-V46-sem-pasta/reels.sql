-- Feward V38 - curtidas de reels/vídeos
-- Rode uma vez no banco "feward". Os reels usam a tabela videos (tipo = 'curto'),
-- então não precisa criar mais nada.
-- (Sem chave estrangeira em video_id de propósito: o videos.id pode ser INT ou
--  INT UNSIGNED conforme o SQL que você rodou antes, e isso causaria erro.)

CREATE TABLE IF NOT EXISTS curtidas_video (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    video_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_curtida_video (video_id, usuario_id),
    KEY idx_curtida_video_usuario (usuario_id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
