<?php
require_once "auth.php";

$erro = "";

// criar uma comunidade nova
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nova_comunidade"])) {
    $nome = trim($_POST["nome"] ?? "");
    $descricao = trim($_POST["descricao"] ?? "");
    if ($nome === "") {
        $erro = "Dê um nome pra comunidade.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO comunidades (nome, descricao, criador_id) VALUES (?, ?, ?)");
            $stmt->execute([$nome, $descricao !== "" ? $descricao : null, $usuario_logado["id"]]);
            $nova_id = (int) $pdo->lastInsertId();
            $pdo->prepare("INSERT IGNORE INTO comunidade_membros (comunidade_id, usuario_id) VALUES (?, ?)")
                ->execute([$nova_id, $usuario_logado["id"]]);
            header("Location: comunidade-ver.php?id=" . $nova_id);
            exit;
        } catch (PDOException $e) {
            $erro = ($e->getCode() == 23000) ? "Já existe uma comunidade com esse nome." : "Erro ao criar comunidade.";
        }
    }
}

$comunidades = $pdo->query("
    SELECT comunidades.*,
        (SELECT COUNT(*) FROM comunidade_membros WHERE comunidade_membros.comunidade_id = comunidades.id) AS total_membros
    FROM comunidades
    ORDER BY nome
")->fetchAll();

$minhas = $pdo->prepare("SELECT comunidade_id FROM comunidade_membros WHERE usuario_id = ?");
$minhas->execute([$usuario_logado["id"]]);
$minhas_ids = array_column($minhas->fetchAll(), "comunidade_id");

$pagina_ativa = "comunidade";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Explore comunidades e participe da rede Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Comunidades - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .grade { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .card-comunidade { background: linear-gradient(160deg, #060030, #1a1a70); border-radius: 15px; padding: 20px; text-align: center; text-decoration: none; color: inherit; display: block; }
        .card-comunidade h3 { margin: 0 0 8px; font-size: 22px; }
        .card-comunidade p { margin: 0 0 10px; font-size: 13px; color: #ccc; min-height: 18px; }
        .card-comunidade .contagem { font-size: 12px; color: #9aa0e0; }
        .membro { background: #2844e2; color:#fff; font-size:11px; padding:3px 10px; border-radius:10px; display:inline-block; margin-top:8px; }
        .criar-comunidade { background: rgba(0,0,0,0.5); border-radius: 20px; padding: 20px 25px; margin-bottom: 25px; max-width: 500px; box-sizing: border-box; }
        .criar-comunidade form { display: flex; flex-direction: column; gap: 10px; }
        .criar-comunidade input { box-sizing: border-box; max-width: 100%; }

        @media (max-width: 900px) {
            .grade { grid-template-columns: repeat(2, 1fr); gap: 15px; }
            .criar-comunidade { max-width: 100%; }
        }

        @media (max-width: 600px) {
            .grade { grid-template-columns: 1fr; }
            .criar-comunidade { padding: 16px; border-radius: 14px; }
            .card-comunidade { padding: 16px; }
            .card-comunidade h3 { font-size: 19px; }
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Comunidades</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="criar-comunidade">
        <h3 style="margin-top:0;">Criar uma comunidade</h3>
        <?php if ($erro): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>
        <form method="POST">
            <input type="hidden" name="nova_comunidade" value="1">
            <input type="text" name="nome" placeholder="Nome da comunidade" maxlength="100" required>
            <input type="text" name="descricao" placeholder="Do que ela é (opcional)" maxlength="255">
            <button class="acao" type="submit">Criar</button>
        </form>
    </div>

    <div class="grade">
        <?php foreach ($comunidades as $c): ?>
            <a class="card-comunidade" href="comunidade-ver.php?id=<?= (int) $c["id"] ?>">
                <h3><?= htmlspecialchars($c["nome"]) ?></h3>
                <p><?= htmlspecialchars($c["descricao"] ?? "") ?></p>
                <span class="contagem"><?= (int) $c["total_membros"] ?> membro(s)</span>
                <?php if (in_array($c["id"], $minhas_ids)): ?><span class="membro">Você é membro</span><?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
