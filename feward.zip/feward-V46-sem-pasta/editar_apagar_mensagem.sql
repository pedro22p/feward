-- Feward V24 - editar e apagar mensagem
-- Execute depois de v18_melhorias.sql (ou a última migração que você já rodou).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.
-- Guarda se uma mensagem foi editada, pra mostrar "(editada)" na conversa,
-- e quando foi a última edição, pra quem está do outro lado da conversa
-- também ver a mensagem atualizada (não só quem editou).

ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS editada BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE mensagens ADD COLUMN IF NOT EXISTS atualizada_em TIMESTAMP NULL DEFAULT NULL;
