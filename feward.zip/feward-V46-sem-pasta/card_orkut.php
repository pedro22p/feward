<?php
// Feward V36 - Card de perfil estilo Orkut.
// Usado pelo perfil.php. Também dá para incluir em outras páginas
// (ex.: perfil-usuario.php) chamando card_orkut_carregar() + card_orkut_exibir().

function co_h($texto): string
{
    return htmlspecialchars((string) $texto, ENT_QUOTES, "UTF-8");
}

// coluna => [rótulo, tamanho máximo, tipo, opções (só para select)]
function card_orkut_campos(): array
{
    return [
        "relacionamento" => ["relacionamento", 30, "select", ["solteiro(a)", "namorando", "casado(a)", "união estável", "é complicado"]],
        "aniversario"    => ["aniversário", 10, "date", []],
        "interesses"     => ["interesses no Feward", 200, "text", []],
        "filhos"         => ["filhos", 30, "select", ["não", "sim"]],
        "etnia"          => ["etnia", 40, "text", []],
        "humor"          => ["humor", 60, "text", []],
        "orientacao"     => ["orientação sexual", 40, "text", []],
        "estilo"         => ["estilo", 40, "text", []],
        "bebo"           => ["bebo", 30, "select", ["não", "socialmente", "sim"]],
        "fumo"           => ["fumo", 30, "select", ["não", "socialmente", "sim"]],
        "animais"        => ["animais de estimação", 100, "text", []],
        "mora"           => ["mora", 60, "text", []],
        "cidade_natal"   => ["cidade natal", 80, "text", []],
        "pagina_web"     => ["página web", 255, "text", []],
        "paixoes"        => ["paixões", 200, "text", []],
        "esportes"       => ["esportes", 150, "text", []],
        "atividades"     => ["atividades", 200, "text", []],
    ];
}

// Lê os dados do card. Se a tabela ainda não existe, devolve vazio (não quebra a página).
function card_orkut_carregar(PDO $pdo, int $usuario_id): array
{
    try {
        $stmt = $pdo->prepare("SELECT * FROM perfil_orkut WHERE usuario_id = ?");
        $stmt->execute([$usuario_id]);
        return $stmt->fetch() ?: [];
    } catch (Throwable $e) {
        return [];
    }
}

// Contadores do topo do card: recados (comentários nos meus posts), fotos, vídeos e fãs.
function card_orkut_contagens(PDO $pdo, int $usuario_id, int $fas): array
{
    $c = ["recados" => 0, "fotos" => 0, "videos" => 0, "fas" => $fas];

    $consultas = [
        "recados" => "SELECT COUNT(*) FROM comentarios c JOIN posts p ON p.id = c.post_id WHERE p.usuario_id = ?",
        "fotos"   => "SELECT COUNT(*) FROM posts WHERE usuario_id = ? AND imagem IS NOT NULL",
        "videos"  => "SELECT COUNT(*) FROM videos WHERE usuario_id = ?",
    ];

    foreach ($consultas as $chave => $sql) {
        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$usuario_id]);
            $c[$chave] = (int) $stmt->fetchColumn();
        } catch (Throwable $e) {
            // tabela ausente: fica 0
        }
    }

    return $c;
}

// Valida e salva o formulário do card (cria ou atualiza a linha do usuário).
function card_orkut_salvar(PDO $pdo, int $usuario_id, array $post): void
{
    $valores = [];

    foreach (card_orkut_campos() as $coluna => [$rotulo, $max, $tipo, $opcoes]) {
        $v = trim((string) ($post[$coluna] ?? ""));

        if ($tipo === "select") {
            if (!in_array($v, $opcoes, true)) {
                $v = "";
            }
        } elseif ($tipo === "date") {
            $d = DateTime::createFromFormat("Y-m-d", $v);
            $ok = $d && $d->format("Y-m-d") === $v && $v >= "1900-01-01" && $v <= date("Y-m-d");
            $v = $ok ? $v : null;
        } elseif ($coluna === "pagina_web") {
            $v = mb_substr($v, 0, $max);
            if ($v !== "") {
                if (!preg_match('#^https?://#i', $v)) {
                    $v = "http://" . $v;
                }
                if (!filter_var($v, FILTER_VALIDATE_URL)) {
                    $v = "";
                }
            }
        } else {
            $v = mb_substr($v, 0, $max);
        }

        $valores[$coluna] = $v;
    }

    // Os nomes das colunas vêm da lista fixa acima, nunca do usuário.
    $colunas = array_keys($valores);
    $sql = "INSERT INTO perfil_orkut (usuario_id, " . implode(", ", $colunas) . ") VALUES (?, "
         . implode(", ", array_fill(0, count($colunas), "?")) . ") ON DUPLICATE KEY UPDATE "
         . implode(", ", array_map(fn($c) => "$c = VALUES($c)", $colunas));

    $pdo->prepare($sql)->execute(array_merge([$usuario_id], array_values($valores)));
}

function card_orkut_exibir(string $nome, array $dados, string $bio, array $contagens): void
{
    $meses = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];

    $aniversario = "";
    $idade = "";
    if (!empty($dados["aniversario"])) {
        try {
            $nasc = new DateTime($dados["aniversario"]);
            $aniversario = $nasc->format("j") . " " . $meses[(int) $nasc->format("n") - 1];
            $idade = (string) $nasc->diff(new DateTime("today"))->y;
        } catch (Throwable $e) {
        }
    }

    // Monta as linhas na mesma ordem do card original.
    $linhas = [];
    foreach (card_orkut_campos() as $coluna => [$rotulo]) {
        $valor = $coluna === "aniversario" ? $aniversario : trim((string) ($dados[$coluna] ?? ""));

        if ($valor !== "") {
            if ($coluna === "pagina_web") {
                $valor_html = '<a href="' . co_h($valor) . '" target="_blank" rel="noopener nofollow">' . co_h($valor) . "</a>";
            } else {
                $valor_html = co_h($valor);
            }
            $linhas[] = [$rotulo, $valor_html];
        }

        if ($coluna === "aniversario" && $idade !== "") {
            $linhas[] = ["idade", co_h($idade)];
        }

        if ($coluna === "interesses" && trim($bio) !== "") {
            $linhas[] = ["quem sou eu", nl2br(co_h($bio))];
        }
    }
    ?>
    <style>
        .orkut-card { max-width: 340px; margin: 12px 0 10px; padding: 8px; background: #d4e0f2; border: 1px solid #a9bfdc; border-radius: 6px; font-family: Verdana, Tahoma, Arial, sans-serif; font-size: 11px; color: #333333; text-align: left; }
        .orkut-card .orkut-nome { margin: 0 0 6px; font-size: 15px; font-weight: bold; color: #2d4c8a; overflow-wrap: anywhere; }
        .orkut-card .orkut-stats { display: flex; gap: 14px; margin-bottom: 8px; color: #6d7f99; font-size: 9px; }
        .orkut-card .orkut-stats div { display: flex; flex-direction: column; }
        .orkut-card .orkut-stats b { color: #2d4c8a; font-size: 11px; }
        .orkut-card .orkut-tabela { width: 100%; border-collapse: separate; border-spacing: 0 2px; }
        .orkut-card .orkut-tabela th { width: 38%; padding: 4px 6px; background: #e9f0fa; color: #6d7f99; font-weight: normal; text-align: right; vertical-align: top; }
        .orkut-card .orkut-tabela td { padding: 4px 6px; background: #f6f9fd; color: #1b2b44; font-weight: bold; vertical-align: top; overflow-wrap: anywhere; }
        .orkut-card .orkut-tabela a { color: #2d4c8a; text-decoration: none; }
        .orkut-card .orkut-tabela a:hover { text-decoration: underline; }
        .orkut-card .orkut-vazio { margin: 6px 0 2px; color: #6d7f99; }
        .orkut-editar { margin: 6px 0 0; }
        .orkut-editar summary { cursor: pointer; font-weight: bold; padding: 6px 0; }
        .orkut-editar label { display: block; margin: 10px 0 4px; font-size: 13px; }
        .orkut-editar input, .orkut-editar select { width: 100%; max-width: 420px; box-sizing: border-box; }
    </style>

    <div class="orkut-card">
        <div class="orkut-nome"><?= co_h($nome) ?></div>

        <div class="orkut-stats">
            <div>recados <b><?= (int) $contagens["recados"] ?></b></div>
            <div>fotos <b><?= (int) $contagens["fotos"] ?></b></div>
            <div>vídeos <b><?= (int) $contagens["videos"] ?></b></div>
            <div>fãs <b><?= (int) $contagens["fas"] ?></b></div>
        </div>

        <?php if ($linhas): ?>
            <table class="orkut-tabela">
                <?php foreach ($linhas as [$rotulo, $valor_html]): ?>
                    <tr><th><?= co_h($rotulo) ?>:</th><td><?= $valor_html ?></td></tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <div class="orkut-vazio">Ainda não tem informações. Use "Editar informações do card" abaixo.</div>
        <?php endif; ?>
    </div>
    <?php
}

// Formulário para editar os campos do card (fica recolhido até clicar).
function card_orkut_formulario(array $dados): void
{
    ?>
    <details class="orkut-editar">
        <summary>Editar informações do card</summary>
        <form method="POST" action="perfil.php#card-orkut">
            <input type="hidden" name="card_orkut" value="1">
            <p style="font-size:12px;color:#ccc;margin:6px 0 0;">Todos os campos são opcionais. "Quem sou eu" vem do campo Bio.</p>

            <?php foreach (card_orkut_campos() as $coluna => [$rotulo, $max, $tipo, $opcoes]): ?>
                <?php $atual = (string) ($dados[$coluna] ?? ""); ?>
                <label for="co_<?= co_h($coluna) ?>"><?= co_h($rotulo) ?></label>

                <?php if ($tipo === "select"): ?>
                    <select id="co_<?= co_h($coluna) ?>" name="<?= co_h($coluna) ?>">
                        <option value="">—</option>
                        <?php foreach ($opcoes as $op): ?>
                            <option value="<?= co_h($op) ?>"<?= $atual === $op ? " selected" : "" ?>><?= co_h($op) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php elseif ($tipo === "date"): ?>
                    <input id="co_<?= co_h($coluna) ?>" type="date" name="<?= co_h($coluna) ?>" value="<?= co_h($atual) ?>" min="1900-01-01" max="<?= date("Y-m-d") ?>">
                <?php else: ?>
                    <input id="co_<?= co_h($coluna) ?>" type="text" name="<?= co_h($coluna) ?>" value="<?= co_h($atual) ?>" maxlength="<?= (int) $max ?>">
                <?php endif; ?>
            <?php endforeach; ?>

            <button class="acao" type="submit" style="margin-top:14px;">Salvar card</button>
        </form>
    </details>
    <?php
}
