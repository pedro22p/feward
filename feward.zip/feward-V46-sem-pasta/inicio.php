<?php
require_once "auth.php";
require_once "moderacao.php";

$erro = "";

// criar novo post
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["conteudo"])) {
    $conteudo = trim($_POST["conteudo"]);
    $nome_imagem = null;

    if (!empty($_FILES["imagem"]["name"]) && $_FILES["imagem"]["error"] !== UPLOAD_ERR_NO_FILE) {
        if ($_FILES["imagem"]["error"] !== UPLOAD_ERR_OK) {
            $erro = "Erro ao enviar a imagem.";
        } else {
            $extensoes_permitidas = ["jpg", "jpeg", "png", "gif", "webp"];
            $extensao = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));
            $info_imagem = @getimagesize($_FILES["imagem"]["tmp_name"]);

            if (!in_array($extensao, $extensoes_permitidas) || $info_imagem === false) {
                $erro = "Envie apenas imagens (jpg, png, gif ou webp).";
            } elseif ($_FILES["imagem"]["size"] > 5 * 1024 * 1024) {
                $erro = "A imagem deve ter no máximo 5MB.";
            } else {
                $pasta_uploads = __DIR__ . "/uploads/posts";
                if (!is_dir($pasta_uploads)) {
                    mkdir($pasta_uploads, 0755, true);
                }
                $nome_imagem = uniqid("post_", true) . "." . $extensao;
                if (!move_uploaded_file($_FILES["imagem"]["tmp_name"], $pasta_uploads . "/" . $nome_imagem)) {
                    $erro = "Erro ao salvar a imagem.";
                    $nome_imagem = null;
                }
            }
        }
    }

    if ($erro !== "") {
        // mantém $erro já definido acima
    } elseif ($conteudo === "" && $nome_imagem === null) {
        $erro = "Escreva algo ou envie uma imagem para publicar.";
    } elseif (bloquearConteudo($conteudo)) {
        $erro = "Conteúdo bloqueado por conter palavras proibidas.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO posts (usuario_id, conteudo, imagem) VALUES (?, ?, ?)");
        $stmt->execute([$usuario_logado["id"], $conteudo !== "" ? $conteudo : null, $nome_imagem]);
        header("Location: inicio.php");
        exit;
    }
}

// publicar um story (some sozinho depois de 7 dias - veja a limpeza logo antes da consulta que traz os stories)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["novo_story"])) {
    $codigo_upload_story = (int) ($_FILES["story_arquivo"]["error"] ?? UPLOAD_ERR_NO_FILE);

    if (empty($_FILES["story_arquivo"]["name"]) || $codigo_upload_story === UPLOAD_ERR_NO_FILE) {
        $erro = "Escolha uma foto ou vídeo para o story.";
    } elseif ($codigo_upload_story === UPLOAD_ERR_INI_SIZE || $codigo_upload_story === UPLOAD_ERR_FORM_SIZE) {
        $erro = "Esse arquivo passa do limite de upload configurado no servidor. Aumente upload_max_filesize e post_max_size no php.ini (ou no .htaccess) e tente de novo.";
    } elseif ($codigo_upload_story !== UPLOAD_ERR_OK) {
        $erro = "Erro ao enviar o story.";
    } else {
        $extensoes_imagem = ["jpg", "jpeg", "png", "gif", "webp"];
        $extensoes_video = ["mp4", "webm"];
        $extensao = strtolower(pathinfo($_FILES["story_arquivo"]["name"], PATHINFO_EXTENSION));

        $eh_imagem = in_array($extensao, $extensoes_imagem, true) && @getimagesize($_FILES["story_arquivo"]["tmp_name"]) !== false;
        $eh_video = in_array($extensao, $extensoes_video, true);

        if (!$eh_imagem && !$eh_video) {
            $erro = "Envie uma imagem (jpg, png, gif, webp) ou vídeo (mp4, webm) para o story.";
        } elseif ($_FILES["story_arquivo"]["size"] > 100 * 1024 * 1024) {
            $erro = "O arquivo do story deve ter no máximo 100MB.";
        } else {
            $pasta_uploads = __DIR__ . "/uploads/stories";
            if (!is_dir($pasta_uploads)) {
                mkdir($pasta_uploads, 0755, true);
            }
            $nome_arquivo = uniqid("story_", true) . "." . $extensao;
            if (!move_uploaded_file($_FILES["story_arquivo"]["tmp_name"], $pasta_uploads . "/" . $nome_arquivo)) {
                $erro = "Erro ao salvar o story.";
            } else {
                $duracoes_validas = [6, 24, 72, 168];
                $duracao = (int) ($_POST["story_duracao"] ?? 24);
                if (!in_array($duracao, $duracoes_validas, true)) $duracao = 24;

                // música de fundo (opcional)
                $nome_musica = null;
                $erro_upload_musica = (int) ($_FILES["story_musica"]["error"] ?? UPLOAD_ERR_NO_FILE);
                if (!empty($_FILES["story_musica"]["name"]) && $erro_upload_musica === UPLOAD_ERR_OK) {
                    $extensoes_audio = ["mp3", "ogg", "wav", "m4a"];
                    $extensao_audio = strtolower(pathinfo($_FILES["story_musica"]["name"], PATHINFO_EXTENSION));
                    if (in_array($extensao_audio, $extensoes_audio, true) && $_FILES["story_musica"]["size"] <= 15 * 1024 * 1024) {
                        $nome_musica_tentativa = uniqid("musica_", true) . "." . $extensao_audio;
                        if (move_uploaded_file($_FILES["story_musica"]["tmp_name"], $pasta_uploads . "/" . $nome_musica_tentativa)) {
                            $nome_musica = $nome_musica_tentativa;
                        }
                    }
                }

                // stickers (emojis posicionados sobre o story), montados no editor pelo navegador e enviados como JSON
                $stickers_json = null;
                $stickers_brutos = json_decode($_POST["story_stickers"] ?? "", true);
                if (is_array($stickers_brutos)) {
                    $stickers_limpos = [];
                    foreach (array_slice($stickers_brutos, 0, 10) as $st) {
                        if (!is_array($st) || !isset($st["emoji"], $st["x"], $st["y"])) continue;
                        $emoji_sticker = mb_substr((string) $st["emoji"], 0, 8);
                        if ($emoji_sticker === "") continue;
                        $stickers_limpos[] = [
                            "emoji" => $emoji_sticker,
                            "x" => max(0, min(100, (float) $st["x"])),
                            "y" => max(0, min(100, (float) $st["y"])),
                        ];
                    }
                    if ($stickers_limpos) {
                        $stickers_json = json_encode($stickers_limpos, JSON_UNESCAPED_UNICODE);
                    }
                }

                try {
                    $stmt = $pdo->prepare("INSERT INTO stories (usuario_id, arquivo, tipo, duracao_horas, musica, stickers) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$usuario_logado["id"], $nome_arquivo, $eh_video ? "video" : "imagem", $duracao, $nome_musica, $stickers_json]);
                } catch (PDOException $e) {
                    // Colunas musica/stickers ainda não existem nesse banco (falta rodar melhorias_stories_v28.sql)
                    $stmt = $pdo->prepare("INSERT INTO stories (usuario_id, arquivo, tipo, duracao_horas) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$usuario_logado["id"], $nome_arquivo, $eh_video ? "video" : "imagem", $duracao]);
                }
                header("Location: inicio.php");
                exit;
            }
        }
    }
}

// curtir / descurtir um story (AJAX)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["curtir_story_id"])) {
    $story_id = (int) $_POST["curtir_story_id"];
    if (!feward_pode_ver_story($pdo, $story_id, (int) $usuario_logado["id"])) {
        header("Content-Type: application/json");
        http_response_code(403);
        echo json_encode(["ok" => false, "erro" => "Siga essa pessoa para interagir com o story."]);
        exit;
    }

    // o dono do story não pode curtir o próprio story
    $dono = $pdo->prepare("SELECT usuario_id FROM stories WHERE id = ?");
    $dono->execute([$story_id]);
    if ((int) $dono->fetchColumn() === (int) $usuario_logado["id"]) {
        header("Content-Type: application/json");
        http_response_code(403);
        echo json_encode(["erro" => "Você não pode curtir o próprio story."]);
        exit;
    }

    $ja = $pdo->prepare("SELECT 1 FROM story_curtidas WHERE story_id = ? AND usuario_id = ?");
    $ja->execute([$story_id, $usuario_logado["id"]]);
    if ($ja->fetch()) {
        $pdo->prepare("DELETE FROM story_curtidas WHERE story_id = ? AND usuario_id = ?")->execute([$story_id, $usuario_logado["id"]]);
        $curti = false;
    } else {
        $pdo->prepare("INSERT IGNORE INTO story_curtidas (story_id, usuario_id) VALUES (?, ?)")->execute([$story_id, $usuario_logado["id"]]);
        $curti = true;
    }
    $total = $pdo->prepare("SELECT COUNT(*) FROM story_curtidas WHERE story_id = ?");
    $total->execute([$story_id]);
    header("Content-Type: application/json");
    echo json_encode(["curti" => $curti, "total" => (int) $total->fetchColumn()]);
    exit;
}

// comentar em um story (AJAX)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["comentario_story_id"])) {
    $story_id = (int) $_POST["comentario_story_id"];
    if (!feward_pode_ver_story($pdo, $story_id, (int) $usuario_logado["id"])) {
        header("Content-Type: application/json");
        http_response_code(403);
        echo json_encode(["ok" => false, "erro" => "Siga essa pessoa para interagir com o story."]);
        exit;
    }
    $texto = trim($_POST["comentario_texto"] ?? "");
    header("Content-Type: application/json");

    // o dono do story não pode comentar no próprio story
    $dono = $pdo->prepare("SELECT usuario_id FROM stories WHERE id = ?");
    $dono->execute([$story_id]);
    if ((int) $dono->fetchColumn() === (int) $usuario_logado["id"]) {
        http_response_code(403);
        echo json_encode(["ok" => false, "erro" => "Você não pode comentar no próprio story."]);
        exit;
    }

    if ($texto === "") {
        echo json_encode(["ok" => false, "erro" => "Escreva algo."]);
        exit;
    }
    if (bloquearConteudo($texto)) {
        echo json_encode(["ok" => false, "erro" => "Comentário bloqueado por conter palavras proibidas."]);
        exit;
    }
    $pdo->prepare("INSERT INTO story_comentarios (story_id, usuario_id, conteudo) VALUES (?, ?, ?)")
        ->execute([$story_id, $usuario_logado["id"], $texto]);
    $total = $pdo->prepare("SELECT COUNT(*) FROM story_comentarios WHERE story_id = ?");
    $total->execute([$story_id]);
    echo json_encode([
        "ok" => true,
        "total" => (int) $total->fetchColumn(),
        "nome_usuario" => $usuario_logado["nome_usuario"],
        "conteudo" => $texto,
    ]);
    exit;
}

// ver os comentários de um story (AJAX)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["listar_comentarios_story_id"])) {
    $story_id = (int) $_POST["listar_comentarios_story_id"];
    if (!feward_pode_ver_story($pdo, $story_id, (int) $usuario_logado["id"])) {
        header("Content-Type: application/json");
        http_response_code(403);
        echo json_encode(["ok" => false, "erro" => "Siga essa pessoa para interagir com o story."]);
        exit;
    }
    $cs = $pdo->prepare("
        SELECT story_comentarios.conteudo, contas.nome_usuario
        FROM story_comentarios
        JOIN contas ON contas.id = story_comentarios.usuario_id
        WHERE story_comentarios.story_id = ?
        ORDER BY story_comentarios.criado_em ASC
    ");
    $cs->execute([$story_id]);
    header("Content-Type: application/json");
    echo json_encode($cs->fetchAll());
    exit;
}

// marcar um story como visto
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["marcar_story_visto"])) {
    $story_visto_id = (int) $_POST["marcar_story_visto"];
    $dono_story = $pdo->prepare("SELECT usuario_id FROM stories WHERE id = ?");
    $dono_story->execute([$story_visto_id]);
    $dono_story = (int) $dono_story->fetchColumn();
    // V30: só registra se eu sigo o dono, e o próprio dono não conta como visualização
    if (empty($usuario_logado["modo_fantasma"]) && $dono_story !== (int) $usuario_logado["id"]
        && feward_sigo($pdo, (int) $usuario_logado["id"], $dono_story)) {
        $stmt = $pdo->prepare("INSERT IGNORE INTO story_visualizacoes (story_id, usuario_id) VALUES (?, ?)");
        $stmt->execute([$story_visto_id, $usuario_logado["id"]]);
    }
    echo "ok";
    exit;
}

// V30: total e lista de quem visualizou um story (AJAX) - só o dono do story
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["listar_visualizacoes_story_id"])) {
    $story_id = (int) $_POST["listar_visualizacoes_story_id"];
    header("Content-Type: application/json");

    $dono = $pdo->prepare("SELECT 1 FROM stories WHERE id = ? AND usuario_id = ?");
    $dono->execute([$story_id, $usuario_logado["id"]]);
    if (!$dono->fetchColumn()) {
        http_response_code(403);
        echo json_encode(["ok" => false, "erro" => "Só quem postou o story vê as visualizações."]);
        exit;
    }

    $total = $pdo->prepare("SELECT COUNT(*) FROM story_visualizacoes WHERE story_id = ? AND usuario_id != ?");
    $total->execute([$story_id, $usuario_logado["id"]]);

    $lista = $pdo->prepare("
        SELECT contas.id, contas.nome_usuario,
               (contas.foto_perfil IS NOT NULL AND contas.foto_perfil != '') AS tem_foto,
               GREATEST(TIMESTAMPDIFF(SECOND, sv.visto_em, NOW()), 0) AS segundos
        FROM story_visualizacoes sv
        JOIN contas ON contas.id = sv.usuario_id
        WHERE sv.story_id = ? AND sv.usuario_id != ?
        ORDER BY sv.visto_em DESC
        LIMIT 300
    ");
    $lista->execute([$story_id, $usuario_logado["id"]]);

    echo json_encode([
        "ok" => true,
        "total" => (int) $total->fetchColumn(),
        "visualizacoes" => array_map(function ($v) {
            return [
                "id" => (int) $v["id"],
                "nome_usuario" => $v["nome_usuario"],
                "tem_foto" => (bool) $v["tem_foto"],
                "segundos" => (int) $v["segundos"],
            ];
        }, $lista->fetchAll()),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// excluir um story (somente o dono pode excluir o próprio story)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["excluir_story_id"])) {
    $story_id = (int) $_POST["excluir_story_id"];

    $stmt = $pdo->prepare("SELECT * FROM stories WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$story_id, $usuario_logado["id"]]);
    $story_para_excluir = $stmt->fetch();

    if ($story_para_excluir) {
        if (!empty($story_para_excluir["arquivo"])) {
            $arquivo_story = __DIR__ . "/uploads/stories/" . $story_para_excluir["arquivo"];
            if (is_file($arquivo_story)) {
                @unlink($arquivo_story);
            }
        }
        if (!empty($story_para_excluir["musica"])) {
            $arquivo_musica = __DIR__ . "/uploads/stories/" . $story_para_excluir["musica"];
            if (is_file($arquivo_musica)) {
                @unlink($arquivo_musica);
            }
        }
        $pdo->prepare("DELETE FROM story_visualizacoes WHERE story_id = ?")->execute([$story_id]);
        $pdo->prepare("DELETE FROM stories WHERE id = ?")->execute([$story_id]);
        echo "ok";
    } else {
        http_response_code(403);
        echo "erro";
    }
    exit;
}

// salvar um post
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["salvar_post_id"])) {
    $stmt = $pdo->prepare("INSERT IGNORE INTO salvos (usuario_id, post_id) VALUES (?, ?)");
    $stmt->execute([$usuario_logado["id"], (int) $_POST["salvar_post_id"]]);
    header("Location: inicio.php");
    exit;
}

// curtir / descurtir um post
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["curtir_post_id"])) {
    $post_id = (int) $_POST["curtir_post_id"];
    $ja_curtiu = $pdo->prepare("SELECT 1 FROM curtidas WHERE usuario_id = ? AND post_id = ?");
    $ja_curtiu->execute([$usuario_logado["id"], $post_id]);
    if ($ja_curtiu->fetch()) {
        $pdo->prepare("DELETE FROM curtidas WHERE usuario_id = ? AND post_id = ?")->execute([$usuario_logado["id"], $post_id]);
    } else {
        $pdo->prepare("INSERT IGNORE INTO curtidas (usuario_id, post_id) VALUES (?, ?)")->execute([$usuario_logado["id"], $post_id]);
    }
    header("Location: inicio.php");
    exit;
}

// comentar em um post
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["comentario_post_id"])) {
    $texto = trim($_POST["comentario_texto"]);
    if ($texto !== "") {
        if (bloquearConteudo($texto)) {
            $erro = "Comentário bloqueado por conter palavras proibidas.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO comentarios (post_id, usuario_id, conteudo) VALUES (?, ?, ?)");
            $stmt->execute([(int) $_POST["comentario_post_id"], $usuario_logado["id"], $texto]);
        }
    }
    header("Location: inicio.php");
    exit;
}

// editar um comentário (somente o dono do comentário)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["editar_comentario_id"])) {
    $comentario_id = (int) $_POST["editar_comentario_id"];
    $novo_texto = trim($_POST["novo_comentario_texto"] ?? "");
    if ($novo_texto !== "" && !bloquearConteudo($novo_texto)) {
        $stmt = $pdo->prepare("UPDATE comentarios SET conteudo = ? WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$novo_texto, $comentario_id, $usuario_logado["id"]]);
    }
    header("Location: inicio.php");
    exit;
}

// excluir um comentário (somente o dono do comentário)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["excluir_comentario_id"])) {
    $comentario_id = (int) $_POST["excluir_comentario_id"];
    $pdo->prepare("DELETE FROM comentarios WHERE id = ? AND usuario_id = ?")
        ->execute([$comentario_id, $usuario_logado["id"]]);
    header("Location: inicio.php");
    exit;
}

$posts_stmt = $pdo->prepare("
    SELECT posts.*, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos,
        (SELECT COUNT(*) FROM curtidas WHERE curtidas.post_id = posts.id) AS total_curtidas,
        EXISTS(SELECT 1 FROM curtidas WHERE curtidas.post_id = posts.id AND curtidas.usuario_id = ?) AS curti,
        (SELECT COUNT(*) FROM amizades WHERE amizades.amigo_id = contas.id AND amizades.status = 'aceito') AS autor_seguidores
    FROM posts
    JOIN contas ON contas.id = posts.usuario_id
    ORDER BY posts.criado_em DESC
    LIMIT 20
");
$posts_stmt->execute([$usuario_logado["id"]]);
$posts = $posts_stmt->fetchAll();

// Busca os comentários dos posts carregados acima, com a foto de quem comentou, para exibir embaixo de cada um.
$comentarios_por_post = [];
if (!empty($posts)) {
    $ids_posts = array_column($posts, "id");
    $marcadores = implode(",", array_fill(0, count($ids_posts), "?"));
    $comentarios_stmt = $pdo->prepare("
        SELECT comentarios.id, comentarios.post_id, comentarios.conteudo, comentarios.criado_em,
            contas.id AS autor_id, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos
        FROM comentarios
        JOIN contas ON contas.id = comentarios.usuario_id
        WHERE comentarios.post_id IN ($marcadores)
        ORDER BY comentarios.criado_em ASC
    ");
    $comentarios_stmt->execute($ids_posts);
    foreach ($comentarios_stmt->fetchAll() as $com) {
        $comentarios_por_post[$com["post_id"]][] = $com;
    }
}

// Apaga de vez (linha do banco + arquivo) os stories com mais de 7 dias.
$stories_expirados = $pdo->query("SELECT id, arquivo FROM stories WHERE criado_em <= (NOW() - INTERVAL duracao_horas HOUR)")->fetchAll();
if ($stories_expirados) {
    foreach ($stories_expirados as $exp) {
        if (!empty($exp["arquivo"])) {
            $arquivo_expirado = __DIR__ . "/uploads/stories/" . $exp["arquivo"];
            if (is_file($arquivo_expirado)) {
                @unlink($arquivo_expirado);
            }
        }
    }
    $pdo->exec("DELETE FROM story_visualizacoes WHERE story_id IN (SELECT id FROM (SELECT id FROM stories WHERE criado_em <= (NOW() - INTERVAL duracao_horas HOUR)) AS t)");
    $pdo->exec("DELETE FROM stories WHERE criado_em <= (NOW() - INTERVAL duracao_horas HOUR)");
}

// Stories ativos (últimos 7 dias), agrupados por autor, mais recente primeiro.
try {
    $stories_stmt = $pdo->prepare("
        SELECT stories.id, stories.usuario_id, stories.arquivo, stories.tipo, stories.criado_em,
            stories.musica, stories.stickers,
            contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos,
            (SELECT COUNT(*) FROM story_curtidas WHERE story_curtidas.story_id = stories.id) AS total_curtidas,
            EXISTS(SELECT 1 FROM story_curtidas WHERE story_curtidas.story_id = stories.id AND story_curtidas.usuario_id = ?) AS curti,
            (SELECT COUNT(*) FROM story_comentarios WHERE story_comentarios.story_id = stories.id) AS total_comentarios,
            EXISTS(SELECT 1 FROM story_visualizacoes WHERE story_visualizacoes.story_id = stories.id AND story_visualizacoes.usuario_id = ?) AS visto
        FROM stories
        JOIN contas ON contas.id = stories.usuario_id
        WHERE stories.criado_em > (NOW() - INTERVAL stories.duracao_horas HOUR)
        ORDER BY stories.criado_em DESC
    ");
    $stories_stmt->execute([$usuario_logado["id"], $usuario_logado["id"]]);
    $stories_todos = $stories_stmt->fetchAll();
} catch (PDOException $e) {
    try {
        // Colunas musica/stickers ainda não existem nesse banco (falta rodar melhorias_stories_v28.sql)
        $stories_stmt = $pdo->prepare("
            SELECT stories.id, stories.usuario_id, stories.arquivo, stories.tipo, stories.criado_em,
                NULL AS musica, NULL AS stickers,
                contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos,
                (SELECT COUNT(*) FROM story_curtidas WHERE story_curtidas.story_id = stories.id) AS total_curtidas,
                EXISTS(SELECT 1 FROM story_curtidas WHERE story_curtidas.story_id = stories.id AND story_curtidas.usuario_id = ?) AS curti,
                (SELECT COUNT(*) FROM story_comentarios WHERE story_comentarios.story_id = stories.id) AS total_comentarios,
                EXISTS(SELECT 1 FROM story_visualizacoes WHERE story_visualizacoes.story_id = stories.id AND story_visualizacoes.usuario_id = ?) AS visto
            FROM stories
            JOIN contas ON contas.id = stories.usuario_id
            WHERE stories.criado_em > (NOW() - INTERVAL stories.duracao_horas HOUR)
            ORDER BY stories.criado_em DESC
        ");
        $stories_stmt->execute([$usuario_logado["id"], $usuario_logado["id"]]);
        $stories_todos = $stories_stmt->fetchAll();
    } catch (PDOException $e2) {
        // Tabelas story_curtidas/story_comentarios ainda não existem nesse banco
        // (falta rodar story_curtidas_comentarios.sql) - o feed continua funcionando,
        // só sem curtida/comentário em story até o SQL ser executado.
        $stories_stmt = $pdo->prepare("
            SELECT stories.id, stories.usuario_id, stories.arquivo, stories.tipo, stories.criado_em,
                NULL AS musica, NULL AS stickers,
                contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos,
                0 AS total_curtidas, 0 AS curti, 0 AS total_comentarios,
                EXISTS(SELECT 1 FROM story_visualizacoes WHERE story_visualizacoes.story_id = stories.id AND story_visualizacoes.usuario_id = ?) AS visto
            FROM stories
            JOIN contas ON contas.id = stories.usuario_id
            WHERE stories.criado_em > (NOW() - INTERVAL stories.duracao_horas HOUR)
            ORDER BY stories.criado_em DESC
        ");
        $stories_stmt->execute([$usuario_logado["id"]]);
        $stories_todos = $stories_stmt->fetchAll();
    }
}

// V30: só aparecem os stories meus e de quem eu sigo.
$seguidos_ids = feward_ids_seguidos($pdo, (int) $usuario_logado["id"]);
$stories_todos = array_values(array_filter($stories_todos, function ($s) use ($seguidos_ids, $usuario_logado) {
    return (int) $s["usuario_id"] === (int) $usuario_logado["id"] || isset($seguidos_ids[(int) $s["usuario_id"]]);
}));

// V30: total de visualizações dos MEUS stories (a lista de quem viu vem ao abrir o painel).
$ids_meus_stories = [];
foreach ($stories_todos as $s) {
    if ((int) $s["usuario_id"] === (int) $usuario_logado["id"]) $ids_meus_stories[] = (int) $s["id"];
}
$views_por_story = [];
if ($ids_meus_stories) {
    $marc = implode(",", array_fill(0, count($ids_meus_stories), "?"));
    $stmt_views = $pdo->prepare("SELECT story_id, COUNT(*) FROM story_visualizacoes WHERE story_id IN ($marc) AND usuario_id != ? GROUP BY story_id");
    $stmt_views->execute(array_merge($ids_meus_stories, [$usuario_logado["id"]]));
    foreach ($stmt_views->fetchAll(PDO::FETCH_NUM) as $linha) $views_por_story[(int) $linha[0]] = (int) $linha[1];
}
foreach ($stories_todos as $i => $s) {
    $stories_todos[$i]["total_visualizacoes"] = $views_por_story[(int) $s["id"]] ?? 0;
}

$stories_por_usuario = [];
foreach ($stories_todos as $s) {
    if (!isset($stories_por_usuario[$s["usuario_id"]])) {
        $stories_por_usuario[$s["usuario_id"]] = [
            "usuario_id" => $s["usuario_id"],
            "nome_usuario" => $s["nome_usuario"],
            "foto_perfil" => $s["foto_perfil"],
            "foto_perfil_pos" => $s["foto_perfil_pos"],
            "itens" => [],
        ];
    }
    $stories_por_usuario[$s["usuario_id"]]["itens"][] = $s;
}
// Marca cada grupo (que não seja o meu) como "todos vistos" quando já vi
// todos os itens daquele autor - usado pra deixar o anel cinza na faixa.
foreach ($stories_por_usuario as $uid_grupo => $dados_grupo) {
    $todos_vistos = (int) $uid_grupo !== (int) $usuario_logado["id"];
    if ($todos_vistos) {
        foreach ($dados_grupo["itens"] as $item_grupo) {
            if (!(bool) $item_grupo["visto"]) {
                $todos_vistos = false;
                break;
            }
        }
    }
    $stories_por_usuario[$uid_grupo]["todos_vistos"] = $todos_vistos;
}
// Meu grupo de stories (se eu tiver) sempre primeiro.
if (isset($stories_por_usuario[$usuario_logado["id"]])) {
    $meu_grupo = $stories_por_usuario[$usuario_logado["id"]];
    unset($stories_por_usuario[$usuario_logado["id"]]);
    $stories_por_usuario = [$usuario_logado["id"] => $meu_grupo] + $stories_por_usuario;
}

$comunidades_alta = $pdo->query("SELECT nome FROM comunidades ORDER BY id LIMIT 4")->fetchAll();

$pagina_ativa = "inicio";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Feward: rede social para posts, comunidades, vídeos e mensagens.">
    <meta name="theme-color" content="#0b1050">
    <title>Início - Feward</title>
    <link rel="icon" type="image/svg+xml" href="img/favicon.svg">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .layout { display: flex; gap: 25px; }
        .coluna-feed { flex: 2; }
        .coluna-lateral { flex: 1; }
        .post { background: linear-gradient(160deg, #dfe4ea, #ffffff); color: #111; border-radius: 15px; margin-bottom: 20px; overflow: hidden; }
        .post-cabecalho { display: flex; align-items: center; gap: 10px; padding: 12px 15px; }
        .post-cabecalho a.avatar-link { display: flex; align-items: center; gap: 10px; color: inherit; text-decoration: none; }
        .post-cabecalho a.avatar-link:hover strong { color: #2844e2; }
        .post-imagem { width: 100%; max-height: 520px; object-fit: contain; background: #000; display: block; }
        .post-texto { padding: 10px 15px; }
        .post-comentario-form { display: flex; padding: 10px 15px 15px; gap: 8px; align-items: center; }
        .post-comentario-form input { border-radius: 15px; }
        .post-comentarios { padding: 0 15px 8px; display: flex; flex-direction: column; gap: 8px; }
        .post-comentario { display: flex; align-items: flex-start; gap: 8px; font-size: 14px; color: #222; background: #f0f2f5; border-radius: 14px; padding: 8px 12px; }
        .post-comentario a { flex-shrink: 0; }
        .post-comentario strong { color: #000; }
        .post-comentario-texto { flex: 1; min-width: 0; overflow-wrap: anywhere; word-break: break-word; }
        .post-comentario-acoes { display: flex; gap: 6px; margin-left: 4px; flex-shrink: 0; }
        .post-comentario-acoes button { background: none; border: none; cursor: pointer; font-size: 12px; color: #888; padding: 0; }
        .post-comentario-acoes button:hover { color: #333; }
        .post-comentario-editar { display: none; flex: 1; gap: 6px; align-items: center; }
        .post-comentario-editar.ativo { display: flex; }
        .post-comentario-editar input[type=text] { flex: 1; border-radius: 12px; padding: 6px 10px; font-size: 13px; }
        .post-comentario.editando .post-comentario-texto { display: none; }
        .avatar-mini { width: 30px; height: 30px; min-width: 30px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; }
        .selo-verificado { display: inline-flex; align-items: center; justify-content: center; width: 15px; height: 15px; background: #2196f3; color: #fff; border-radius: 50%; font-size: 10px; vertical-align: middle; }
        .baixar-midia { position: absolute; bottom: 10px; right: 10px; background: rgba(0,0,0,0.55); color: #fff; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-decoration: none; font-size: 15px; }
        .avatar-mini-pequeno { width: 26px; height: 26px; min-width: 26px; border-radius: 50%; object-fit: cover; background: #ccc; display: inline-flex; align-items: center; justify-content: center; font-size: 13px; }
        .criar-post { background: rgba(0,0,0,0.5); border-radius: 30px; padding: 15px 25px; margin-bottom: 25px; }
        .criar-post form { display: flex; flex-direction: column; gap: 10px; }
        .criar-post textarea { min-height: 45px; border-radius: 20px; resize: vertical; }
        .comunidade-linha { padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.15); }

        .faixa-stories { display: flex; gap: 14px; overflow-x: auto; padding: 4px 2px 18px; margin-bottom: 5px; }
        .story-bolha { display: flex; flex-direction: column; align-items: center; gap: 6px; flex-shrink: 0; width: 72px; text-decoration: none; color: inherit; background: none; border: none; cursor: pointer; font-family: inherit; }
        .story-anel { width: 64px; height: 64px; border-radius: 50%; padding: 3px; background: linear-gradient(135deg, #ff8a3d, #ff3b6b, #2844e2); display: flex; align-items: center; justify-content: center; }
        .story-anel.visto { background: #555; }
        .story-anel.adicionar { background: #2a2a2a; }
        .story-anel img, .story-anel .avatar-vazio-story { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; background: #3a3d63; display: flex; align-items: center; justify-content: center; border: 2px solid #142080; }
        .story-anel .simbolo-mais { font-size: 24px; color: #4bbae6; }
        .story-bolha span { font-size: 11px; text-align: center; color: #ccc; max-width: 72px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .story-bolha-wrap { position: relative; flex-shrink: 0; width: 72px; }
        .story-add-mais { position: absolute; top: 42px; left: 42px; width: 22px; height: 22px; border-radius: 50%; background: #2844e2; color: #fff; font-size: 16px; line-height: 22px; text-align: center; border: 2px solid #0b1050; cursor: pointer; display: block; }
        .story-visor-excluir { position: absolute; top: 18px; right: 56px; background: none; border: none; color: #fff; font-size: 22px; cursor: pointer; z-index: 2; }

        .story-visor-overlay { display: none; position: fixed; inset: 0; background: #000; z-index: 300; }
        .story-visor-overlay.aberto { display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .story-visor-barra { position: absolute; top: 10px; left: 10px; right: 10px; display: flex; gap: 4px; }
        .story-visor-barra span { flex: 1; height: 3px; background: rgba(255,255,255,0.3); border-radius: 3px; overflow: hidden; }
        .story-visor-barra span i { display: block; height: 100%; background: #fff; width: 0%; }
        .story-visor-topo { position: absolute; top: 20px; left: 10px; right: 10px; display: flex; align-items: center; gap: 8px; color: #fff; }
        .story-visor-fechar { position: absolute; top: 18px; right: 14px; background: none; border: none; color: #fff; font-size: 28px; cursor: pointer; z-index: 2; }
        .story-visor-midia-wrap { position: relative; width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; }
        .story-visor-midia { max-width: 100%; max-height: 100%; object-fit: contain; }
        .story-visor-nav { position: absolute; top: 0; bottom: 74px; width: 35%; background: transparent; border: none; cursor: pointer; }
        .story-visor-nav.anterior { left: 0; }
        .story-visor-nav.proximo { right: 0; }
        .story-visor-rodape { position: absolute; bottom: 14px; left: 14px; right: 14px; display: flex; gap: 8px; align-items: center; z-index: 3; }
        .story-visor-rodape input[type=text] { flex: 1; border-radius: 20px; padding: 10px 16px; background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.4); color: #fff; }
        .story-visor-rodape input[type=text]::placeholder { color: #ddd; }
        .story-visor-rodape button { background: none; border: none; color: #fff; font-size: 20px; cursor: pointer; display: flex; align-items: center; gap: 4px; }
        .story-visor-rodape button span { font-size: 13px; }
        .story-visor-comentarios { position: absolute; bottom: 62px; left: 14px; right: 14px; max-height: 220px; overflow-y: auto; display: none; flex-direction: column; gap: 6px; z-index: 3; }
        .story-visor-comentarios.aberto { display: flex; }
        .story-visor-comentario { background: rgba(0,0,0,0.55); color: #fff; font-size: 13px; padding: 6px 12px; border-radius: 14px; align-self: flex-start; max-width: 90%; overflow-wrap: anywhere; }
        .story-visor-comentario strong { margin-right: 4px; }
        .story-visor-midia { max-height: 100vh; }
        .story-visor-sticker { position: absolute; transform: translate(-50%, -50%); font-size: 42px; z-index: 2; pointer-events: none; text-shadow: 0 2px 6px rgba(0,0,0,0.4); }
        .story-visor-rodape.escondido { display: none; }
        .story-visor-views { position: absolute; bottom: 14px; left: 50%; transform: translateX(-50%); background: rgba(0,0,0,0.55); border: none; color: #fff; border-radius: 20px; padding: 9px 18px; font-size: 14px; cursor: pointer; z-index: 3; }
        .story-views-painel { display: none; position: absolute; left: 0; right: 0; bottom: 0; max-height: 60%; background: #14163a; border-radius: 16px 16px 0 0; z-index: 5; flex-direction: column; color: #fff; }
        .story-views-painel.aberto { display: flex; }
        .story-views-topo { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.12); }
        .story-views-topo button { background: none; border: none; color: #fff; font-size: 24px; cursor: pointer; }
        #story-views-lista { overflow-y: auto; padding: 6px 16px 16px; }
        .story-views-item { display: flex; align-items: center; gap: 10px; padding: 8px 0; }
        .story-views-item img, .story-views-item .sem-foto { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: flex; align-items: center; justify-content: center; }
        .story-views-item small { margin-left: auto; color: #aaa; }

        .story-editor-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 320; align-items: center; justify-content: center; padding: 16px; }
        .story-editor-overlay.aberto { display: flex; }
        .story-editor-caixa { background: #14163a; border-radius: 16px; padding: 18px; width: 100%; max-width: 380px; max-height: 92vh; overflow-y: auto; position: relative; display: flex; flex-direction: column; gap: 14px; }
        .story-editor-fechar { position: absolute; top: 10px; right: 14px; background: none; border: none; color: #fff; font-size: 24px; cursor: pointer; }
        .story-editor-preview { position: relative; width: 100%; aspect-ratio: 9/16; max-height: 50vh; background: #000; border-radius: 12px; overflow: hidden; display: flex; align-items: center; justify-content: center; touch-action: none; }
        .story-editor-preview img, .story-editor-preview video { max-width: 100%; max-height: 100%; object-fit: contain; }
        .story-editor-sticker { position: absolute; font-size: 40px; transform: translate(-50%, -50%); cursor: grab; user-select: none; touch-action: none; text-shadow: 0 2px 6px rgba(0,0,0,0.5); }
        .story-editor-campo { display: flex; flex-direction: column; gap: 6px; color: #ddd; font-size: 13px; }
        .story-editor-campo select { border-radius: 10px; padding: 8px 10px; }
        .story-editor-emojis { display: flex; flex-wrap: wrap; gap: 6px; }
        .story-editor-emojis button { background: #23255c; border: none; border-radius: 10px; font-size: 20px; padding: 6px 9px; cursor: pointer; }
        .story-editor-dica { font-size: 11px; color: #999; }
        .story-editor-botao-musica { background: #23255c; color: #fff; border: none; border-radius: 10px; padding: 8px 12px; cursor: pointer; text-align: left; width: fit-content; }
        .story-editor-musica-nome { font-size: 12px; color: #bbb; overflow-wrap: anywhere; }
        .story-editor-remover-musica { background: none; border: none; color: #ff6b6b; cursor: pointer; text-align: left; padding: 0; width: fit-content; font-size: 12px; }
        .story-editor-publicar { background: linear-gradient(135deg, #ff8a3d, #ff3b6b); color: #fff; border: none; border-radius: 24px; padding: 12px; font-weight: 600; cursor: pointer; }
        @media (max-width: 480px) {
            .story-anel { width: 58px; height: 58px; }
            .story-bolha { width: 64px; }
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Início</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <?php if ($erro): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>

    <div class="layout">
        <div class="coluna-feed">

            <div class="faixa-stories">
                <?php if (isset($stories_por_usuario[$usuario_logado["id"]])): ?>
                    <div class="story-bolha-wrap">
                        <button type="button" class="story-bolha" onclick="abrirStory(<?= (int) $usuario_logado["id"] ?>)">
                            <span class="story-anel">
                                <?php if (!empty($usuario_logado["foto_perfil"])): ?>
                                    <img src="avatar.php" alt="" style="object-position: <?= htmlspecialchars($usuario_logado["foto_perfil_pos"] ?? "50% 50%") ?>;">
                                <?php else: ?>
                                    <span class="avatar-vazio-story">👤</span>
                                <?php endif; ?>
                            </span>
                            <span>Seu story</span>
                        </button>
                        <label class="story-add-mais" for="input-novo-story" title="Adicionar outro story" onclick="event.stopPropagation()">+</label>
                    </div>
                <?php else: ?>
                    <label class="story-bolha" for="input-novo-story">
                        <span class="story-anel adicionar">
                            <span class="simbolo-mais">+</span>
                        </span>
                        <span>Criar story</span>
                    </label>
                <?php endif; ?>

                <?php foreach ($stories_por_usuario as $grupo): ?>
                    <?php if ((int) $grupo["usuario_id"] === (int) $usuario_logado["id"]) continue; ?>
                    <button type="button" class="story-bolha" onclick="abrirStory(<?= (int) $grupo["usuario_id"] ?>)">
                        <span class="story-anel<?= !empty($grupo["todos_vistos"]) ? " visto" : "" ?>" id="story-anel-<?= (int) $grupo["usuario_id"] ?>">
                            <?php if (!empty($grupo["foto_perfil"])): ?>
                                <img src="avatar.php?id=<?= (int) $grupo["usuario_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($grupo["foto_perfil_pos"] ?? "50% 50%") ?>;">
                            <?php else: ?>
                                <span class="avatar-vazio-story">👤</span>
                            <?php endif; ?>
                        </span>
                        <span><?= htmlspecialchars($grupo["nome_usuario"]) ?></span>
                    </button>
                <?php endforeach; ?>
            </div>

            <form id="form-novo-story" method="POST" enctype="multipart/form-data" style="display:none;">
                <input type="hidden" name="novo_story" value="1">
                <input type="hidden" id="input-duracao-story" name="story_duracao" value="24">
                <input type="hidden" id="input-stickers-story" name="story_stickers" value="">
                <input type="file" id="input-novo-story" name="story_arquivo" accept="image/*,video/mp4,video/webm" onchange="selecionouArquivoStory(this)">
                <input type="file" id="input-musica-story" name="story_musica" form="form-novo-story" accept="audio/mpeg,audio/mp3,audio/ogg,audio/wav,audio/x-m4a,audio/mp4" style="display:none;" onchange="mudouMusicaStory()">
            </form>

            <div class="criar-post">
                <form method="POST" enctype="multipart/form-data">
                    <textarea name="conteudo" placeholder="Fazer um post..."></textarea>
                    <input type="file" name="imagem" accept="image/*">
                    <button class="acao" type="submit">Publicar</button>
                </form>
            </div>

            <?php foreach ($posts as $post): ?>
                <div class="post">
                    <div class="post-cabecalho">
                        <a class="avatar-link" href="perfil-usuario.php?id=<?= (int) $post["usuario_id"] ?>">
                            <?php if (!empty($post["foto_perfil"])): ?>
                                <img class="avatar-mini" src="avatar.php?id=<?= (int) $post["usuario_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($post["foto_perfil_pos"] ?? "50% 50%") ?>;">
                            <?php else: ?>
                                <span class="avatar-mini">👤</span>
                            <?php endif; ?>
                            <strong><?= htmlspecialchars($post["nome_usuario"]) ?></strong>
                            <?php if ((int) $post["autor_seguidores"] >= 1000): ?><span class="selo-verificado" title="Verificado - 1000+ seguidores">✔</span><?php endif; ?>
                        </a>
                        <span style="color:#555;font-size:12px;"><?= date("d/m/Y H:i", strtotime($post["criado_em"])) ?></span>
                    </div>

                    <?php if ($post["imagem"]): ?>
                        <?php $post_img_src = "midia.php?pasta=posts&arquivo=" . urlencode($post["imagem"]); ?>
                        <div style="position:relative;">
                            <img class="post-imagem" src="<?= htmlspecialchars($post_img_src) ?>" alt="post" onclick="abrirLightbox(this.src)">
                            <a href="<?= htmlspecialchars($post_img_src) ?>" download class="baixar-midia" title="Baixar">⬇</a>
                        </div>
                    <?php endif; ?>

                    <?php if ($post["conteudo"]): ?>
                        <div class="post-texto"><?= nl2br(htmlspecialchars($post["conteudo"])) ?></div>
                    <?php endif; ?>

                    <div style="display:flex; gap:10px; padding: 0 15px;">
                        <form method="POST">
                            <input type="hidden" name="curtir_post_id" value="<?= $post["id"] ?>">
                            <button class="acao" type="submit" style="background-color:<?= $post["curti"] ? "#ff3b6b" : "#888" ?>;">
                                <?= $post["curti"] ? "❤️" : "🤍" ?> <?= (int) $post["total_curtidas"] ?>
                            </button>
                        </form>
                        <form method="POST">
                            <input type="hidden" name="salvar_post_id" value="<?= $post["id"] ?>">
                            <button class="acao" type="submit" style="background-color:#2844e2;">🔖 Salvar</button>
                        </form>
                    </div>

                    <?php if (!empty($comentarios_por_post[$post["id"]])): ?>
                        <div class="post-comentarios">
                            <?php foreach ($comentarios_por_post[$post["id"]] as $com): ?>
                                <div class="post-comentario" id="comentario-<?= (int) $com["id"] ?>">
                                    <a href="perfil-usuario.php?id=<?= (int) $com["autor_id"] ?>">
                                        <?php if (!empty($com["foto_perfil"])): ?>
                                            <img class="avatar-mini-pequeno" src="avatar.php?id=<?= (int) $com["autor_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($com["foto_perfil_pos"] ?? "50% 50%") ?>;">
                                        <?php else: ?>
                                            <span class="avatar-mini-pequeno">👤</span>
                                        <?php endif; ?>
                                    </a>
                                    <div class="post-comentario-texto">
                                        <a href="perfil-usuario.php?id=<?= (int) $com["autor_id"] ?>" style="color:inherit;">
                                            <strong><?= htmlspecialchars($com["nome_usuario"]) ?>:</strong>
                                        </a>
                                        <?= htmlspecialchars($com["conteudo"]) ?>
                                    </div>
                                    <?php if ((int) $com["autor_id"] === (int) $usuario_logado["id"]): ?>
                                        <form class="post-comentario-editar" id="editar-form-<?= (int) $com["id"] ?>" method="POST">
                                            <input type="hidden" name="editar_comentario_id" value="<?= (int) $com["id"] ?>">
                                            <input type="text" name="novo_comentario_texto" value="<?= htmlspecialchars($com["conteudo"]) ?>" required maxlength="500">
                                            <button class="acao" type="submit" style="padding:6px 12px;">Salvar</button>
                                            <button type="button" class="acao" style="padding:6px 12px;background:#888;" onclick="cancelarEdicaoComentario(<?= (int) $com["id"] ?>)">Cancelar</button>
                                        </form>
                                        <div class="post-comentario-acoes">
                                            <button type="button" title="Editar" onclick="editarComentario(<?= (int) $com["id"] ?>)">✏️</button>
                                            <form method="POST" onsubmit="return confirm('Apagar esse comentário?');" style="display:inline;">
                                                <input type="hidden" name="excluir_comentario_id" value="<?= (int) $com["id"] ?>">
                                                <button type="submit" title="Apagar">🗑️</button>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <form class="post-comentario-form" method="POST">
                        <input type="hidden" name="comentario_post_id" value="<?= $post["id"] ?>">
                        <input type="text" name="comentario_texto" placeholder="Comentário" required>
                        <button class="acao" type="submit">➤</button>
                    </form>
                </div>
            <?php endforeach; ?>

            <?php if (empty($posts)): ?>
                <p>Ainda não há posts. Seja o primeiro a publicar!</p>
            <?php endif; ?>
        </div>

        <div class="coluna-lateral">
            <div class="card-escuro">
                <h2>Comunidades em alta</h2>
                <?php foreach ($comunidades_alta as $c): ?>
                    <div class="comunidade-linha"><?= htmlspecialchars($c["nome"]) ?></div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<div class="lightbox-overlay" id="lightbox-overlay" onclick="fecharLightbox()">
    <button class="lightbox-fechar" type="button" onclick="fecharLightbox()">&times;</button>
    <img id="lightbox-img" src="" alt="Imagem ampliada" onclick="event.stopPropagation()">
</div>

<div class="story-visor-overlay" id="story-visor-overlay">
    <div class="story-visor-barra" id="story-visor-barra"></div>
    <div class="story-visor-topo">
        <strong id="story-visor-nome"></strong>
    </div>
    <button class="story-visor-excluir" type="button" id="story-visor-excluir" onclick="excluirStoryAtual()" title="Excluir story" style="display:none;">🗑</button>
    <button class="story-visor-fechar" type="button" onclick="fecharStory()">&times;</button>
    <button class="story-visor-nav anterior" type="button" onclick="storyAnterior()" aria-label="Story anterior"></button>
    <button class="story-visor-nav proximo" type="button" onclick="storyProximo()" aria-label="Próximo story"></button>
    <div class="story-visor-midia-wrap" id="story-visor-midia-wrap">
        <img class="story-visor-midia" id="story-visor-img" alt="Story" style="display:none;">
        <video class="story-visor-midia" id="story-visor-video" playsinline style="display:none;"></video>
        <div id="story-visor-stickers"></div>
    </div>
    <audio id="story-visor-audio" style="display:none;"></audio>

    <div class="story-visor-comentarios" id="story-visor-comentarios"></div>

    <div class="story-visor-rodape" id="story-visor-rodape">
        <input type="text" id="story-visor-input-comentario" placeholder="Enviar mensagem..." maxlength="500"
            onfocus="pausarStory()" onblur="retomarStory()"
            onkeydown="if(event.key==='Enter'){event.preventDefault();enviarComentarioStory();}">
        <button type="button" onclick="enviarComentarioStory()" title="Enviar">➤</button>
        <button type="button" id="story-visor-curtir" onclick="curtirStoryAtual()" title="Curtir">
            <span id="story-visor-curtir-emoji">🤍</span> <span id="story-visor-total-curtidas">0</span>
        </button>
        <button type="button" onclick="alternarComentariosStory()" title="Comentários">
            💬 <span id="story-visor-total-comentarios">0</span>
        </button>
    </div>

    <!-- V30: só o dono do story vê isto -->
    <button type="button" class="story-visor-views" id="story-visor-views" onclick="abrirVisualizacoesStory()" style="display:none;">
        👁 <span id="story-visor-total-views">0</span> visualizações
    </button>
    <div class="story-views-painel" id="story-views-painel">
        <div class="story-views-topo">
            <strong>Visualizações (<span id="story-views-total">0</span>)</strong>
            <button type="button" onclick="fecharVisualizacoesStory(true)" aria-label="Fechar">&times;</button>
        </div>
        <div id="story-views-lista"></div>
    </div>
</div>

<div class="story-editor-overlay" id="story-editor-overlay">
    <div class="story-editor-caixa">
        <button type="button" class="story-editor-fechar" onclick="fecharEditorStory()" title="Cancelar">&times;</button>
        <div class="story-editor-preview" id="story-editor-preview">
            <img id="story-editor-img" style="display:none;" alt="Pré-visualização do story">
            <video id="story-editor-video" muted playsinline style="display:none;"></video>
        </div>
        <div class="story-editor-campo">
            <label>Sticker</label>
            <div class="story-editor-emojis">
                <button type="button" onclick="adicionarStickerStory('😂')">😂</button>
                <button type="button" onclick="adicionarStickerStory('❤️')">❤️</button>
                <button type="button" onclick="adicionarStickerStory('🔥')">🔥</button>
                <button type="button" onclick="adicionarStickerStory('🎉')">🎉</button>
                <button type="button" onclick="adicionarStickerStory('😍')">😍</button>
                <button type="button" onclick="adicionarStickerStory('👍')">👍</button>
                <button type="button" onclick="adicionarStickerStory('😢')">😢</button>
                <button type="button" onclick="adicionarStickerStory('💯')">💯</button>
            </div>
            <span class="story-editor-dica">Toque num emoji pra colar no story, arraste pra posicionar e toque nele de novo pra remover.</span>
        </div>
        <div class="story-editor-campo">
            <label for="input-editor-duracao">Duração</label>
            <select id="input-editor-duracao">
                <option value="6">6 horas</option>
                <option value="24" selected>24 horas</option>
                <option value="72">3 dias</option>
                <option value="168">7 dias</option>
            </select>
        </div>
        <div class="story-editor-campo">
            <label>Música de fundo (opcional)</label>
            <button type="button" class="story-editor-botao-musica" id="story-editor-botao-musica" onclick="document.getElementById('input-musica-story').click()">🎵 Escolher música</button>
            <span class="story-editor-musica-nome" id="story-editor-musica-nome"></span>
            <button type="button" class="story-editor-remover-musica" id="story-editor-remover-musica" onclick="removerMusicaStory()" style="display:none;">Remover</button>
        </div>
        <button type="button" class="story-editor-publicar" onclick="publicarStoryEditor()">Publicar story</button>
    </div>
</div>

<script src="midia.js"></script>
<script>
    function editarComentario(id) {
        document.getElementById("comentario-" + id).classList.add("editando");
        document.getElementById("editar-form-" + id).classList.add("ativo");
    }
    function cancelarEdicaoComentario(id) {
        document.getElementById("comentario-" + id).classList.remove("editando");
        document.getElementById("editar-form-" + id).classList.remove("ativo");
    }

    // Dados de todos os grupos de stories (por autor), gerados pelo PHP.
    const usuarioLogadoId = <?= (int) $usuario_logado["id"] ?>;
    const gruposStories = <?= json_encode(array_values(array_map(function ($g) {
        return [
            "usuario_id" => (int) $g["usuario_id"],
            "nome_usuario" => $g["nome_usuario"],
            "itens" => array_map(function ($item) {
                $stickers_item = [];
                if (!empty($item["stickers"])) {
                    $decodificado = json_decode($item["stickers"], true);
                    if (is_array($decodificado)) $stickers_item = $decodificado;
                }
                return [
                    "id" => (int) $item["id"],
                    "src" => "midia.php?pasta=stories&arquivo=" . urlencode($item["arquivo"]),
                    "tipo" => $item["tipo"],
                    "musica" => !empty($item["musica"]) ? "midia.php?pasta=stories&arquivo=" . urlencode($item["musica"]) : null,
                    "stickers" => $stickers_item,
                    "total_curtidas" => (int) $item["total_curtidas"],
                    "curti" => (bool) $item["curti"],
                    "total_comentarios" => (int) $item["total_comentarios"],
                    "visto" => (bool) $item["visto"],
                    "total_visualizacoes" => (int) ($item["total_visualizacoes"] ?? 0),
                ];
            }, $g["itens"]),
        ];
    }, $stories_por_usuario)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;

    let indiceGrupoAtual = 0;
    let indiceItemAtual = 0;
    let timerStory = null;

    function abrirStory(usuarioId) {
        const idx = gruposStories.findIndex(g => g.usuario_id === usuarioId);
        if (idx === -1) return;
        indiceGrupoAtual = idx;
        indiceItemAtual = 0;
        document.getElementById("story-visor-overlay").classList.add("aberto");
        mostrarStoryAtual();
    }

    function fecharStory() {
        document.getElementById("story-views-painel").classList.remove("aberto");
        document.getElementById("story-visor-overlay").classList.remove("aberto");
        pararMidiaStory();
        clearTimeout(timerStory);
        document.getElementById("story-visor-audio").pause();
    }

    function pararMidiaStory() {
        const video = document.getElementById("story-visor-video");
        video.onended = null;
        video.onerror = null;
        video.pause();
        video.src = "";
    }

    function animarBarraStory(duracaoMs) {
        const barras = document.querySelectorAll("#story-visor-barra span i");
        barras.forEach((b, i) => { b.style.transition = "none"; b.style.width = i < indiceItemAtual ? "100%" : "0%"; });
        void document.getElementById("story-visor-barra").offsetWidth; // força reflow
        if (barras[indiceItemAtual]) {
            barras[indiceItemAtual].style.transition = "width " + duracaoMs + "ms linear";
            requestAnimationFrame(() => { barras[indiceItemAtual].style.width = "100%"; });
        }
    }

    function montarBarras(total) {
        const barra = document.getElementById("story-visor-barra");
        barra.innerHTML = "";
        for (let i = 0; i < total; i++) {
            const span = document.createElement("span");
            span.innerHTML = "<i></i>";
            barra.appendChild(span);
        }
    }

    function mostrarStoryAtual() {
        const grupo = gruposStories[indiceGrupoAtual];
        if (!grupo) { fecharStory(); return; }
        const item = grupo.itens[indiceItemAtual];
        if (!item) { fecharStory(); return; }

        document.getElementById("story-visor-nome").textContent = grupo.nome_usuario;
        const ehMeuStory = grupo.usuario_id === usuarioLogadoId;
        document.getElementById("story-visor-excluir").style.display = ehMeuStory ? "block" : "none";
        // dono do story não pode curtir nem comentar no próprio story
        document.getElementById("story-visor-rodape").classList.toggle("escondido", ehMeuStory);
        // V30: dono vê quantas visualizações teve (e toca pra ver quem viu)
        document.getElementById("story-visor-views").style.display = ehMeuStory ? "block" : "none";
        document.getElementById("story-views-painel").classList.remove("aberto");
        document.getElementById("story-visor-total-views").textContent = item.total_visualizacoes || 0;
        if (ehMeuStory) carregarVisualizacoesStory(item);
        montarBarras(grupo.itens.length);
        atualizarBotaoCurtir(item);
        document.getElementById("story-visor-total-comentarios").textContent = item.total_comentarios;
        document.getElementById("story-visor-comentarios").classList.remove("aberto");
        document.getElementById("story-visor-input-comentario").value = "";
        montarStickersVisor(item.stickers);

        const imgEl = document.getElementById("story-visor-img");
        const videoEl = document.getElementById("story-visor-video");
        pararMidiaStory();
        clearTimeout(timerStory);
        tocarMusicaStory(item.musica);

        if (item.tipo === "video") {
            imgEl.style.display = "none";
            videoEl.style.display = "block";
            videoEl.src = item.src;
            videoEl.play().catch(() => {});

            // Vídeo de qualquer duração: a barra acompanha o tamanho real do
            // arquivo e o avanço pro próximo story só acontece quando o vídeo
            // termina de verdade (antes era sempre cortado em 15s).
            const iniciarBarraComDuracaoReal = () => {
                const duracaoReal = isFinite(videoEl.duration) && videoEl.duration > 0 ? videoEl.duration * 1000 : 15000;
                animarBarraStory(duracaoReal);
            };
            if (videoEl.readyState >= 1) {
                iniciarBarraComDuracaoReal();
            } else {
                videoEl.addEventListener("loadedmetadata", iniciarBarraComDuracaoReal, { once: true });
            }
            videoEl.onended = storyProximo;
            // se o vídeo não conseguir carregar/tocar, não trava o visor
            videoEl.onerror = () => { timerStory = setTimeout(storyProximo, 4000); };
        } else {
            videoEl.style.display = "none";
            imgEl.style.display = "block";
            imgEl.src = item.src;
            animarBarraStory(6000);
            timerStory = setTimeout(storyProximo, 6000);
        }

        // marca como visto no servidor (não trava a navegação se falhar) e deixa
        // o anel do autor cinza assim que todos os stories dele já tiverem sido vistos
        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "marcar_story_visto=" + item.id
        }).then(() => {
            item.visto = true;
            if (!ehMeuStory && grupo.itens.every(i => i.visto)) {
                const anel = document.getElementById("story-anel-" + grupo.usuario_id);
                if (anel) anel.classList.add("visto");
            }
        }).catch(() => {});
    }

    // V30: visualizações do story (só o dono)
    function tempoAtrasStory(seg) {
        if (seg < 60) return "agora";
        if (seg < 3600) return "há " + Math.floor(seg / 60) + " min";
        if (seg < 86400) return "há " + Math.floor(seg / 3600) + " h";
        return "há " + Math.floor(seg / 86400) + " d";
    }

    function carregarVisualizacoesStory(item) {
        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "listar_visualizacoes_story_id=" + item.id
        }).then(r => r.json()).then(resp => {
            if (!resp.ok) return;
            item.total_visualizacoes = resp.total;
            const atual = gruposStories[indiceGrupoAtual].itens[indiceItemAtual];
            if (!atual || atual.id !== item.id) return; // já mudou de story
            document.getElementById("story-visor-total-views").textContent = resp.total;
            document.getElementById("story-views-total").textContent = resp.total;
            const lista = document.getElementById("story-views-lista");
            lista.innerHTML = "";
            if (!resp.visualizacoes.length) {
                lista.innerHTML = '<p style="color:#aaa;">Ninguém viu ainda.</p>';
                return;
            }
            resp.visualizacoes.forEach(v => {
                const linha = document.createElement("div");
                linha.className = "story-views-item";
                const foto = v.tem_foto
                    ? '<img src="avatar.php?id=' + v.id + '" alt="">'
                    : '<span class="sem-foto">👤</span>';
                linha.innerHTML = foto + "<span>" + escaparHtml(v.nome_usuario) + "</span><small>" + tempoAtrasStory(v.segundos) + "</small>";
                lista.appendChild(linha);
            });
        }).catch(() => {});
    }

    function abrirVisualizacoesStory() {
        pausarStory();
        const item = gruposStories[indiceGrupoAtual].itens[indiceItemAtual];
        if (item) carregarVisualizacoesStory(item);
        document.getElementById("story-views-painel").classList.add("aberto");
    }

    function fecharVisualizacoesStory(retomar) {
        document.getElementById("story-views-painel").classList.remove("aberto");
        if (retomar) retomarStory();
    }

    function montarStickersVisor(stickers) {
        const caixa = document.getElementById("story-visor-stickers");
        caixa.innerHTML = "";
        (stickers || []).forEach(st => {
            const span = document.createElement("span");
            span.className = "story-visor-sticker";
            span.textContent = st.emoji;
            span.style.left = st.x + "%";
            span.style.top = st.y + "%";
            caixa.appendChild(span);
        });
    }

    function tocarMusicaStory(musicaSrc) {
        const audio = document.getElementById("story-visor-audio");
        audio.pause();
        if (musicaSrc) {
            audio.src = musicaSrc;
            audio.currentTime = 0;
            audio.play().catch(() => {});
        } else {
            audio.removeAttribute("src");
        }
    }

    function storyProximo() {
        const grupo = gruposStories[indiceGrupoAtual];
        if (indiceItemAtual < grupo.itens.length - 1) {
            indiceItemAtual++;
            mostrarStoryAtual();
        } else if (indiceGrupoAtual < gruposStories.length - 1) {
            indiceGrupoAtual++;
            indiceItemAtual = 0;
            mostrarStoryAtual();
        } else {
            fecharStory();
        }
    }

    function excluirStoryAtual() {
        const grupo = gruposStories[indiceGrupoAtual];
        if (!grupo) return;
        const item = grupo.itens[indiceItemAtual];
        if (!item) return;
        if (!confirm("Excluir este story?")) return;

        clearTimeout(timerStory);

        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "excluir_story_id=" + item.id
        })
            .then(r => r.text())
            .then(resp => {
                if (resp.trim() !== "ok") { window.location.reload(); return; }
                grupo.itens.splice(indiceItemAtual, 1);
                if (grupo.itens.length === 0) {
                    // sem mais stories deste autor: recarrega pra atualizar a faixa de stories
                    window.location.reload();
                    return;
                }
                if (indiceItemAtual >= grupo.itens.length) {
                    indiceItemAtual = grupo.itens.length - 1;
                }
                mostrarStoryAtual();
            })
            .catch(() => window.location.reload());
    }

    function atualizarBotaoCurtir(item) {
        document.getElementById("story-visor-total-curtidas").textContent = item.total_curtidas;
        document.getElementById("story-visor-curtir-emoji").textContent = item.curti ? "❤️" : "🤍";
    }

    function curtirStoryAtual() {
        const grupo = gruposStories[indiceGrupoAtual];
        const item = grupo.itens[indiceItemAtual];
        if (!item) return;
        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "curtir_story_id=" + item.id
        })
            .then(r => r.json())
            .then(dados => {
                item.curti = dados.curti;
                item.total_curtidas = dados.total;
                atualizarBotaoCurtir(item);
            })
            .catch(() => {});
    }

    function pausarStory() {
        clearTimeout(timerStory);
        const video = document.getElementById("story-visor-video");
        if (video.style.display !== "none") video.pause();
        document.getElementById("story-visor-audio").pause();
        const barraAtual = document.querySelectorAll("#story-visor-barra span i")[indiceItemAtual];
        if (barraAtual) {
            const largura = getComputedStyle(barraAtual).width;
            barraAtual.style.transition = "none";
            barraAtual.style.width = largura;
        }
    }

    function retomarStory() {
        const grupo = gruposStories[indiceGrupoAtual];
        const item = grupo.itens[indiceItemAtual];
        if (!item) return;
        const video = document.getElementById("story-visor-video");
        const audio = document.getElementById("story-visor-audio");
        if (audio.src) audio.play().catch(() => {});
        if (item.tipo === "video") {
            video.play().catch(() => {});
            const restante = isFinite(video.duration) && video.duration > 0
                ? Math.max((video.duration - video.currentTime) * 1000, 300)
                : 15000;
            animarBarraStory(restante);
        } else {
            animarBarraStory(6000);
            timerStory = setTimeout(storyProximo, 6000);
        }
    }

    function alternarComentariosStory() {
        const painel = document.getElementById("story-visor-comentarios");
        if (painel.classList.contains("aberto")) {
            painel.classList.remove("aberto");
            retomarStory();
            return;
        }
        pausarStory();
        const grupo = gruposStories[indiceGrupoAtual];
        const item = grupo.itens[indiceItemAtual];
        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "listar_comentarios_story_id=" + item.id
        })
            .then(r => r.json())
            .then(lista => {
                painel.innerHTML = lista.length
                    ? lista.map(c => "<div class=\"story-visor-comentario\"><strong>" + escaparHtml(c.nome_usuario) + ":</strong>" + escaparHtml(c.conteudo) + "</div>").join("")
                    : "<div class=\"story-visor-comentario\">Nenhum comentário ainda.</div>";
                painel.classList.add("aberto");
            })
            .catch(() => {});
    }

    function escaparHtml(texto) {
        const div = document.createElement("div");
        div.textContent = texto;
        return div.innerHTML;
    }

    function enviarComentarioStory() {
        const grupo = gruposStories[indiceGrupoAtual];
        const item = grupo.itens[indiceItemAtual];
        if (!item) return;
        const input = document.getElementById("story-visor-input-comentario");
        const texto = input.value.trim();
        if (texto === "") return;
        fetch("inicio.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "comentario_story_id=" + item.id + "&comentario_texto=" + encodeURIComponent(texto)
        })
            .then(r => r.json())
            .then(dados => {
                if (!dados.ok) { alert(dados.erro || "Não foi possível enviar."); return; }
                input.value = "";
                item.total_comentarios = dados.total;
                document.getElementById("story-visor-total-comentarios").textContent = dados.total;
                const painel = document.getElementById("story-visor-comentarios");
                if (painel.classList.contains("aberto")) {
                    const vazio = painel.querySelector(".story-visor-comentario");
                    if (vazio && vazio.textContent === "Nenhum comentário ainda.") painel.innerHTML = "";
                    painel.insertAdjacentHTML("beforeend", "<div class=\"story-visor-comentario\"><strong>" + escaparHtml(dados.nome_usuario) + ":</strong>" + escaparHtml(dados.conteudo) + "</div>");
                    painel.scrollTop = painel.scrollHeight;
                } else {
                    input.blur();
                }
            })
            .catch(() => {});
    }

    function storyAnterior() {
        if (indiceItemAtual > 0) {
            indiceItemAtual--;
            mostrarStoryAtual();
        } else if (indiceGrupoAtual > 0) {
            indiceGrupoAtual--;
            indiceItemAtual = gruposStories[indiceGrupoAtual].itens.length - 1;
            mostrarStoryAtual();
        }
    }

    document.addEventListener("keydown", function (e) {
        const overlay = document.getElementById("story-visor-overlay");
        if (!overlay.classList.contains("aberto")) return;
        if (e.key === "Escape") fecharStory();
        if (e.key === "ArrowRight") storyProximo();
        if (e.key === "ArrowLeft") storyAnterior();
    });

    // --- Editor de novo story (sticker + música + duração) ---
    let stickersEditor = [];
    let urlPreviaEditor = null;

    function selecionouArquivoStory(inputEl) {
        if (!inputEl.files || !inputEl.files[0]) return;
        const arquivo = inputEl.files[0];
        stickersEditor = [];
        document.getElementById("story-editor-preview").querySelectorAll(".story-editor-sticker").forEach(el => el.remove());
        document.getElementById("input-musica-story").value = "";
        document.getElementById("story-editor-musica-nome").textContent = "";
        document.getElementById("story-editor-remover-musica").style.display = "none";
        document.getElementById("input-editor-duracao").value = "24";

        if (urlPreviaEditor) URL.revokeObjectURL(urlPreviaEditor);
        urlPreviaEditor = URL.createObjectURL(arquivo);

        const imgEl = document.getElementById("story-editor-img");
        const videoEl = document.getElementById("story-editor-video");
        if (arquivo.type.startsWith("video/")) {
            imgEl.style.display = "none";
            videoEl.style.display = "block";
            videoEl.src = urlPreviaEditor;
            videoEl.play().catch(() => {});
        } else {
            videoEl.style.display = "none";
            videoEl.pause();
            imgEl.style.display = "block";
            imgEl.src = urlPreviaEditor;
        }
        document.getElementById("story-editor-overlay").classList.add("aberto");
    }

    function fecharEditorStory() {
        document.getElementById("story-editor-overlay").classList.remove("aberto");
        document.getElementById("story-editor-video").pause();
        document.getElementById("input-novo-story").value = "";
        if (urlPreviaEditor) { URL.revokeObjectURL(urlPreviaEditor); urlPreviaEditor = null; }
    }

    function adicionarStickerStory(emoji) {
        const preview = document.getElementById("story-editor-preview");
        const span = document.createElement("span");
        span.className = "story-editor-sticker";
        span.textContent = emoji;
        span.style.left = "50%";
        span.style.top = "50%";
        tornarStickerArrastavel(span);
        preview.appendChild(span);
        stickersEditor.push({ emoji: emoji, x: 50, y: 50, el: span });
    }

    function tornarStickerArrastavel(span) {
        let arrastando = false;
        let moveu = false;
        span.addEventListener("pointerdown", e => {
            arrastando = true;
            moveu = false;
            span.setPointerCapture(e.pointerId);
        });
        span.addEventListener("pointermove", e => {
            if (!arrastando) return;
            moveu = true;
            const caixa = document.getElementById("story-editor-preview").getBoundingClientRect();
            let x = ((e.clientX - caixa.left) / caixa.width) * 100;
            let y = ((e.clientY - caixa.top) / caixa.height) * 100;
            x = Math.max(0, Math.min(100, x));
            y = Math.max(0, Math.min(100, y));
            span.style.left = x + "%";
            span.style.top = y + "%";
            const dados = stickersEditor.find(s => s.el === span);
            if (dados) { dados.x = x; dados.y = y; }
        });
        span.addEventListener("pointerup", e => {
            arrastando = false;
            if (!moveu) {
                // toque rápido sem arrastar = remover o sticker
                stickersEditor = stickersEditor.filter(s => s.el !== span);
                span.remove();
            }
        });
    }

    function mudouMusicaStory() {
        const input = document.getElementById("input-musica-story");
        if (input.files && input.files[0]) {
            document.getElementById("story-editor-musica-nome").textContent = input.files[0].name;
            document.getElementById("story-editor-remover-musica").style.display = "inline";
        }
    }

    function removerMusicaStory() {
        document.getElementById("input-musica-story").value = "";
        document.getElementById("story-editor-musica-nome").textContent = "";
        document.getElementById("story-editor-remover-musica").style.display = "none";
    }

    function publicarStoryEditor() {
        document.getElementById("input-duracao-story").value = document.getElementById("input-editor-duracao").value;
        document.getElementById("input-stickers-story").value = JSON.stringify(
            stickersEditor.map(s => ({ emoji: s.emoji, x: Math.round(s.x), y: Math.round(s.y) }))
        );
        document.getElementById("form-novo-story").submit();
    }
</script>

</body>
</html>
