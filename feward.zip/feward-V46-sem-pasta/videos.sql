-- Feward V16 - vídeos
-- Execute depois de digitando.sql.
-- usuario_id é UNSIGNED para ficar compatível com contas.id.

CREATE TABLE IF NOT EXISTS videos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    tipo ENUM('curto','longo') NOT NULL,
    arquivo VARCHAR(255) NULL,
    link_externo VARCHAR(500) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
