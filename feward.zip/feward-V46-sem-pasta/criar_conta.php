<?php
require_once "conexao.php";
session_start();

if (isset($_SESSION["usuario_id"])) {
    header("Location: inicio.php");
    exit;
}

$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";
    $repetir_senha = $_POST["repetir_senha"] ?? "";
    $usuario = trim($_POST["usuario"] ?? "");
    $nome = trim($_POST["nome"] ?? "");

    if ($nome === "" || $email === "" || $usuario === "" || $senha === "" || $repetir_senha === "") {
        $erro = "Preencha todos os campos.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = "Digite um email válido.";
    } elseif (strlen($senha) < 2) {
        $erro = "A senha deve ter pelo menos 2 caracteres.";
    } elseif ($senha !== $repetir_senha) {
        $erro = "As senhas não coincidem.";
    } else {
        try {
            // A tabela contas usa nome_usuario, email e senha_hash.
            // O campo 'nome' não existe no schema atual, então não é enviado no INSERT.
            $verificar = $pdo->prepare(
                "SELECT id FROM contas WHERE email = ? OR nome_usuario = ? LIMIT 1"
            );
            $verificar->execute([$email, $usuario]);

            if ($verificar->fetch()) {
                $erro = "Email ou nome de usuário já cadastrado.";
            } else {
                $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

                $stmt = $pdo->prepare(
                    "INSERT INTO contas (nome_usuario, email, senha_hash) VALUES (?, ?, ?)"
                );
                $stmt->execute([$usuario, $email, $senha_hash]);

                header("Location: login.php?cadastro=sucesso");
                exit;
            }
        } catch (PDOException $e) {
            $erro = "Não foi possível criar a conta. Confira se a tabela contas está configurada corretamente.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Crie sua conta no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Criar Conta - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            padding: 25px 16px;
            font-family: Arial, Helvetica, sans-serif;
            background:
                linear-gradient(rgba(5, 8, 35, 0.35), rgba(5, 8, 35, 0.55)),
                url("img/fundo.jpeg") center center / cover no-repeat fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .form-container {
            width: 350px;
            max-width: 100%;
        }

        .logo { text-align: center; margin-bottom: 25px; }
        .logo img { width: min(200px, 65vw); height: auto; }

        .campo { margin-bottom: 18px; }

        .campo label {
            display: block;
            text-align: center;
            font-size: 14px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .campo input {
            width: 100%;
            height: 46px;
            border: none;
            border-radius: 25px;
            padding: 0 20px;
            background: linear-gradient(to right, #0d0d0d, #2a2a2a);
            color: white;
            font-size: 15px;
            outline: none;
        }

        .campo input::placeholder { color: #888; }

        .erro {
            text-align: center;
            color: #ff6b6b;
            font-size: 14px;
            margin: 0 0 15px;
        }

        .criar-btn, .voltar-btn {
            display: block;
            width: 100%;
            padding: 12px 0;
            border-radius: 25px;
            font-size: 15px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            text-align: center;
            cursor: pointer;
        }

        .criar-btn {
            margin-top: 8px;
            border: none;
            background-color: #4bbae6;
            color: white;
        }

        .voltar-btn {
            margin-top: 15px;
            border: 2px solid #2844e2;
            background: transparent;
            color: white;
            text-decoration: none;
        }

        .versao {
            text-align: center;
            font-size: 13px;
            font-weight: normal;
            margin: 18px 0 0;
        }

        @media (max-width: 600px) {
            body { align-items: flex-start; padding-top: 20px; }
            .form-container { width: min(350px, 100%); }
            .logo { margin-bottom: 20px; }
            .campo { margin-bottom: 14px; }
            .campo input { height: 48px; font-size: 16px; }
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="logo">
            <img src="img/logo.png" alt="Logo Feward">
        </div>

        <?php if ($erro): ?>
            <p class="erro" role="alert"><?= htmlspecialchars($erro, ENT_QUOTES, "UTF-8") ?></p>
        <?php endif; ?>

        <form method="POST" action="criar_conta.php" autocomplete="on">
            <div class="campo">
                <label for="nome">Seu Nome</label>
                <input type="text" id="nome" name="nome" placeholder="Digite seu nome" value="<?= htmlspecialchars($_POST["nome"] ?? "", ENT_QUOTES, "UTF-8") ?>" required>
            </div>

            <div class="campo">
                <label for="email">Digite Email</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($_POST["email"] ?? "", ENT_QUOTES, "UTF-8") ?>" required>
            </div>

            <div class="campo">
                <label for="senha">Digite Senha</label>
                <input type="password" id="senha" name="senha" required>
            </div>

            <div class="campo">
                <label for="repetir_senha">Repita a Senha</label>
                <input type="password" id="repetir_senha" name="repetir_senha" required>
            </div>

            <div class="campo">
                <label for="usuario">Nome de Usuario</label>
                <input type="text" id="usuario" name="usuario" value="<?= htmlspecialchars($_POST["usuario"] ?? "", ENT_QUOTES, "UTF-8") ?>" required>
            </div>

            <button class="criar-btn" type="submit">Criar Conta</button>
        </form>

        <a class="voltar-btn" href="login.php">Voltar</a>
        <h1 class="versao">Versão 1.0</h1>
    </div>
</body>
</html>
