-- Feward V18 - instalador completo do banco
-- Não apaga contas existentes.

ALTER TABLE contas ADD COLUMN IF NOT EXISTS bio TEXT NULL;
ALTER TABLE contas ADD COLUMN IF NOT EXISTS foto_perfil VARCHAR(255) NULL;
ALTER TABLE contas ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE contas ADD COLUMN IF NOT EXISTS foto_perfil_pos VARCHAR(20) NOT NULL DEFAULT '50% 50%';

CREATE TABLE IF NOT EXISTS comunidades (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 nome VARCHAR(100) NOT NULL,
 imagem VARCHAR(255) NULL,
 PRIMARY KEY (id), UNIQUE KEY uq_comunidades_nome (nome)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS posts (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 conteudo TEXT NULL,
 imagem VARCHAR(255) NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_posts_usuario_data (usuario_id, criado_em),
 FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comentarios (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 post_id INT UNSIGNED NOT NULL,
 usuario_id INT UNSIGNED NOT NULL,
 conteudo TEXT NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_comentarios_post_data (post_id, criado_em),
 FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comunidade_membros (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 comunidade_id INT UNSIGNED NOT NULL,
 usuario_id INT UNSIGNED NOT NULL,
 PRIMARY KEY (id), UNIQUE KEY unico_membro (comunidade_id, usuario_id),
 FOREIGN KEY (comunidade_id) REFERENCES comunidades(id) ON DELETE CASCADE,
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS salvos (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 post_id INT UNSIGNED NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), UNIQUE KEY unico_salvo (usuario_id, post_id),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE,
 FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS amizades (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 amigo_id INT UNSIGNED NOT NULL,
 status ENUM('pendente','aceito') NOT NULL DEFAULT 'pendente',
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), UNIQUE KEY unica_amizade (usuario_id, amigo_id),
 KEY idx_amizades_amigo_status (amigo_id, status),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE,
 FOREIGN KEY (amigo_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagens (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 remetente_id INT UNSIGNED NOT NULL,
 destinatario_id INT UNSIGNED NOT NULL,
 conteudo TEXT NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 lida BOOLEAN NOT NULL DEFAULT FALSE,
 PRIMARY KEY (id), KEY idx_mensagens_conversa (remetente_id, destinatario_id, id),
 KEY idx_mensagens_destinatario_lida (destinatario_id, lida),
 FOREIGN KEY (remetente_id) REFERENCES contas(id) ON DELETE CASCADE,
 FOREIGN KEY (destinatario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS digitando (
 usuario_id INT UNSIGNED NOT NULL,
 destinatario_id INT UNSIGNED NOT NULL,
 atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (usuario_id, destinatario_id),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE,
 FOREIGN KEY (destinatario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS videos (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 titulo VARCHAR(150) NOT NULL,
 tipo ENUM('curto','longo') NOT NULL,
 arquivo VARCHAR(255) NULL,
 link_externo VARCHAR(500) NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_videos_usuario_data (usuario_id, criado_em),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comentarios_video (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 video_id INT UNSIGNED NOT NULL,
 usuario_id INT UNSIGNED NOT NULL,
 conteudo TEXT NOT NULL,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_comentarios_video_data (video_id, criado_em),
 FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE,
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS stories (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 arquivo VARCHAR(255) NOT NULL,
 tipo ENUM('imagem','video') NOT NULL DEFAULT 'imagem',
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_stories_usuario_data (usuario_id, criado_em),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_visualizacoes (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 story_id INT UNSIGNED NOT NULL,
 usuario_id INT UNSIGNED NOT NULL,
 visto_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), UNIQUE KEY unica_visualizacao (story_id, usuario_id),
 FOREIGN KEY (story_id) REFERENCES stories(id) ON DELETE CASCADE,
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notificacoes_seguir (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 amizade_id INT UNSIGNED NOT NULL,
 de_usuario_id INT UNSIGNED NOT NULL,
 para_usuario_id INT UNSIGNED NOT NULL,
 vista TINYINT(1) NOT NULL DEFAULT 0,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id), KEY idx_notif_para_vista (para_usuario_id, vista, criado_em),
 FOREIGN KEY (amizade_id) REFERENCES amizades(id) ON DELETE CASCADE,
 FOREIGN KEY (de_usuario_id) REFERENCES contas(id) ON DELETE CASCADE,
 FOREIGN KEY (para_usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO comunidades (nome) SELECT 'Jogos' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='Jogos');
INSERT INTO comunidades (nome) SELECT 'FanArte' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='FanArte');
INSERT INTO comunidades (nome) SELECT 'Digital Circus' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='Digital Circus');
INSERT INTO comunidades (nome) SELECT 'Animes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='Animes');
INSERT INTO comunidades (nome) SELECT 'Filmes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='Filmes');
INSERT INTO comunidades (nome) SELECT 'Memes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome='Memes');

CREATE TABLE IF NOT EXISTS recuperacao_senha (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT,
 usuario_id INT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL,
 expira_em DATETIME NOT NULL,
 usado TINYINT(1) NOT NULL DEFAULT 0,
 criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (id),
 UNIQUE KEY uq_recuperacao_token (token_hash),
 KEY idx_recuperacao_usuario (usuario_id),
 KEY idx_recuperacao_expira (expira_em),
 FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
