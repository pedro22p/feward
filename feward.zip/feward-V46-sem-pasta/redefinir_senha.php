<?php
require_once "conexao.php";
session_start();

if (isset($_SESSION["usuario_id"])) {
    header("Location: inicio.php");
    exit;
}

$token = trim($_GET["token"] ?? $_POST["token"] ?? "");
$erro = "";
$sucesso = "";
$tokenValido = false;

if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    try {
        $hash = hash("sha256", $token);
        $stmt = $pdo->prepare(
            "SELECT id, usuario_id FROM recuperacao_senha\n             WHERE token_hash = ? AND usado = 0 AND expira_em > NOW()\n             LIMIT 1"
        );
        $stmt->execute([$hash]);
        $recuperacao = $stmt->fetch();
        $tokenValido = (bool)$recuperacao;
    } catch (PDOException $e) {
        $erro = "Não foi possível verificar o link.";
    }
} else {
    $erro = "O link de recuperação é inválido.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $tokenValido) {
    $senha = $_POST["senha"] ?? "";
    $confirmacao = $_POST["confirmacao"] ?? "";

    if (strlen($senha) < 2) {
        $erro = "A senha precisa ter pelo menos 2 caracteres.";
    } elseif ($senha !== $confirmacao) {
        $erro = "As senhas não coincidem.";
    } else {
        try {
            $novoHash = password_hash($senha, PASSWORD_DEFAULT);
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("UPDATE contas SET senha_hash = ? WHERE id = ?");
            $stmt->execute([$novoHash, $recuperacao["usuario_id"]]);

            // Invalida o token imediatamente após o uso.
            $stmt = $pdo->prepare("UPDATE recuperacao_senha SET usado = 1 WHERE id = ?");
            $stmt->execute([$recuperacao["id"]]);

            // Invalida também outros tokens antigos da mesma conta.
            $pdo->prepare("DELETE FROM recuperacao_senha WHERE usuario_id = ? AND id <> ?")
                ->execute([$recuperacao["usuario_id"], $recuperacao["id"]]);

            $pdo->commit();
            $sucesso = "Senha redefinida com sucesso. Agora você já pode entrar com a nova senha.";
            $tokenValido = false;
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $erro = "Não foi possível redefinir a senha. Tente novamente.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0b1050">
    <title>Redefinir senha - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <style>
        *{box-sizing:border-box}html,body{margin:0;min-height:100%;font-family:Arial,Helvetica,sans-serif}
        body{min-height:100vh;background:linear-gradient(rgba(5,8,35,.45),rgba(5,8,35,.65)),url("img/fundo.jpeg") center/cover fixed;color:#fff;display:flex;flex-direction:column;align-items:center;padding:35px 16px}
        .logo img{max-width:180px;max-height:120px;object-fit:contain}.caixa{width:100%;max-width:420px;margin-top:30px;padding:28px 22px;background:rgba(0,0,0,.88);border-radius:18px;box-shadow:0 15px 45px rgba(0,0,0,.4)}
        h1{text-align:center;font-size:27px;margin:0 0 22px}.erro,.sucesso{padding:12px;border-radius:10px;line-height:1.45;margin-bottom:18px}.erro{background:rgba(220,60,60,.16);border:1px solid rgba(255,100,100,.3)}.sucesso{background:rgba(40,180,100,.15);border:1px solid rgba(100,220,150,.35)}
        label{display:block;margin:0 0 7px;color:#ddd;font-size:14px}input{width:100%;min-height:50px;padding:14px 15px;border:1px solid transparent;border-radius:10px;font-size:16px;outline:none;margin-bottom:15px}input:focus{border-color:#2844e2;box-shadow:0 0 0 3px rgba(40,68,226,.2)}button{width:100%;min-height:50px;background:#2844e2;border:0;border-radius:10px;color:#fff;font-size:16px;font-weight:bold;cursor:pointer}.voltar{display:block;text-align:center;margin-top:15px;color:#9cacff;text-decoration:none;font-size:14px}
    </style>
</head>
<body>
    <div class="logo"><img src="img/logo.png" alt="Logo do Feward"></div>
    <main class="caixa">
        <h1>Redefinir senha</h1>
        <?php if ($erro): ?><div class="erro" role="alert"><?= htmlspecialchars($erro, ENT_QUOTES, "UTF-8") ?></div><?php endif; ?>
        <?php if ($sucesso): ?>
            <div class="sucesso" role="status"><?= htmlspecialchars($sucesso, ENT_QUOTES, "UTF-8") ?></div>
            <a class="voltar" href="login.php">Ir para o login</a>
        <?php elseif ($tokenValido): ?>
            <form method="POST" autocomplete="off">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, "UTF-8") ?>">
                <label for="senha">Nova senha</label>
                <input id="senha" type="password" name="senha" minlength="2" autocomplete="new-password" required>
                <label for="confirmacao">Confirmar nova senha</label>
                <input id="confirmacao" type="password" name="confirmacao" minlength="2" autocomplete="new-password" required>
                <button type="submit">Salvar nova senha</button>
            </form>
        <?php else: ?>
            <a class="voltar" href="esqueci_senha.php">Solicitar outro link</a>
        <?php endif; ?>
    </main>
</body>
</html>
