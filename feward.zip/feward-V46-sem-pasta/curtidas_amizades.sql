-- Feward V16 - curtidas e amizades
-- Execute depois de extra_tabelas.sql.

CREATE TABLE IF NOT EXISTS curtidas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    post_id INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id),
    FOREIGN KEY (post_id) REFERENCES posts(id),
    UNIQUE KEY unica_curtida (usuario_id, post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE amizades
    MODIFY status ENUM('pendente','aceito') DEFAULT 'pendente';
