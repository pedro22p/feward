<?php
require_once "auth.php";

$erro = "";
$sucesso = "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nome_usuario"])) {
    $novo_nome = trim($_POST["nome_usuario"]);
    try {
        $stmt = $pdo->prepare("UPDATE contas SET nome_usuario = ? WHERE id = ?");
        $stmt->execute([$novo_nome, $usuario_logado["id"]]);
        $sucesso = "Nome de usuário atualizado.";
        $usuario_logado["nome_usuario"] = $novo_nome;
    } catch (PDOException $e) {
        $erro = ($e->getCode() == 23000) ? "Esse nome de usuário já está em uso." : "Erro ao atualizar.";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["modo_fantasma"])) {
    $pdo->prepare("UPDATE contas SET modo_fantasma = ? WHERE id = ?")->execute([$_POST["modo_fantasma"] === "1" ? 1 : 0, $usuario_logado["id"]]);
    header("Location: configuracao.php");
    exit;
}

$pagina_ativa = "configuracao";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Configurações da sua conta no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Configuração - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Configuração</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="card-escuro" style="max-width: 400px;">
        <?php if ($erro): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>
        <?php if ($sucesso): ?><p class="sucesso"><?= htmlspecialchars($sucesso) ?></p><?php endif; ?>

        <form method="POST">
            <label>Nome de usuário</label>
            <input type="text" name="nome_usuario" value="<?= htmlspecialchars($usuario_logado["nome_usuario"]) ?>" required>
            <br><br>
            <button class="acao" type="submit">Salvar</button>
        </form>

        <hr style="margin:20px 0;border-color:rgba(255,255,255,0.15);">
        <form method="POST">
            <label>Modo fantasma (ver stories/mensagens sem aparecer como "visto", e ficar sem mostrar status online/visto por último pra ninguém)</label><br>
            <input type="hidden" name="modo_fantasma" value="<?= !empty($usuario_logado["modo_fantasma"]) ? 0 : 1 ?>">
            <button class="acao" type="submit"><?= !empty($usuario_logado["modo_fantasma"]) ? "Desativar" : "Ativar" ?> modo fantasma</button>
        </form>
    </div>
</div>

</body>
</html>
