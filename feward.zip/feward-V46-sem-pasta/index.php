<?php
// Página de entrada do Feward.
// Não inicia sessão nem acessa o banco aqui para evitar que um problema
// de sessão/conexão impeça o redirecionamento inicial do site.
header('Location: login.php', true, 302);
exit;
