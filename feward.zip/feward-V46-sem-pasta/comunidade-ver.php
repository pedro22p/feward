<?php
require_once "auth.php";
require_once "moderacao.php";

$comunidade_id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;
$stmt = $pdo->prepare("SELECT comunidades.*, contas.nome_usuario AS criador_nome FROM comunidades LEFT JOIN contas ON contas.id = comunidades.criador_id WHERE comunidades.id = ?");
$stmt->execute([$comunidade_id]);
$comunidade = $stmt->fetch();

if (!$comunidade) {
    http_response_code(404);
    $pagina_ativa = "comunidade";
    ?>
    <!DOCTYPE html><html lang="pt-br"><head><meta charset="UTF-8"><link rel="stylesheet" href="estilo.css"></head>
    <body><?php include "nav.php"; ?>
    <div class="conteudo"><h1>Comunidade não encontrada</h1><p>Essa comunidade não existe ou foi removida.</p></div>
    </body></html>
    <?php
    exit;
}

$erro = "";

// entrar / sair da comunidade
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["entrar"])) {
    $pdo->prepare("INSERT IGNORE INTO comunidade_membros (comunidade_id, usuario_id) VALUES (?, ?)")
        ->execute([$comunidade_id, $usuario_logado["id"]]);
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["sair"])) {
    $pdo->prepare("DELETE FROM comunidade_membros WHERE comunidade_id = ? AND usuario_id = ?")
        ->execute([$comunidade_id, $usuario_logado["id"]]);
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}

$sou_membro_stmt = $pdo->prepare("SELECT 1 FROM comunidade_membros WHERE comunidade_id = ? AND usuario_id = ?");
$sou_membro_stmt->execute([$comunidade_id, $usuario_logado["id"]]);
$sou_membro = (bool) $sou_membro_stmt->fetchColumn();

// publicar um post na comunidade (só membros)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["conteudo"])) {
    if (!$sou_membro) {
        $erro = "Entre na comunidade pra poder postar.";
    } else {
        $conteudo = trim($_POST["conteudo"]);
        $nome_imagem = null;
        if (!empty($_FILES["imagem"]["name"]) && $_FILES["imagem"]["error"] === UPLOAD_ERR_OK) {
            $extensoes = ["jpg", "jpeg", "png", "gif", "webp"];
            $extensao = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));
            if (in_array($extensao, $extensoes) && @getimagesize($_FILES["imagem"]["tmp_name"]) !== false && $_FILES["imagem"]["size"] <= 5 * 1024 * 1024) {
                $pasta = __DIR__ . "/uploads/posts";
                if (!is_dir($pasta)) mkdir($pasta, 0755, true);
                $nome_imagem = uniqid("post_", true) . "." . $extensao;
                if (!move_uploaded_file($_FILES["imagem"]["tmp_name"], $pasta . "/" . $nome_imagem)) $nome_imagem = null;
            } else {
                $erro = "Imagem inválida (jpg/png/gif/webp até 5MB).";
            }
        }
        if ($erro === "") {
            if ($conteudo === "" && $nome_imagem === null) {
                $erro = "Escreva algo ou envie uma imagem.";
            } elseif (bloquearConteudo($conteudo)) {
                $erro = "Conteúdo bloqueado por conter palavras proibidas.";
            } else {
                $pdo->prepare("INSERT INTO posts (usuario_id, conteudo, imagem, comunidade_id) VALUES (?, ?, ?, ?)")
                    ->execute([$usuario_logado["id"], $conteudo !== "" ? $conteudo : null, $nome_imagem, $comunidade_id]);
                header("Location: comunidade-ver.php?id=" . $comunidade_id);
                exit;
            }
        }
    }
}

// curtir / descurtir
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["curtir_post_id"])) {
    $post_id = (int) $_POST["curtir_post_id"];
    $ja = $pdo->prepare("SELECT 1 FROM curtidas WHERE usuario_id = ? AND post_id = ?");
    $ja->execute([$usuario_logado["id"], $post_id]);
    if ($ja->fetch()) {
        $pdo->prepare("DELETE FROM curtidas WHERE usuario_id = ? AND post_id = ?")->execute([$usuario_logado["id"], $post_id]);
    } else {
        $pdo->prepare("INSERT IGNORE INTO curtidas (usuario_id, post_id) VALUES (?, ?)")->execute([$usuario_logado["id"], $post_id]);
    }
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}

// comentar
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["comentario_post_id"])) {
    $texto = trim($_POST["comentario_texto"] ?? "");
    if ($texto !== "" && !bloquearConteudo($texto)) {
        $pdo->prepare("INSERT INTO comentarios (post_id, usuario_id, conteudo) VALUES (?, ?, ?)")
            ->execute([(int) $_POST["comentario_post_id"], $usuario_logado["id"], $texto]);
    }
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}

// editar um comentário (somente o dono do comentário)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["editar_comentario_id"])) {
    $comentario_id = (int) $_POST["editar_comentario_id"];
    $novo_texto = trim($_POST["novo_comentario_texto"] ?? "");
    if ($novo_texto !== "" && !bloquearConteudo($novo_texto)) {
        $stmt = $pdo->prepare("UPDATE comentarios SET conteudo = ? WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$novo_texto, $comentario_id, $usuario_logado["id"]]);
    }
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}

// excluir um comentário (somente o dono do comentário)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["excluir_comentario_id"])) {
    $comentario_id = (int) $_POST["excluir_comentario_id"];
    $pdo->prepare("DELETE FROM comentarios WHERE id = ? AND usuario_id = ?")
        ->execute([$comentario_id, $usuario_logado["id"]]);
    header("Location: comunidade-ver.php?id=" . $comunidade_id);
    exit;
}

$total_membros = $pdo->prepare("SELECT COUNT(*) FROM comunidade_membros WHERE comunidade_id = ?");
$total_membros->execute([$comunidade_id]);
$total_membros = (int) $total_membros->fetchColumn();

$posts_stmt = $pdo->prepare("
    SELECT posts.*, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos,
        (SELECT COUNT(*) FROM curtidas WHERE curtidas.post_id = posts.id) AS total_curtidas,
        EXISTS(SELECT 1 FROM curtidas WHERE curtidas.post_id = posts.id AND curtidas.usuario_id = ?) AS curti
    FROM posts
    JOIN contas ON contas.id = posts.usuario_id
    WHERE posts.comunidade_id = ?
    ORDER BY posts.criado_em DESC
    LIMIT 50
");
$posts_stmt->execute([$usuario_logado["id"], $comunidade_id]);
$posts = $posts_stmt->fetchAll();

$comentarios_por_post = [];
if ($posts) {
    $ids = array_column($posts, "id");
    $marcadores = implode(",", array_fill(0, count($ids), "?"));
    $cs = $pdo->prepare("
        SELECT comentarios.id, comentarios.post_id, comentarios.conteudo, contas.id AS autor_id, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos
        FROM comentarios JOIN contas ON contas.id = comentarios.usuario_id
        WHERE comentarios.post_id IN ($marcadores) ORDER BY comentarios.criado_em ASC
    ");
    $cs->execute($ids);
    foreach ($cs->fetchAll() as $c) $comentarios_por_post[$c["post_id"]][] = $c;
}

$pagina_ativa = "comunidade";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Comunidade <?= htmlspecialchars($comunidade["nome"]) ?> no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title><?= htmlspecialchars($comunidade["nome"]) ?> - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .cabecalho-comunidade { background: linear-gradient(160deg, #060030, #1a1a70); border-radius: 15px; padding: 20px 25px; margin-bottom: 20px; }
        .cabecalho-comunidade h1 { margin: 0 0 6px; }
        .cabecalho-comunidade p { margin: 0 0 10px; color: #ccc; }
        .cabecalho-comunidade .info { font-size: 13px; color: #9aa0e0; }
        .post { background: linear-gradient(160deg, #dfe4ea, #ffffff); color: #111; border-radius: 15px; margin-bottom: 20px; overflow: hidden; }
        .post-cabecalho { display: flex; align-items: center; gap: 10px; padding: 12px 15px; }
        .post-cabecalho a { display: flex; align-items: center; gap: 10px; color: inherit; text-decoration: none; }
        .post-midia { width: 100%; max-height: 520px; object-fit: contain; background: #000; display: block; }
        .post-texto { padding: 10px 15px; }
        .post-comentario-form { display: flex; padding: 10px 15px 15px; gap: 8px; align-items: center; }
        .post-comentario-form input { border-radius: 15px; }
        .post-comentarios { padding: 0 15px 8px; display: flex; flex-direction: column; gap: 8px; }
        .post-comentario { display: flex; align-items: flex-start; gap: 8px; font-size: 14px; color: #222; background: #f0f2f5; border-radius: 14px; padding: 8px 12px; }
        .post-comentario-texto { flex: 1; min-width: 0; overflow-wrap: anywhere; word-break: break-word; }
        .post-comentario-acoes { display: flex; gap: 6px; margin-left: 4px; flex-shrink: 0; }
        .post-comentario-acoes button { background: none; border: none; cursor: pointer; font-size: 12px; color: #888; padding: 0; }
        .post-comentario-acoes button:hover { color: #333; }
        .post-comentario-editar { display: none; flex: 1; gap: 6px; align-items: center; }
        .post-comentario-editar.ativo { display: flex; }
        .post-comentario-editar input[type=text] { flex: 1; border-radius: 12px; padding: 6px 10px; font-size: 13px; }
        .post-comentario.editando .post-comentario-texto { display: none; }
        .avatar-mini { width: 30px; height: 30px; min-width: 30px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; }
        .avatar-mini-pequeno { width: 26px; height: 26px; min-width: 26px; border-radius: 50%; object-fit: cover; background: #ccc; display: inline-flex; align-items: center; justify-content: center; font-size: 13px; }
        .criar-post { background: rgba(0,0,0,0.5); border-radius: 30px; padding: 15px 25px; margin-bottom: 25px; }
        .criar-post form { display: flex; flex-direction: column; gap: 10px; }
        .criar-post textarea { min-height: 45px; border-radius: 20px; resize: vertical; }
        .post-midia { cursor: zoom-in; }
        .lightbox-fundo { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.9); z-index: 999; align-items: center; justify-content: center; padding: 20px; }
        .lightbox-fundo.ativo { display: flex; }
        .lightbox-fundo img { max-width: 100%; max-height: 100%; object-fit: contain; border-radius: 6px; }
        .lightbox-fechar { position: absolute; top: 18px; right: 25px; color: #fff; font-size: 32px; cursor: pointer; line-height: 1; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="cabecalho-comunidade">
        <h1><?= htmlspecialchars($comunidade["nome"]) ?></h1>
        <?php if (!empty($comunidade["descricao"])): ?><p><?= nl2br(htmlspecialchars($comunidade["descricao"])) ?></p><?php endif; ?>
        <div class="info">
            <?= $total_membros ?> membro(s)<?php if (!empty($comunidade["criador_nome"])): ?> · criada por <?= htmlspecialchars($comunidade["criador_nome"]) ?><?php endif; ?>
        </div>
        <form method="POST" style="margin-top:12px;">
            <?php if ($sou_membro): ?>
                <input type="hidden" name="sair" value="1">
                <button class="acao" type="submit" style="background:#888;">Sair da comunidade</button>
            <?php else: ?>
                <input type="hidden" name="entrar" value="1">
                <button class="acao" type="submit">Entrar na comunidade</button>
            <?php endif; ?>
        </form>
    </div>

    <?php if ($erro): ?><p class="erro"><?= htmlspecialchars($erro) ?></p><?php endif; ?>

    <?php if ($sou_membro): ?>
        <div class="criar-post">
            <form method="POST" enctype="multipart/form-data">
                <textarea name="conteudo" placeholder="Postar em <?= htmlspecialchars($comunidade["nome"]) ?>..."></textarea>
                <input type="file" name="imagem" accept="image/*">
                <button class="acao" type="submit">Publicar</button>
            </form>
        </div>
    <?php else: ?>
        <p style="color:#aaa;">Entre na comunidade pra poder postar.</p>
    <?php endif; ?>

    <?php if (!$posts): ?>
        <p style="color:#aaa;">Ainda não tem nenhum post nessa comunidade.</p>
    <?php endif; ?>

    <?php foreach ($posts as $post): ?>
        <div class="post">
            <div class="post-cabecalho">
                <a href="perfil-usuario.php?id=<?= (int) $post["usuario_id"] ?>">
                    <?php if (!empty($post["foto_perfil"])): ?>
                        <img class="avatar-mini" src="avatar.php?id=<?= (int) $post["usuario_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($post["foto_perfil_pos"] ?? "50% 50%") ?>;">
                    <?php else: ?>
                        <span class="avatar-mini">👤</span>
                    <?php endif; ?>
                    <strong><?= htmlspecialchars($post["nome_usuario"]) ?></strong>
                </a>
                <span style="color:#555;font-size:12px;margin-left:auto;"><?= date("d/m/Y H:i", strtotime($post["criado_em"])) ?></span>
            </div>

            <?php if ($post["imagem"]): ?>
                <img class="post-midia" src="midia.php?pasta=posts&arquivo=<?= urlencode($post["imagem"]) ?>" alt="post" onclick="abrirLightbox(this.src)">
            <?php endif; ?>

            <?php if ($post["conteudo"]): ?>
                <div class="post-texto"><?= nl2br(htmlspecialchars($post["conteudo"])) ?></div>
            <?php endif; ?>

            <div style="padding: 0 15px;">
                <form method="POST">
                    <input type="hidden" name="curtir_post_id" value="<?= $post["id"] ?>">
                    <button class="acao" type="submit" style="background-color:<?= $post["curti"] ? "#ff3b6b" : "#888" ?>;">
                        <?= $post["curti"] ? "❤️" : "🤍" ?> <?= (int) $post["total_curtidas"] ?>
                    </button>
                </form>
            </div>

            <?php if (!empty($comentarios_por_post[$post["id"]])): ?>
                <div class="post-comentarios">
                    <?php foreach ($comentarios_por_post[$post["id"]] as $com): ?>
                        <div class="post-comentario" id="comentario-<?= (int) $com["id"] ?>">
                            <a href="perfil-usuario.php?id=<?= (int) $com["autor_id"] ?>">
                                <?php if (!empty($com["foto_perfil"])): ?>
                                    <img class="avatar-mini-pequeno" src="avatar.php?id=<?= (int) $com["autor_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($com["foto_perfil_pos"] ?? "50% 50%") ?>;">
                                <?php else: ?>
                                    <span class="avatar-mini-pequeno">👤</span>
                                <?php endif; ?>
                            </a>
                            <div class="post-comentario-texto"><strong><?= htmlspecialchars($com["nome_usuario"]) ?>:</strong> <?= htmlspecialchars($com["conteudo"]) ?></div>
                            <?php if ((int) $com["autor_id"] === (int) $usuario_logado["id"]): ?>
                                <form class="post-comentario-editar" id="editar-form-<?= (int) $com["id"] ?>" method="POST">
                                    <input type="hidden" name="editar_comentario_id" value="<?= (int) $com["id"] ?>">
                                    <input type="text" name="novo_comentario_texto" value="<?= htmlspecialchars($com["conteudo"]) ?>" required maxlength="500">
                                    <button class="acao" type="submit" style="padding:6px 12px;">Salvar</button>
                                    <button type="button" class="acao" style="padding:6px 12px;background:#888;" onclick="cancelarEdicaoComentario(<?= (int) $com["id"] ?>)">Cancelar</button>
                                </form>
                                <div class="post-comentario-acoes">
                                    <button type="button" title="Editar" onclick="editarComentario(<?= (int) $com["id"] ?>)">✏️</button>
                                    <form method="POST" onsubmit="return confirm('Apagar esse comentário?');" style="display:inline;">
                                        <input type="hidden" name="excluir_comentario_id" value="<?= (int) $com["id"] ?>">
                                        <button type="submit" title="Apagar">🗑️</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ($sou_membro): ?>
                <form class="post-comentario-form" method="POST">
                    <input type="hidden" name="comentario_post_id" value="<?= $post["id"] ?>">
                    <input type="text" name="comentario_texto" placeholder="Comentário" required>
                    <button class="acao" type="submit">➤</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<div class="lightbox-fundo" id="lightbox" onclick="fecharLightbox()">
    <span class="lightbox-fechar" onclick="fecharLightbox()">&times;</span>
    <img id="lightbox-img" src="" alt="">
</div>

<script>
function abrirLightbox(src) {
    document.getElementById("lightbox-img").src = src;
    document.getElementById("lightbox").classList.add("ativo");
}
function fecharLightbox() {
    document.getElementById("lightbox").classList.remove("ativo");
    document.getElementById("lightbox-img").src = "";
}
function editarComentario(id) {
    document.getElementById("comentario-" + id).classList.add("editando");
    document.getElementById("editar-form-" + id).classList.add("ativo");
}
function cancelarEdicaoComentario(id) {
    document.getElementById("comentario-" + id).classList.remove("editando");
    document.getElementById("editar-form-" + id).classList.remove("ativo");
}
</script>

</body>
</html>
