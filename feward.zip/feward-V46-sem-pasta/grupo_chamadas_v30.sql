-- Feward V30 - chamadas de voz/vídeo e compartilhamento de tela nos grupos
CREATE TABLE IF NOT EXISTS grupo_chamadas (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    grupo_id INT UNSIGNED NOT NULL,
    criador_id INT UNSIGNED NOT NULL,
    tipo ENUM('voz','video') NOT NULL DEFAULT 'video',
    status ENUM('ativa','encerrada') NOT NULL DEFAULT 'ativa',
    criada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    encerrada_em TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_gc_grupo_status (grupo_id, status),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (criador_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS grupo_chamada_membros (
    chamada_id BIGINT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    entrou_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    saiu_em TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (chamada_id, usuario_id),
    KEY idx_gcm_usuario (usuario_id),
    FOREIGN KEY (chamada_id) REFERENCES grupo_chamadas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS grupo_chamada_sinais (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    chamada_id BIGINT UNSIGNED NOT NULL,
    remetente_id INT UNSIGNED NOT NULL,
    destinatario_id INT UNSIGNED NULL,
    tipo VARCHAR(20) NOT NULL,
    dados LONGTEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_gcs_chamada_id (chamada_id, id),
    KEY idx_gcs_destino (chamada_id, destinatario_id, id),
    FOREIGN KEY (chamada_id) REFERENCES grupo_chamadas(id) ON DELETE CASCADE,
    FOREIGN KEY (remetente_id) REFERENCES contas(id) ON DELETE CASCADE,
    FOREIGN KEY (destinatario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS grupo_convites (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    grupo_id INT UNSIGNED NOT NULL,
    convidante_id INT UNSIGNED NOT NULL,
    convidado_id INT UNSIGNED NOT NULL,
    status ENUM('pendente','aceito','recusado') NOT NULL DEFAULT 'pendente',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    respondido_em TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_grupo_convite (grupo_id, convidado_id),
    KEY idx_gci_convidado_status (convidado_id, status),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (convidante_id) REFERENCES contas(id) ON DELETE CASCADE,
    FOREIGN KEY (convidado_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
