-- Feward V16 - schema principal
-- Seguro para um banco que JÁ possui a tabela contas.
-- Não apaga dados existentes.
-- MariaDB: ADD COLUMN IF NOT EXISTS evita o erro "Duplicate column name".

ALTER TABLE contas ADD COLUMN IF NOT EXISTS bio TEXT NULL;
ALTER TABLE contas ADD COLUMN IF NOT EXISTS foto_perfil VARCHAR(255) NULL;
ALTER TABLE contas ADD COLUMN IF NOT EXISTS criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

CREATE TABLE IF NOT EXISTS comunidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    imagem VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comunidade_membros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    comunidade_id INT NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    UNIQUE KEY unico_membro (comunidade_id, usuario_id),
    FOREIGN KEY (comunidade_id) REFERENCES comunidades(id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    conteudo TEXT NULL,
    imagem VARCHAR(255) NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS salvos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    post_id INT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id),
    FOREIGN KEY (post_id) REFERENCES posts(id),
    UNIQUE KEY unico_salvo (usuario_id, post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS amizades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    amigo_id INT UNSIGNED NOT NULL,
    status ENUM('pendente','aceito') DEFAULT 'pendente',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id),
    FOREIGN KEY (amigo_id) REFERENCES contas(id),
    UNIQUE KEY unica_amizade (usuario_id, amigo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    remetente_id INT UNSIGNED NOT NULL,
    destinatario_id INT UNSIGNED NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    lida BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (remetente_id) REFERENCES contas(id),
    FOREIGN KEY (destinatario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Cria as comunidades padrão somente se ainda não existirem.
INSERT INTO comunidades (nome)
SELECT 'Jogos' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'Jogos');
INSERT INTO comunidades (nome)
SELECT 'FanArte' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'FanArte');
INSERT INTO comunidades (nome)
SELECT 'Digital Circus' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'Digital Circus');
INSERT INTO comunidades (nome)
SELECT 'Animes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'Animes');
INSERT INTO comunidades (nome)
SELECT 'Filmes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'Filmes');
INSERT INTO comunidades (nome)
SELECT 'Memes' WHERE NOT EXISTS (SELECT 1 FROM comunidades WHERE nome = 'Memes');
