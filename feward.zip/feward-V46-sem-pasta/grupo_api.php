<?php
// V30: API dos grupos e da sinalização WebRTC.
require_once "auth.php";
header("Content-Type: application/json; charset=utf-8");

$acao = $_POST["acao"] ?? $_GET["acao"] ?? "";
$eu = (int) $usuario_logado["id"];
$grupo_id = (int) ($_POST["grupo_id"] ?? $_GET["grupo"] ?? 0);

function falhar(int $codigo, string $msg) {
    http_response_code($codigo);
    echo json_encode(["ok" => false, "erro" => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}
function responder(array $dados) {
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}
function membro(PDO $pdo, int $grupo_id, int $usuario_id): bool {
    $s = $pdo->prepare("SELECT 1 FROM grupo_membros WHERE grupo_id=? AND usuario_id=?");
    $s->execute([$grupo_id, $usuario_id]);
    return (bool)$s->fetchColumn();
}
function membroChamada(PDO $pdo, int $chamada_id, int $usuario_id): bool {
    $s = $pdo->prepare("SELECT 1 FROM grupo_chamada_membros WHERE chamada_id=? AND usuario_id=? AND saiu_em IS NULL");
    $s->execute([$chamada_id, $usuario_id]);
    return (bool)$s->fetchColumn();
}
$acoes_sem_membro = ["aceitar_convite", "recusar_convite"];
if (!in_array($acao, $acoes_sem_membro, true) && ($grupo_id <= 0 || !membro($pdo, $grupo_id, $eu))) {
    falhar(403, "Você não faz parte deste grupo.");
}

switch ($acao) {
    case "enviar":
        $texto = trim($_POST["conteudo"] ?? "");
        if ($texto === "") falhar(400, "Mensagem vazia.");
        if (mb_strlen($texto) > 2000) falhar(400, "Mensagem muito longa (máximo 2000 caracteres).");
        $pdo->prepare("INSERT INTO grupo_mensagens (grupo_id, remetente_id, conteudo) VALUES (?, ?, ?)")->execute([$grupo_id, $eu, $texto]);
        $s=$pdo->prepare("SELECT gm.id,gm.remetente_id,gm.conteudo,gm.criado_em,c.nome_usuario FROM grupo_mensagens gm JOIN contas c ON c.id=gm.remetente_id WHERE gm.id=?");
        $s->execute([$pdo->lastInsertId()]);
        responder(["ok"=>true,"mensagem"=>$s->fetch()]);

    case "atualizar":
        $depois=(int)($_GET["depois_de"]??0);
        $s=$pdo->prepare("SELECT gm.id,gm.remetente_id,gm.conteudo,gm.criado_em,c.nome_usuario FROM grupo_mensagens gm JOIN contas c ON c.id=gm.remetente_id WHERE gm.grupo_id=? AND gm.id>? ORDER BY gm.id ASC LIMIT 200");
        $s->execute([$grupo_id,$depois]);
        responder(["ok"=>true,"mensagens"=>$s->fetchAll()]);

    case "sair":
        $pdo->prepare("DELETE FROM grupo_membros WHERE grupo_id=? AND usuario_id=?")->execute([$grupo_id,$eu]);
        $s=$pdo->prepare("SELECT COUNT(*) FROM grupo_membros WHERE grupo_id=?"); $s->execute([$grupo_id]);
        if ((int)$s->fetchColumn()===0) $pdo->prepare("DELETE FROM grupos WHERE id=?")->execute([$grupo_id]);
        responder(["ok"=>true]);

    case "convidar":
        $raw=$_POST["usuario_ids"]??"[]"; $ids=json_decode($raw,true);
        if(!is_array($ids)) falhar(400,"Convites inválidos.");
        $ids=array_values(array_unique(array_filter(array_map("intval",$ids),fn($id)=>$id>0 && $id!==$eu)));
        if(!$ids) falhar(400,"Escolha pelo menos uma pessoa.");
        if(count($ids)>50) falhar(400,"Você pode convidar no máximo 50 pessoas por vez.");
        $ins=$pdo->prepare("INSERT INTO grupo_convites (grupo_id,convidante_id,convidado_id,status) VALUES (?,?,?,'pendente') ON DUPLICATE KEY UPDATE convidante_id=VALUES(convidante_id), status='pendente', criado_em=CURRENT_TIMESTAMP");
        $ok=0;
        foreach($ids as $uid){
            $q=$pdo->prepare("SELECT 1 FROM contas WHERE id=? AND id<>?"); $q->execute([$uid,$eu]); if(!$q->fetchColumn()) continue;
            $q=$pdo->prepare("SELECT 1 FROM grupo_membros WHERE grupo_id=? AND usuario_id=?"); $q->execute([$grupo_id,$uid]); if($q->fetchColumn()) continue;
            $ins->execute([$grupo_id,$eu,$uid]); $ok++;
        }
        responder(["ok"=>true,"mensagem"=>$ok." convite(s) enviado(s)."]);

    case "aceitar_convite":
        $convite=(int)($_POST["convite_id"]??0);
        $s=$pdo->prepare("SELECT gc.grupo_id,g.nome FROM grupo_convites gc JOIN grupos g ON g.id=gc.grupo_id WHERE gc.id=? AND gc.convidado_id=? AND gc.status='pendente'"); $s->execute([$convite,$eu]); $c=$s->fetch();
        if(!$c) falhar(404,"Convite não encontrado.");
        $q=$pdo->prepare("SELECT 1 FROM grupo_membros WHERE grupo_id=? AND usuario_id=?"); $q->execute([$c["grupo_id"],$eu]);
        if(!$q->fetchColumn()) {
            $pdo->prepare("INSERT INTO grupo_membros (grupo_id,usuario_id) VALUES (?,?)")->execute([$c["grupo_id"],$eu]);
            $nome=$usuario_logado["nome_usuario"]??"Alguém";
            $pdo->prepare("INSERT INTO grupo_mensagens (grupo_id,remetente_id,conteudo) VALUES (?,?,?)")->execute([$c["grupo_id"],$eu,"👋 ".$nome." entrou no grupo."]);
        }
        $pdo->prepare("UPDATE grupo_convites SET status='aceito',respondido_em=CURRENT_TIMESTAMP WHERE id=?")->execute([$convite]);
        responder(["ok"=>true,"grupo_id"=>(int)$c["grupo_id"]]);

    case "recusar_convite":
        $convite=(int)($_POST["convite_id"]??0);
        $pdo->prepare("UPDATE grupo_convites SET status='recusado',respondido_em=CURRENT_TIMESTAMP WHERE id=? AND convidado_id=? AND status='pendente'")->execute([$convite,$eu]);
        responder(["ok"=>true]);

    case "chamada_criar":
        $tipo=($_POST["tipo"]??"video")==="voz"?"voz":"video";
        $s=$pdo->prepare("SELECT id FROM grupo_chamadas WHERE grupo_id=? AND status='ativa' ORDER BY id DESC LIMIT 1");
        $s->execute([$grupo_id]); $ativa=$s->fetchColumn();
        if ($ativa) responder(["ok"=>true,"chamada_id"=>(int)$ativa,"existente"=>true]);
        $pdo->beginTransaction();
        $pdo->prepare("INSERT INTO grupo_chamadas (grupo_id,criador_id,tipo) VALUES (?,?,?)")->execute([$grupo_id,$eu,$tipo]);
        $cid=(int)$pdo->lastInsertId();
        $pdo->prepare("INSERT INTO grupo_chamada_membros (chamada_id,usuario_id) VALUES (?,?)")->execute([$cid,$eu]);
        $pdo->commit();
        responder(["ok"=>true,"chamada_id"=>$cid,"tipo"=>$tipo,"existente"=>false]);

    case "chamada_entrar":
        $cid=(int)($_POST["chamada_id"]??0);
        $s=$pdo->prepare("SELECT id,tipo FROM grupo_chamadas WHERE id=? AND grupo_id=? AND status='ativa'");
        $s->execute([$cid,$grupo_id]); $call=$s->fetch();
        if(!$call) falhar(404,"A chamada não está mais ativa.");
        $pdo->prepare("INSERT INTO grupo_chamada_membros (chamada_id,usuario_id,saiu_em) VALUES (?,?,NULL) ON DUPLICATE KEY UPDATE saiu_em=NULL,entrou_em=CURRENT_TIMESTAMP")->execute([$cid,$eu]);
        $s=$pdo->prepare("SELECT u.id,u.nome_usuario FROM grupo_chamada_membros m JOIN contas u ON u.id=m.usuario_id WHERE m.chamada_id=? AND m.saiu_em IS NULL AND m.usuario_id<>? ORDER BY m.usuario_id");
        $s->execute([$cid,$eu]);
        responder(["ok"=>true,"tipo"=>$call["tipo"],"participantes"=>$s->fetchAll()]);

    case "chamada_ativa":
        $s=$pdo->prepare("SELECT id,tipo,status FROM grupo_chamadas WHERE grupo_id=? AND status='ativa' ORDER BY id DESC LIMIT 1");
        $s->execute([$grupo_id]); $call=$s->fetch();
        if(!$call) responder(["ok"=>true,"ativa"=>false]);
        $s=$pdo->prepare("SELECT u.id,u.nome_usuario FROM grupo_chamada_membros m JOIN contas u ON u.id=m.usuario_id WHERE m.chamada_id=? AND m.saiu_em IS NULL ORDER BY m.usuario_id");
        $s->execute([$call["id"]]);
        responder(["ok"=>true,"ativa"=>true,"chamada"=>$call,"participantes"=>$s->fetchAll()]);

    case "chamada_estado":
        $cid=(int)($_GET["chamada_id"]??0);
        $s=$pdo->prepare("SELECT id,tipo,status,criador_id FROM grupo_chamadas WHERE id=? AND grupo_id=?"); $s->execute([$cid,$grupo_id]); $call=$s->fetch();
        if(!$call) falhar(404,"Chamada não encontrada.");
        if(!membroChamada($pdo,$cid,$eu) && $call["status"]==='ativa') falhar(403,"Você não está nesta chamada.");
        $s=$pdo->prepare("SELECT u.id,u.nome_usuario FROM grupo_chamada_membros m JOIN contas u ON u.id=m.usuario_id WHERE m.chamada_id=? AND m.saiu_em IS NULL ORDER BY m.usuario_id"); $s->execute([$cid]);
        responder(["ok"=>true,"chamada"=>$call,"participantes"=>$s->fetchAll()]);

    case "sinal":
        $cid=(int)($_POST["chamada_id"]??0);
        if(!membroChamada($pdo,$cid,$eu)) falhar(403,"Você não está nesta chamada.");
        $tipo=$_POST["tipo"]??"";
        $permitidos=["offer","answer","ice","renegotiate"];
        if(!in_array($tipo,$permitidos,true)) falhar(400,"Sinalização inválida.");
        $dados=$_POST["dados"]??"";
        if(strlen($dados)>50000) falhar(413,"Sinalização muito grande.");
        json_decode($dados,true); if(json_last_error()!==JSON_ERROR_NONE) falhar(400,"Dados WebRTC inválidos.");
        $dest=(int)($_POST["destinatario_id"]??0); $dest=$dest>0?$dest:null;
        if($dest!==null && !membroChamada($pdo,$cid,$dest)) falhar(403,"Destinatário não está na chamada.");
        $pdo->prepare("INSERT INTO grupo_chamada_sinais (chamada_id,remetente_id,destinatario_id,tipo,dados) VALUES (?,?,?,?,?)")->execute([$cid,$eu,$dest,$tipo,$dados]);
        responder(["ok"=>true]);

    case "sinais":
        $cid=(int)($_GET["chamada_id"]??0); $depois=(int)($_GET["depois_de"]??0);
        if(!membroChamada($pdo,$cid,$eu)) falhar(403,"Você não está nesta chamada.");
        $s=$pdo->prepare("SELECT id,remetente_id,destinatario_id,tipo,dados FROM grupo_chamada_sinais WHERE chamada_id=? AND id>? AND (destinatario_id IS NULL OR destinatario_id=?) AND remetente_id<>? ORDER BY id ASC LIMIT 100");
        $s->execute([$cid,$depois,$eu,$eu]);
        responder(["ok"=>true,"sinais"=>$s->fetchAll()]);

    case "chamada_sair":
        $cid=(int)($_POST["chamada_id"]??0);
        if(!membroChamada($pdo,$cid,$eu)) responder(["ok"=>true]);
        $pdo->prepare("UPDATE grupo_chamada_membros SET saiu_em=CURRENT_TIMESTAMP WHERE chamada_id=? AND usuario_id=?")->execute([$cid,$eu]);
        $s=$pdo->prepare("SELECT COUNT(*) FROM grupo_chamada_membros WHERE chamada_id=? AND saiu_em IS NULL"); $s->execute([$cid]);
        if((int)$s->fetchColumn()===0) $pdo->prepare("UPDATE grupo_chamadas SET status='encerrada',encerrada_em=CURRENT_TIMESTAMP WHERE id=?")->execute([$cid]);
        responder(["ok"=>true]);

    case "chamada_encerrar":
        $cid=(int)($_POST["chamada_id"]??0);
        $s=$pdo->prepare("SELECT criador_id FROM grupo_chamadas WHERE id=? AND grupo_id=?"); $s->execute([$cid,$grupo_id]); $call=$s->fetch();
        if(!$call) falhar(404,"Chamada não encontrada.");
        if((int)$call["criador_id"]!==$eu) falhar(403,"Só quem iniciou pode encerrar a chamada.");
        $pdo->prepare("UPDATE grupo_chamadas SET status='encerrada',encerrada_em=CURRENT_TIMESTAMP WHERE id=?")->execute([$cid]);
        $pdo->prepare("UPDATE grupo_chamada_membros SET saiu_em=CURRENT_TIMESTAMP WHERE chamada_id=? AND saiu_em IS NULL")->execute([$cid]);
        responder(["ok"=>true]);

    default: falhar(400,"Ação inválida.");
}
