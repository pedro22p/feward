<?php
require_once "auth.php";

// desfazer salvar
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["remover_salvo_id"])) {
    $stmt = $pdo->prepare("DELETE FROM salvos WHERE usuario_id = ? AND post_id = ?");
    $stmt->execute([$usuario_logado["id"], (int) $_POST["remover_salvo_id"]]);
    header("Location: salvos.php");
    exit;
}

$salvos = $pdo->prepare("
    SELECT posts.id, posts.imagem, posts.conteudo
    FROM salvos
    JOIN posts ON posts.id = salvos.post_id
    WHERE salvos.usuario_id = ?
    ORDER BY salvos.criado_em DESC
");
$salvos->execute([$usuario_logado["id"]]);
$salvos = $salvos->fetchAll();

$pagina_ativa = "salvos";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Itens salvos no Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Salvos - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .grade-salvos { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .item-salvo { position: relative; border-radius: 15px; overflow: hidden; background: #111; }
        .item-salvo img { width: 100%; height: 180px; object-fit: cover; display: block; }
        .item-salvo form { position: absolute; top: 8px; right: 8px; }
        .item-salvo button { background: rgba(0,0,0,0.7); border: none; color: white; border-radius: 10px; padding: 5px 10px; cursor: pointer; }
        .item-sem-imagem { padding: 15px; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Vídeos &amp; fotos Salvos</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="grade-salvos">
        <?php foreach ($salvos as $s): ?>
            <div class="item-salvo">
                <?php if ($s["imagem"]): ?>
                    <?php $salvo_img_src = "midia.php?pasta=posts&arquivo=" . urlencode($s["imagem"]); ?>
                    <img src="<?= htmlspecialchars($salvo_img_src) ?>" alt="salvo" onclick="abrirLightbox(this.src)">
                <?php else: ?>
                    <div class="item-sem-imagem"><?= nl2br(htmlspecialchars($s["conteudo"])) ?></div>
                <?php endif; ?>
                <form method="POST">
                    <input type="hidden" name="remover_salvo_id" value="<?= $s["id"] ?>">
                    <button type="submit">Remover</button>
                </form>
            </div>
        <?php endforeach; ?>
        <?php if (empty($salvos)): ?>
            <p>Você ainda não salvou nada. Salve posts a partir do Início.</p>
        <?php endif; ?>
    </div>
</div>

<div class="lightbox-overlay" id="lightbox-overlay" onclick="fecharLightbox()">
    <button class="lightbox-fechar" type="button" onclick="fecharLightbox()">&times;</button>
    <img id="lightbox-img" src="" alt="Imagem ampliada" onclick="event.stopPropagation()">
</div>
<script src="midia.js"></script>

</body>
</html>
