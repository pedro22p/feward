<?php
require_once "auth.php";

header("Content-Type: application/json; charset=utf-8");

$acao = $_POST["acao"] ?? $_GET["acao"] ?? "";

switch ($acao) {

    // "batida de presença": chamado periodicamente pelo navegador enquanto
    // o app fica aberto, pra manter a conta como online e avisar que as
    // mensagens pendentes pra mim chegaram no meu aparelho (entregue).
    case "ping":
        $pdo->prepare("UPDATE contas SET ultimo_acesso = UTC_TIMESTAMP() WHERE id = ?")
            ->execute([$usuario_logado["id"]]);

        $pdo->prepare("
            UPDATE mensagens
            SET entregue = TRUE, entregue_em = UTC_TIMESTAMP()
            WHERE destinatario_id = ? AND entregue = FALSE
        ")->execute([$usuario_logado["id"]]);

        echo json_encode(["ok" => true]);
        break;

    // status (online/offline/visto por último) de uma ou mais contas,
    // já respeitando o modo fantasma de cada uma.
    case "status":
        $ids_brutos = $_GET["ids"] ?? "";
        $ids = array_values(array_unique(array_filter(array_map("intval", explode(",", $ids_brutos)))));

        if (empty($ids)) {
            echo json_encode(["ok" => true, "status" => []]);
            break;
        }

        $marcadores = implode(",", array_fill(0, count($ids), "?"));
        $stmt = $pdo->prepare("SELECT id, ultimo_acesso, modo_fantasma FROM contas WHERE id IN ($marcadores)");
        $stmt->execute($ids);

        $resultado = [];
        foreach ($stmt->fetchAll() as $conta) {
            $resultado[$conta["id"]] = feward_status_usuario($conta);
        }

        echo json_encode(["ok" => true, "status" => $resultado]);
        break;

    default:
        http_response_code(400);
        echo json_encode(["erro" => "Ação inválida."]);
}
