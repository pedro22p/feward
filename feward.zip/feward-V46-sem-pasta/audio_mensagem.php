<?php
// Serve o áudio de uma mensagem SOMENTE para quem participa da conversa
// (remetente ou destinatário). Diferente de midia.php (posts/vídeos/stories,
// que são públicos pra quem está logado), mensagens são privadas.
require_once "conexao.php";
session_start();

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(404);
    exit;
}

$meu_id = (int) $_SESSION["usuario_id"];
$mensagem_id = isset($_GET["id"]) ? (int) $_GET["id"] : 0;

$stmt = $pdo->prepare("SELECT remetente_id, destinatario_id, audio FROM mensagens WHERE id = ? AND tipo = 'audio'");
$stmt->execute([$mensagem_id]);
$msg = $stmt->fetch();

if (!$msg || empty($msg["audio"])) {
    http_response_code(404);
    exit;
}

if ($meu_id !== (int) $msg["remetente_id"] && $meu_id !== (int) $msg["destinatario_id"]) {
    http_response_code(403);
    exit;
}

// Só aceita nomes de arquivo "limpos" (sem ../ nem caminhos).
if (!preg_match('#^[A-Za-z0-9._-]+$#', $msg["audio"])) {
    http_response_code(404);
    exit;
}

$caminho = __DIR__ . "/uploads/audios/" . $msg["audio"];
if (!is_file($caminho) || !is_readable($caminho)) {
    http_response_code(404);
    exit;
}

$tamanho = filesize($caminho);

$mime = "application/octet-stream";
if (function_exists("finfo_open")) {
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo !== false) {
        $mime = finfo_file($finfo, $caminho) ?: $mime;
        finfo_close($finfo);
    }
}

header("Content-Type: " . $mime);
header("Cache-Control: private, max-age=3600");
header("Accept-Ranges: bytes");

// Suporte a Range (necessário pra adiantar/voltar o áudio no player).
if (isset($_SERVER["HTTP_RANGE"])) {
    if ($tamanho <= 0 || !preg_match('/bytes=(\d*)-(\d*)/i', $_SERVER["HTTP_RANGE"], $m)) {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    }

    if ($m[1] === "" && $m[2] === "") {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    } elseif ($m[1] === "") {
        $quantidade = (int) $m[2];
        if ($quantidade <= 0) {
            header("Content-Range: bytes */$tamanho");
            http_response_code(416);
            exit;
        }
        $inicio = max(0, $tamanho - $quantidade);
        $fim = $tamanho - 1;
    } else {
        $inicio = (int) $m[1];
        $fim = ($m[2] === "") ? ($tamanho - 1) : (int) $m[2];
        $fim = min($fim, $tamanho - 1);
    }

    if ($inicio < 0 || $inicio > $fim || $inicio >= $tamanho) {
        header("Content-Range: bytes */$tamanho");
        http_response_code(416);
        exit;
    }

    http_response_code(206);
    header("Content-Range: bytes $inicio-$fim/$tamanho");
    header("Content-Length: " . ($fim - $inicio + 1));

    $handle = fopen($caminho, "rb");
    if ($handle === false) {
        http_response_code(500);
        exit;
    }
    fseek($handle, $inicio);
    $restante = $fim - $inicio + 1;
    while ($restante > 0 && !feof($handle)) {
        $pedaco = min(8192, $restante);
        echo fread($handle, $pedaco);
        $restante -= $pedaco;
        flush();
    }
    fclose($handle);
    exit;
}

header("Content-Length: " . $tamanho);
readfile($caminho);
exit;
