-- Feward V18 - melhorias
-- Execute depois de posicao_foto.sql (última migração do V16).
-- Não apaga dados existentes. Seguro rodar em cima do banco atual.

-- 1) Comentários em vídeos (mesmo padrão da tabela `comentarios`, mas ligada a `videos`)
CREATE TABLE IF NOT EXISTS comentarios_video (
    id INT AUTO_INCREMENT PRIMARY KEY,
    video_id INT NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    conteudo TEXT NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (video_id) REFERENCES videos(id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) Stories (expiram sozinhos: a consulta só traz quem foi criado_em < 24h)
CREATE TABLE IF NOT EXISTS stories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    arquivo VARCHAR(255) NOT NULL,
    tipo ENUM('imagem','video') NOT NULL DEFAULT 'imagem',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS story_visualizacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    story_id INT NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    visto_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unica_visualizacao (story_id, usuario_id),
    FOREIGN KEY (story_id) REFERENCES stories(id),
    FOREIGN KEY (usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3) A tabela `amizades` (criada no V16) já guarda pedidos de seguir com
--    status pendente/aceito, mas nenhuma tela usa ainda. Aqui só garantimos
--    que ela existe (caso este SQL rode num banco que pulou o V16) e criamos
--    uma tabela de notificações para o pedido aparecer para quem recebeu.
CREATE TABLE IF NOT EXISTS amizades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    amigo_id INT UNSIGNED NOT NULL,
    status ENUM('pendente','aceito') DEFAULT 'pendente',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES contas(id),
    FOREIGN KEY (amigo_id) REFERENCES contas(id),
    UNIQUE KEY unica_amizade (usuario_id, amigo_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notificacoes_seguir (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amizade_id INT NOT NULL,
    de_usuario_id INT UNSIGNED NOT NULL,
    para_usuario_id INT UNSIGNED NOT NULL,
    vista TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (amizade_id) REFERENCES amizades(id),
    FOREIGN KEY (de_usuario_id) REFERENCES contas(id),
    FOREIGN KEY (para_usuario_id) REFERENCES contas(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) Recuperação de senha (esqueci_senha.php / redefinir_senha.php).
--    Faltava neste arquivo incremental (só existia no snapshot banco_feward_v18.sql),
--    então quem seguisse o LEIA-ME-BANCO.txt rodando este arquivo nunca tinha essa
--    tabela criada e a tela "Esqueci minha senha" quebrava com erro de SQL.
CREATE TABLE IF NOT EXISTS recuperacao_senha (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id INT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expira_em DATETIME NOT NULL,
    usado TINYINT(1) NOT NULL DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_recuperacao_token (token_hash),
    KEY idx_recuperacao_usuario (usuario_id),
    KEY idx_recuperacao_expira (expira_em),
    FOREIGN KEY (usuario_id) REFERENCES contas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
