<?php
require_once "auth.php";
require_once "moderacao.php";

$erro = "";
$sucesso = "";

/*
 * Extrai o ID de vídeos do YouTube em formatos comuns.
 * O Feward aceita somente links do YouTube para vídeos externos.
 */
function extrair_id_youtube($url) {
    $url = trim($url);

    $padroes = [
        '~(?:https?://)?(?:www\.)?youtube\.com/watch\?(?:[^#&]*&)*v=([A-Za-z0-9_-]{11})~i',
        '~(?:https?://)?(?:www\.)?youtube\.com/shorts/([A-Za-z0-9_-]{11})~i',
        '~(?:https?://)?youtu\.be/([A-Za-z0-9_-]{11})~i',
        '~(?:https?://)?(?:www\.)?youtube\.com/embed/([A-Za-z0-9_-]{11})~i',
    ];

    foreach ($padroes as $padrao) {
        if (preg_match($padrao, $url, $m)) {
            return $m[1];
        }
    }

    return null;
}

/*
 * Converte os códigos de erro do upload do PHP em mensagens claras.
 */
function mensagem_erro_upload($codigo) {
    $erros = [
        UPLOAD_ERR_INI_SIZE   => "O vídeo é maior que o limite de upload configurado no servidor.",
        UPLOAD_ERR_FORM_SIZE  => "O vídeo é maior que o limite permitido pelo formulário.",
        UPLOAD_ERR_PARTIAL    => "O upload do vídeo foi interrompido antes de terminar.",
        UPLOAD_ERR_NO_FILE    => "Nenhum vídeo foi selecionado.",
        UPLOAD_ERR_NO_TMP_DIR => "O servidor não encontrou a pasta temporária para receber o vídeo.",
        UPLOAD_ERR_CANT_WRITE => "O servidor não conseguiu gravar o vídeo temporário.",
        UPLOAD_ERR_EXTENSION  => "Uma extensão do PHP bloqueou o upload do vídeo.",
    ];

    return $erros[$codigo] ?? "Ocorreu um erro desconhecido durante o upload do vídeo.";
}

// excluir um vídeo (somente o dono pode excluir o próprio vídeo)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["excluir_video_id"])) {
    $video_id = (int) $_POST["excluir_video_id"];

    $stmt = $pdo->prepare("SELECT * FROM videos WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$video_id, $usuario_logado["id"]]);
    $video_para_excluir = $stmt->fetch();

    if ($video_para_excluir) {
        try {
            // Apaga primeiro os comentários do vídeo, senão a exclusão do vídeo
            // pode falhar por causa da referência (chave estrangeira).
            $pdo->prepare("DELETE FROM comentarios_video WHERE video_id = ?")->execute([$video_id]);
            $pdo->prepare("DELETE FROM videos WHERE id = ?")->execute([$video_id]);

            if (!empty($video_para_excluir["arquivo"])) {
                $arquivo_video = __DIR__ . "/uploads/videos/" . $video_para_excluir["arquivo"];
                if (is_file($arquivo_video)) {
                    @unlink($arquivo_video);
                }
            }
        } catch (PDOException $e) {
            $erro = "Não foi possível excluir o vídeo agora.";
        }
    }

    if ($erro === "") {
        header("Location: video.php");
        exit;
    }
}

// comentar em um vídeo
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["comentario_video_id"])) {
    $texto = trim($_POST["comentario_texto"] ?? "");
    if ($texto !== "") {
        if (bloquearConteudo($texto)) {
            $erro = "Comentário bloqueado por conter palavras proibidas.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO comentarios_video (video_id, usuario_id, conteudo) VALUES (?, ?, ?)");
            $stmt->execute([(int) $_POST["comentario_video_id"], $usuario_logado["id"], $texto]);
            header("Location: video.php");
            exit;
        }
    } else {
        header("Location: video.php");
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && !isset($_POST["excluir_video_id"]) && !isset($_POST["comentario_video_id"])) {
    $titulo = trim($_POST["titulo"] ?? "");
    $tipo = ($_POST["tipo"] ?? "") === "longo" ? "longo" : "curto";
    $link_externo = trim($_POST["link_externo"] ?? "");

    $tem_arquivo = isset($_FILES["arquivo"])
        && ($_FILES["arquivo"]["error"] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

    if ($titulo === "") {
        $erro = "Escreva um título para o vídeo.";
    } elseif (mb_strlen($titulo) > 150) {
        $erro = "O título pode ter no máximo 150 caracteres.";
    } elseif ($tem_arquivo && $link_externo !== "") {
        $erro = "Envie um arquivo OU cole um link, não os dois.";
    } elseif (!$tem_arquivo && $link_externo === "") {
        $erro = "Envie um arquivo de vídeo ou cole um link do YouTube.";
    } elseif ($link_externo !== "") {
        // Vídeo externo: transforma o link do YouTube em URL de incorporação.
        $id_youtube = extrair_id_youtube($link_externo);

        if (!$id_youtube) {
            $erro = "Por enquanto só aceitamos links válidos do YouTube.";
        } else {
            try {
                $stmt = $pdo->prepare(
                    "INSERT INTO videos (usuario_id, titulo, tipo, link_externo)
                     VALUES (?, ?, ?, ?)"
                );
                $stmt->execute([
                    (int)$usuario_logado["id"],
                    $titulo,
                    $tipo,
                    "https://www.youtube.com/embed/" . $id_youtube
                ]);

                header("Location: video.php");
                exit;
            } catch (PDOException $e) {
                $erro = "Não foi possível publicar o vídeo agora. Verifique a tabela videos no banco de dados.";
            }
        }
    } else {
        // Upload de arquivo local.
        $arquivo = $_FILES["arquivo"];
        $codigo_upload = (int)($arquivo["error"] ?? UPLOAD_ERR_NO_FILE);

        if ($codigo_upload !== UPLOAD_ERR_OK) {
            $erro = mensagem_erro_upload($codigo_upload);
        } elseif (!isset($arquivo["tmp_name"]) || !is_uploaded_file($arquivo["tmp_name"])) {
            $erro = "O arquivo enviado não foi reconhecido corretamente pelo servidor.";
        } elseif (($arquivo["size"] ?? 0) <= 0) {
            $erro = "O arquivo de vídeo está vazio.";
        } else {
            $extensoes_permitidas = ["mp4", "webm", "mov", "mkv"];
            $mimes_permitidos = [
                "video/mp4",
                "video/webm",
                "video/quicktime",
                "video/x-matroska",
                "application/octet-stream"
            ];

            $extensao = strtolower(pathinfo($arquivo["name"] ?? "", PATHINFO_EXTENSION));

            if (!in_array($extensao, $extensoes_permitidas, true)) {
                $erro = "Envie um vídeo em MP4, WEBM, MOV ou MKV.";
            } else {
                // Verifica o MIME real quando a extensão finfo estiver disponível.
                $mime_real = null;
                if (function_exists("finfo_open")) {
                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                    if ($finfo !== false) {
                        $mime_real = finfo_file($finfo, $arquivo["tmp_name"]);
                        finfo_close($finfo);
                    }
                }

                if ($mime_real !== null && !in_array($mime_real, $mimes_permitidos, true)) {
                    $erro = "O arquivo enviado não parece ser um vídeo válido.";
                } else {
                    $pasta_uploads = __DIR__ . "/uploads/videos";

                    if (!is_dir($pasta_uploads) && !@mkdir($pasta_uploads, 0755, true)) {
                        $erro = "Não foi possível criar a pasta de vídeos no servidor.";
                    } elseif (!is_writable($pasta_uploads)) {
                        $erro = "A pasta uploads/videos não tem permissão para receber arquivos.";
                    } else {
                        try {
                            $nome_arquivo = "video_" . bin2hex(random_bytes(12)) . "." . $extensao;
                        } catch (Throwable $e) {
                            $nome_arquivo = "video_" . uniqid() . "." . $extensao;
                        }

                        $destino = $pasta_uploads . DIRECTORY_SEPARATOR . $nome_arquivo;

                        if (!move_uploaded_file($arquivo["tmp_name"], $destino)) {
                            $erro = "Não foi possível salvar o vídeo. O servidor pode estar sem permissão ou o limite de upload pode ter sido atingido.";
                        } else {
                            try {
                                $stmt = $pdo->prepare(
                                    "INSERT INTO videos (usuario_id, titulo, tipo, arquivo)
                                     VALUES (?, ?, ?, ?)"
                                );
                                $stmt->execute([
                                    (int)$usuario_logado["id"],
                                    $titulo,
                                    $tipo,
                                    $nome_arquivo
                                ]);

                                header("Location: video.php");
                                exit;
                            } catch (PDOException $e) {
                                // Se o banco falhar, não deixa um arquivo órfão no servidor.
                                @unlink($destino);
                                $erro = "O vídeo foi enviado, mas não foi possível registrar no banco de dados.";
                            }
                        }
                    }
                }
            }
        }
    }
}

$videos_stmt = $pdo->query(
    "SELECT videos.*, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos
     FROM videos
     JOIN contas ON contas.id = videos.usuario_id
     ORDER BY videos.criado_em DESC
     LIMIT 30"
);
$videos = $videos_stmt->fetchAll();

// Busca os comentários dos vídeos carregados acima, com a foto de quem comentou.
$comentarios_por_video = [];
if (!empty($videos)) {
    $ids_videos = array_column($videos, "id");
    $marcadores_v = implode(",", array_fill(0, count($ids_videos), "?"));
    $comentarios_video_stmt = $pdo->prepare("
        SELECT comentarios_video.video_id, comentarios_video.conteudo, comentarios_video.criado_em,
            contas.id AS autor_id, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos
        FROM comentarios_video
        JOIN contas ON contas.id = comentarios_video.usuario_id
        WHERE comentarios_video.video_id IN ($marcadores_v)
        ORDER BY comentarios_video.criado_em ASC
    ");
    $comentarios_video_stmt->execute($ids_videos);
    foreach ($comentarios_video_stmt->fetchAll() as $com) {
        $comentarios_por_video[$com["video_id"]][] = $com;
    }
}

$pagina_ativa = "videos";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Feward: vídeos, clipes e conteúdos em comunidade.">
    <meta name="theme-color" content="#0b1050">
    <title>Vídeos - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .form-video { background: rgba(0,0,0,0.5); border-radius: 20px; padding: 20px 25px; margin-bottom: 25px; }
        .form-video .linha { display: flex; gap: 10px; margin-bottom: 10px; flex-wrap: wrap; }
        .form-video input[type=text], .form-video select { flex: 1; min-width: 150px; }
        .form-video .ou { text-align: center; color: #aaa; font-size: 13px; margin: 8px 0; }
        .form-video small { display:block; color:#aaa; margin-top:6px; }
        .grade-videos { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
        .card-video { background: #111; border-radius: 15px; overflow: hidden; }
        .card-video video, .card-video iframe { width: 100%; aspect-ratio: 16 / 9; display: block; border: none; background:#000; }
        .card-video-info { padding: 12px 15px; }
        .card-video-info .selo { display: inline-block; background: #2844e2; color: white; font-size: 11px; padding: 2px 8px; border-radius: 8px; margin-bottom: 6px; }
        .card-video-info .autor-linha { display: flex; align-items: center; gap: 8px; color: #aaa; font-size: 12px; text-decoration: none; }
        .card-video-info .autor-linha:hover { color: #4bbae6; }
        .avatar-mini { width: 24px; height: 24px; min-width: 24px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; font-size: 12px; }
        .video-comentarios { padding: 4px 15px 6px; display: flex; flex-direction: column; gap: 8px; border-top: 1px solid rgba(255,255,255,0.08); margin-top: 10px; }
        .video-comentario { display: flex; align-items: flex-start; gap: 8px; font-size: 13px; color: #ddd; }
        .video-comentario a { flex-shrink: 0; }
        .video-comentario strong { color: #fff; }
        .video-comentario-form { display: flex; padding: 10px 15px 15px; gap: 8px; align-items: center; }
        .video-comentario-form input[type=text] { border-radius: 15px; }
        .erro { color:#ff7777; }
        @media (max-width: 600px) {
            .form-video { padding: 16px; }
            .form-video .linha { flex-direction: column; }
            .form-video input[type=text], .form-video select { width:100%; box-sizing:border-box; }
            .grade-videos { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Vídeos</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <?php if ($erro): ?>
        <p class="erro"><?= htmlspecialchars($erro, ENT_QUOTES, "UTF-8") ?></p>
    <?php endif; ?>

    <div class="form-video">
        <form method="POST" enctype="multipart/form-data">
            <div class="linha">
                <input type="text" name="titulo" maxlength="150" placeholder="Título do vídeo" required>
                <select name="tipo">
                    <option value="curto">Curto</option>
                    <option value="longo">Longo</option>
                </select>
            </div>

            <div class="linha">
                <input type="file" name="arquivo" accept="video/mp4,video/webm,video/quicktime,video/x-matroska">
            </div>
            <small>Formatos aceitos: MP4, WEBM, MOV e MKV. O tamanho máximo depende da configuração do servidor.</small>

            <div class="ou">— ou —</div>

            <div class="linha">
                <input type="text" name="link_externo" placeholder="Link do YouTube">
            </div>

            <button class="acao" type="submit">Publicar</button>
        </form>
    </div>

    <div class="grade-videos">
        <?php foreach ($videos as $v): ?>
            <div class="card-video">
                <?php if (!empty($v["arquivo"])): ?>
                    <?php $video_src = "midia.php?pasta=videos&arquivo=" . urlencode($v["arquivo"]); ?>
                    <video src="<?= htmlspecialchars($video_src, ENT_QUOTES, "UTF-8") ?>" controls preload="metadata"></video>
                <?php elseif (!empty($v["link_externo"])): ?>
                    <iframe
                        src="<?= htmlspecialchars($v["link_externo"], ENT_QUOTES, "UTF-8") ?>"
                        title="<?= htmlspecialchars($v["titulo"], ENT_QUOTES, "UTF-8") ?>"
                        loading="lazy"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen>
                    </iframe>
                <?php endif; ?>

                <div class="card-video-info">
                    <span class="selo"><?= $v["tipo"] === "longo" ? "Longo" : "Curto" ?></span>
                    <div><strong><?= htmlspecialchars($v["titulo"], ENT_QUOTES, "UTF-8") ?></strong></div>
                    <a class="autor-linha" href="perfil-usuario.php?id=<?= (int) $v["usuario_id"] ?>">
                        <?php if (!empty($v["foto_perfil"])): ?>
                            <img class="avatar-mini" src="avatar.php?id=<?= (int) $v["usuario_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($v["foto_perfil_pos"] ?? "50% 50%", ENT_QUOTES, "UTF-8") ?>;">
                        <?php else: ?>
                            <span class="avatar-mini">👤</span>
                        <?php endif; ?>
                        por <?= htmlspecialchars($v["nome_usuario"], ENT_QUOTES, "UTF-8") ?>
                    </a>

                    <?php if ((int) $v["usuario_id"] === (int) $usuario_logado["id"]): ?>
                        <form method="POST" onsubmit="return confirm('Excluir este vídeo? Essa ação não pode ser desfeita.');" style="margin-top:10px;">
                            <input type="hidden" name="excluir_video_id" value="<?= $v["id"] ?>">
                            <button class="acao" type="submit" style="background-color:#b30000;">🗑️ Excluir</button>
                        </form>
                    <?php endif; ?>
                </div>

                <?php if (!empty($comentarios_por_video[$v["id"]])): ?>
                    <div class="video-comentarios">
                        <?php foreach ($comentarios_por_video[$v["id"]] as $com): ?>
                            <div class="video-comentario">
                                <a href="perfil-usuario.php?id=<?= (int) $com["autor_id"] ?>">
                                    <?php if (!empty($com["foto_perfil"])): ?>
                                        <img class="avatar-mini" src="avatar.php?id=<?= (int) $com["autor_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($com["foto_perfil_pos"] ?? "50% 50%", ENT_QUOTES, "UTF-8") ?>;">
                                    <?php else: ?>
                                        <span class="avatar-mini">👤</span>
                                    <?php endif; ?>
                                </a>
                                <div>
                                    <a href="perfil-usuario.php?id=<?= (int) $com["autor_id"] ?>" style="color:inherit;">
                                        <strong><?= htmlspecialchars($com["nome_usuario"], ENT_QUOTES, "UTF-8") ?></strong>
                                    </a>
                                    <?= htmlspecialchars($com["conteudo"], ENT_QUOTES, "UTF-8") ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form class="video-comentario-form" method="POST">
                    <input type="hidden" name="comentario_video_id" value="<?= $v["id"] ?>">
                    <input type="text" name="comentario_texto" placeholder="Comentário" required>
                    <button class="acao" type="submit">➤</button>
                </form>
            </div>
        <?php endforeach; ?>

        <?php if (empty($videos)): ?>
            <p>Nenhum vídeo publicado ainda.</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
