<?php
require_once "auth.php";

// Marca as notificações como vistas (zera o contador no menu lateral)
$_SESSION["notif_vistas_em"] = date("Y-m-d H:i:s");

// Limpa apenas a lista de notificações deste usuário, sem apagar comentários ou mensagens do banco.
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["limpar_notificacoes"])) {
    $_SESSION["notificacoes_limpas_em"] = date("Y-m-d H:i:s");
    header("Location: notificacao.php");
    exit;
}

// aceitar um pedido de seguir
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["aceitar_amizade_id"])) {
    $amizade_id = (int) $_POST["aceitar_amizade_id"];
    $stmt = $pdo->prepare("UPDATE amizades SET status = 'aceito' WHERE id = ? AND amigo_id = ?");
    $stmt->execute([$amizade_id, $usuario_logado["id"]]);
    $pdo->prepare("UPDATE notificacoes_seguir SET vista = 1 WHERE amizade_id = ?")->execute([$amizade_id]);
    header("Location: notificacao.php");
    exit;
}

// recusar um pedido de seguir
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["recusar_amizade_id"])) {
    $amizade_id = (int) $_POST["recusar_amizade_id"];
    // A notificação possui uma FK para a amizade. Removemos a notificação
    // primeiro para que o pedido possa ser excluído sem erro de FK.
    $pdo->prepare("DELETE FROM notificacoes_seguir WHERE amizade_id = ?")->execute([$amizade_id]);
    $stmt = $pdo->prepare("DELETE FROM amizades WHERE id = ? AND amigo_id = ?");
    $stmt->execute([$amizade_id, $usuario_logado["id"]]);
    header("Location: notificacao.php");
    exit;
}

$limpas_em = $_SESSION["notificacoes_limpas_em"] ?? "1970-01-01 00:00:00";

$convites_grupo = $pdo->prepare("
    SELECT gc.id AS convite_id, gc.grupo_id, g.nome AS grupo_nome, c.nome_usuario AS convidante_nome, c.id AS convidante_id, c.foto_perfil
    FROM grupo_convites gc
    JOIN grupos g ON g.id=gc.grupo_id
    JOIN contas c ON c.id=gc.convidante_id
    WHERE gc.convidado_id=? AND gc.status='pendente'
    ORDER BY gc.criado_em DESC
    LIMIT 50
");
$convites_grupo->execute([$usuario_logado["id"]]);
$convites_grupo=$convites_grupo->fetchAll();

$pedidos_seguir = $pdo->prepare("
    SELECT amizades.id AS amizade_id, contas.id AS de_id, contas.nome_usuario, contas.foto_perfil, contas.foto_perfil_pos
    FROM amizades
    JOIN contas ON contas.id = amizades.usuario_id
    WHERE amizades.amigo_id = ? AND amizades.status = 'pendente'
    ORDER BY amizades.criado_em DESC
");
$pedidos_seguir->execute([$usuario_logado["id"]]);
$pedidos_seguir = $pedidos_seguir->fetchAll();

$notificacoes = $pdo->prepare("
    SELECT comentarios.conteudo, comentarios.criado_em, contas.nome_usuario
    FROM comentarios
    JOIN posts ON posts.id = comentarios.post_id
    JOIN contas ON contas.id = comentarios.usuario_id
    WHERE posts.usuario_id = ? AND comentarios.usuario_id != ? AND comentarios.criado_em > ?
    ORDER BY comentarios.criado_em DESC
    LIMIT 30
");
$notificacoes->execute([$usuario_logado["id"], $usuario_logado["id"], $limpas_em]);
$notificacoes = $notificacoes->fetchAll();

$msgs_recebidas = $pdo->prepare("
    SELECT mensagens.conteudo, mensagens.criado_em, mensagens.remetente_id, contas.nome_usuario
    FROM mensagens
    JOIN contas ON contas.id = mensagens.remetente_id
    WHERE mensagens.destinatario_id = ? AND mensagens.criado_em > ?
    ORDER BY mensagens.criado_em DESC
    LIMIT 30
");
$msgs_recebidas->execute([$usuario_logado["id"], $limpas_em]);
$msgs_recebidas = $msgs_recebidas->fetchAll();

$nao_lidas = $pdo->prepare("SELECT COUNT(*) FROM mensagens WHERE destinatario_id = ? AND lida = FALSE");
$nao_lidas->execute([$usuario_logado["id"]]);
$nao_lidas = $nao_lidas->fetchColumn();

$pagina_ativa = "notificacao";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Notificações do Feward.">
    <meta name="theme-color" content="#0b1050">
    <title>Notificações - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .notif-item { padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.15); }
        .pedido-item { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.15); flex-wrap: wrap; }
        .pedido-item .avatar-mini { width: 44px; height: 44px; min-width: 44px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; font-size: 20px; }
        .pedido-item .pedido-texto { flex: 1; min-width: 140px; }
        .pedido-item a.nome-link { color: inherit; text-decoration: none; }
        .pedido-item a.nome-link:hover { color: #4bbae6; }
        .pedido-acoes { display: flex; gap: 8px; }
        .pedido-acoes button { width: auto; padding: 8px 16px; }
        .btn-recusar { background-color: #333 !important; }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo">
    <div class="topo-pagina">
        <h1>Notificação</h1>
        <button class="btn-creditos" onclick="window.location.href='cretidos.php'">Créditos</button>
    </div>

    <div class="card-escuro">
        <h2 style="margin-top:0;">Convites para grupos<?php if (!empty($convites_grupo)): ?> <span style="background:#2844e2;color:white;padding:2px 8px;border-radius:10px;font-size:12px;"><?= count($convites_grupo) ?></span><?php endif; ?></h2>
        <?php foreach ($convites_grupo as $c): ?>
            <div class="pedido-item">
                <?php if (!empty($c["foto_perfil"])): ?><img class="avatar-mini" src="avatar.php?id=<?= (int)$c["convidante_id"] ?>" alt=""><?php else: ?><span class="avatar-mini">👤</span><?php endif; ?>
                <div class="pedido-texto"><strong><?= htmlspecialchars($c["convidante_nome"]) ?></strong> convidou você para o grupo <strong><?= htmlspecialchars($c["grupo_nome"]) ?></strong>.</div>
                <div class="pedido-acoes"><button type="button" onclick="responderConvite(<?= (int)$c["convite_id"] ?>,true)">Entrar</button><button type="button" class="btn-recusar" onclick="responderConvite(<?= (int)$c["convite_id"] ?>,false)">Recusar</button></div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($convites_grupo)): ?><p>Nenhum convite de grupo pendente.</p><?php endif; ?>
    </div>

    <div class="card-escuro">
        <h2 style="margin-top:0;">Pedidos para seguir você<?php if (!empty($pedidos_seguir)): ?> <span style="background:#2844e2;color:white;padding:2px 8px;border-radius:10px;font-size:12px;"><?= count($pedidos_seguir) ?></span><?php endif; ?></h2>
        <?php foreach ($pedidos_seguir as $p): ?>
            <div class="pedido-item">
                <a href="perfil-usuario.php?id=<?= (int) $p["de_id"] ?>">
                    <?php if (!empty($p["foto_perfil"])): ?>
                        <img class="avatar-mini" src="avatar.php?id=<?= (int) $p["de_id"] ?>" alt="" style="object-position: <?= htmlspecialchars($p["foto_perfil_pos"] ?? "50% 50%", ENT_QUOTES, "UTF-8") ?>;">
                    <?php else: ?>
                        <span class="avatar-mini">👤</span>
                    <?php endif; ?>
                </a>
                <div class="pedido-texto">
                    <a class="nome-link" href="perfil-usuario.php?id=<?= (int) $p["de_id"] ?>"><strong><?= htmlspecialchars($p["nome_usuario"], ENT_QUOTES, "UTF-8") ?></strong></a>
                    quer seguir você
                </div>
                <div class="pedido-acoes">
                    <form method="POST">
                        <input type="hidden" name="aceitar_amizade_id" value="<?= (int) $p["amizade_id"] ?>">
                        <button class="acao" type="submit" style="background-color:#2844e2;">Aceitar</button>
                    </form>
                    <form method="POST">
                        <input type="hidden" name="recusar_amizade_id" value="<?= (int) $p["amizade_id"] ?>">
                        <button class="acao btn-recusar" type="submit">Recusar</button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($pedidos_seguir)): ?>
            <p>Nenhum pedido para seguir você no momento.</p>
        <?php endif; ?>
    </div>

    <div class="card-escuro">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
            <h2 style="margin:0;">Mensagens recebidas<?php if ($nao_lidas > 0): ?> <span style="background:#ff3b3b;color:white;padding:2px 8px;border-radius:10px;font-size:12px;"><?= $nao_lidas ?> não lida(s)</span><?php endif; ?></h2>
            <form method="POST" onsubmit="return confirm('Limpar todas as notificações exibidas?');">
                <input type="hidden" name="limpar_notificacoes" value="1">
                <button class="acao" type="submit" style="width:auto;">🗑️ Limpar notificações</button>
            </form>
        </div>
        <?php foreach ($msgs_recebidas as $m): ?>
            <div class="notif-item">
                <strong><?= htmlspecialchars($m["nome_usuario"]) ?></strong> enviou: <?= preg_match('/^\[\[reel:\d+\]\]$/', trim($m["conteudo"] ?? "")) ? "um reel 🎬" : "\"" . htmlspecialchars($m["conteudo"]) . "\"" ?>
                <div style="color:#aaa;font-size:12px;"><?= date("d/m/Y H:i", strtotime($m["criado_em"])) ?></div>
                <a href="mensagem.php?com=<?= (int) $m["remetente_id"] ?>" style="color:#4bbae6;font-size:12px;">Responder →</a>
            </div>
        <?php endforeach; ?>
        <?php if (empty($msgs_recebidas)): ?>
            <p>Nenhuma mensagem por enquanto.</p>
        <?php endif; ?>

        <h2>Comentários nos seus posts</h2>
        <?php foreach ($notificacoes as $n): ?>
            <div class="notif-item">
                <strong><?= htmlspecialchars($n["nome_usuario"]) ?></strong> comentou: "<?= htmlspecialchars($n["conteudo"]) ?>"
                <div style="color:#aaa;font-size:12px;"><?= date("d/m/Y H:i", strtotime($n["criado_em"])) ?></div>
            </div>
        <?php endforeach; ?>
        <?php if (empty($notificacoes)): ?>
            <p>Nenhum comentário por enquanto.</p>
        <?php endif; ?>
    </div>
</div>


<script>
async function responderConvite(id,aceitar){
 const d=new URLSearchParams({acao:aceitar?'aceitar_convite':'recusar_convite',convite_id:id,grupo_id:'0'});
 try{const r=await fetch('grupo_api.php',{method:'POST',body:d}); const x=await r.json(); if(!x.ok) throw new Error(x.erro||'Erro'); if(aceitar && x.grupo_id) location.href='grupo.php?id='+x.grupo_id; else location.reload();}
 catch(e){alert(e.message);}
}
</script>
</body>
</html>
