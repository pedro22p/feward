<?php
// Checagem leve: só confirma que existe sessão, sem buscar a conta inteira
// (avatar.php é chamado várias vezes por página, uma vez por avatar exibido).
require_once "conexao.php";
session_start();

if (!isset($_SESSION["usuario_id"])) {
    http_response_code(404);
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : (int)$_SESSION['usuario_id'];

$stmt = $pdo->prepare("SELECT foto_perfil FROM contas WHERE id = ? LIMIT 1");
$stmt->execute([$id]);
$usuario = $stmt->fetch();

if (!$usuario || empty($usuario['foto_perfil'])) {
    http_response_code(404);
    exit;
}

$caminho = str_replace('\\', '/', trim($usuario['foto_perfil']));
$caminho = ltrim($caminho, '/');

// Aceita somente fotos dentro da pasta de perfis.
if (!preg_match('#^uploads/perfis/[A-Za-z0-9._-]+$#', $caminho)) {
    http_response_code(404);
    exit;
}

$arquivo = __DIR__ . '/' . $caminho;
if (!is_file($arquivo) || !is_readable($arquivo)) {
    http_response_code(404);
    exit;
}

$info = @getimagesize($arquivo);
if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) {
    http_response_code(404);
    exit;
}

header('Content-Type: ' . ($info['mime'] ?? 'application/octet-stream'));
header('Content-Length: ' . filesize($arquivo));
header('Cache-Control: public, max-age=86400');
readfile($arquivo);
exit;
