<?php
// Feward V38 - Reels: vídeos curtos verticais, um por vez, rolagem infinita.
// Usa a tabela videos (tipo = 'curto') + curtidas_video (reels.sql).
require_once "auth.php";
require_once "moderacao.php";

const REELS_MAX_SEGUNDOS = 60;

function ini_para_bytes($v) {
    $v = trim((string) $v);
    if ($v === "") return 0;
    $n = (float) $v;
    switch (strtolower(substr($v, -1))) {
        case "g": $n *= 1024;
        case "m": $n *= 1024;
        case "k": $n *= 1024;
    }
    return (int) $n;
}

$limites = array_filter([ini_para_bytes(ini_get("upload_max_filesize")), ini_para_bytes(ini_get("post_max_size"))]);
$limite_bytes = $limites ? min($limites) : 0;
$limite_texto = $limite_bytes ? round($limite_bytes / 1048576, 1) . " MB" : "o limite do servidor";

$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $legenda = trim($_POST["titulo"] ?? "");
    $arq = $_FILES["arquivo"] ?? null;

    if (empty($_POST) && empty($_FILES) && (int) ($_SERVER["CONTENT_LENGTH"] ?? 0) > 0) {
        $erro = "O vídeo passou do limite do servidor ($limite_texto). Aumente upload_max_filesize e post_max_size no php.ini.";
    } elseif ($legenda === "") {
        $erro = "Escreva uma legenda para o reel.";
    } elseif (mb_strlen($legenda) > 150) {
        $erro = "A legenda pode ter no máximo 150 caracteres.";
    } elseif (bloquearConteudo($legenda)) {
        $erro = "Legenda bloqueada por conter palavras proibidas.";
    } elseif (!$arq || ($arq["error"] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        $erro = "Escolha um vídeo.";
    } elseif ($arq["error"] === UPLOAD_ERR_INI_SIZE || $arq["error"] === UPLOAD_ERR_FORM_SIZE) {
        $erro = "O vídeo passou do limite do servidor ($limite_texto).";
    } elseif ($arq["error"] !== UPLOAD_ERR_OK || !is_uploaded_file($arq["tmp_name"])) {
        $erro = "O upload falhou. Tente de novo.";
    } else {
        $ext = strtolower(pathinfo($arq["name"], PATHINFO_EXTENSION));
        $mime = null;
        if (function_exists("finfo_open") && ($fi = finfo_open(FILEINFO_MIME_TYPE))) {
            $mime = finfo_file($fi, $arq["tmp_name"]);
            finfo_close($fi);
        }
        $mimes_ok = ["video/mp4", "video/webm", "video/quicktime", "video/x-matroska", "application/octet-stream"];

        if (!in_array($ext, ["mp4", "webm", "mov", "mkv"], true)) {
            $erro = "Envie um vídeo MP4, WEBM, MOV ou MKV.";
        } elseif ($mime !== null && !in_array($mime, $mimes_ok, true)) {
            $erro = "O arquivo não parece ser um vídeo válido.";
        } else {
            // Se o servidor tiver ffprobe, confere a duração de verdade.
            $duracao = null;
            if (function_exists("shell_exec") && !in_array("shell_exec", array_map("trim", explode(",", (string) ini_get("disable_functions"))), true)) {
                $saida = @shell_exec("ffprobe -v error -show_entries format=duration -of csv=p=0 " . escapeshellarg($arq["tmp_name"]) . " 2>/dev/null");
                if ($saida !== null && is_numeric(trim($saida))) $duracao = (float) trim($saida);
            }
            if ($duracao !== null && $duracao > REELS_MAX_SEGUNDOS + 1) {
                $erro = "Reels podem ter no máximo " . REELS_MAX_SEGUNDOS . " segundos.";
            } else {
                $pasta = __DIR__ . "/uploads/videos";
                if (!is_dir($pasta) && !@mkdir($pasta, 0755, true)) {
                    $erro = "Não foi possível criar a pasta de vídeos.";
                } elseif (!is_writable($pasta)) {
                    $erro = "A pasta uploads/videos não tem permissão de escrita.";
                } else {
                    $nome = "video_" . bin2hex(random_bytes(12)) . "." . $ext;
                    $destino = $pasta . DIRECTORY_SEPARATOR . $nome;
                    if (!move_uploaded_file($arq["tmp_name"], $destino)) {
                        $erro = "Não foi possível salvar o vídeo.";
                    } else {
                        try {
                            $pdo->prepare("INSERT INTO videos (usuario_id, titulo, tipo, arquivo) VALUES (?, ?, 'curto', ?)")
                                ->execute([(int) $usuario_logado["id"], $legenda, $nome]);
                            header("Location: reels.php?id=" . (int) $pdo->lastInsertId());
                            exit;
                        } catch (PDOException $e) {
                            @unlink($destino);
                            $erro = "Não foi possível registrar o reel no banco.";
                        }
                    }
                }
            }
        }
    }
}

$pagina_ativa = "reels";
$id_inicial = (int) ($_GET["id"] ?? 0);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="#000000">
    <title>Reels - Feward</title>
    <link rel="icon" href="img/logo.png" type="image/png">
    <link rel="stylesheet" href="estilo.css">
    <style>
        .conteudo.reels-pagina { padding: 0; display: flex; justify-content: center; background: #000; }
        .reels-coluna { position: relative; width: 100%; max-width: 460px; height: 100vh; height: 100dvh; background: #000; }
        .reels-feed { height: 100%; overflow-y: scroll; scroll-snap-type: y mandatory; scrollbar-width: none; overscroll-behavior: contain; }
        .reels-feed::-webkit-scrollbar { display: none; }
        .reel { position: relative; height: 100%; scroll-snap-align: start; scroll-snap-stop: always; background: #000; overflow: hidden; }
        .reel video { width: 100%; height: 100%; object-fit: contain; background: #000; display: block; }
        .reel video.cheio { object-fit: cover; }
        .reel-sombra { position: absolute; left: 0; right: 0; bottom: 0; height: 40%; background: linear-gradient(transparent, rgba(0,0,0,.75)); pointer-events: none; }
        .reel-info { position: absolute; left: 14px; right: 80px; bottom: 22px; pointer-events: none; text-shadow: 0 1px 4px #000; }
        .reel-info a, .reel-info .legenda { pointer-events: auto; }
        .reel-autor { display: inline-flex; align-items: center; gap: 8px; font-weight: bold; margin-bottom: 8px; }
        .reel-info .legenda { font-size: 14px; line-height: 1.35; word-break: break-word; }
        .avatar-reel { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; background: #3a3d63; display: inline-flex; align-items: center; justify-content: center; border: 2px solid #fff; flex-shrink: 0; }
        .reel-acoes { position: absolute; right: 10px; bottom: 28px; display: flex; flex-direction: column; align-items: center; gap: 18px; }
        .reel-acoes button { background: rgba(0,0,0,.45); border: 0; color: #fff; width: 48px; height: 48px; border-radius: 50%; font-size: 22px; cursor: pointer; display: flex; align-items: center; justify-content: center; -webkit-tap-highlight-color: transparent; }
        .reel-acoes button.curtido { color: #ff3b5c; }
        .reel-acoes .n { display: block; font-size: 12px; text-align: center; margin-top: 3px; text-shadow: 0 1px 3px #000; }
        .reel-pause { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; font-size: 64px; opacity: 0; pointer-events: none; transition: opacity .15s; text-shadow: 0 2px 10px #000; }
        .reel-pause.mostra { opacity: .9; }
        .reel-barra { position: absolute; left: 0; bottom: 0; height: 3px; width: 0; background: #fff; }
        .reels-topo { position: absolute; z-index: 5; top: 0; left: 0; right: 0; display: flex; justify-content: space-between; align-items: center; padding: 14px; background: linear-gradient(rgba(0,0,0,.6), transparent); pointer-events: none; }
        .reels-topo h1 { margin: 0; font-size: 20px; }
        .reels-topo button { pointer-events: auto; background: rgba(255,255,255,.18); color: #fff; border: 0; border-radius: 18px; padding: 8px 14px; font-size: 14px; cursor: pointer; }
        .reels-topo .som { margin-right: 8px; }
        .reels-vazio, .reels-carregando { height: 100%; display: flex; align-items: center; justify-content: center; text-align: center; color: #bbb; padding: 30px; scroll-snap-align: start; }
        .painel-fundo { position: absolute; inset: 0; z-index: 20; background: rgba(0,0,0,.5); display: none; }
        .painel-fundo.aberto { display: block; }
        .painel { position: absolute; left: 0; right: 0; bottom: 0; max-height: 72%; display: flex; flex-direction: column; background: #15162b; border-radius: 18px 18px 0 0; padding: 14px; }
        .painel-cab { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; font-weight: bold; }
        .painel-cab button { background: none; border: 0; color: #fff; font-size: 24px; cursor: pointer; }
        .painel-lista { overflow-y: auto; flex: 1; min-height: 120px; display: flex; flex-direction: column; gap: 10px; }
        .coment { display: flex; gap: 8px; font-size: 14px; word-break: break-word; }
        .coment strong { color: #fff; }
        .painel-form { display: flex; gap: 8px; margin-top: 10px; }
        .painel-form input { flex: 1; border-radius: 18px; border: 0; padding: 10px 14px; background: #272a4d; color: #fff; }
        .painel-form button { border: 0; border-radius: 18px; padding: 0 16px; background: #2844e2; color: #fff; cursor: pointer; }
        .share-lista { overflow-y: auto; flex: 1; min-height: 80px; max-height: 38vh; display: flex; flex-direction: column; gap: 4px; margin-top: 10px; }
        .share-pessoa { display: flex; align-items: center; gap: 10px; padding: 8px; border-radius: 12px; background: none; border: 0; color: #fff; cursor: pointer; text-align: left; font-size: 15px; }
        .share-pessoa:hover { background: #272a4d; }
        .share-pessoa .ok { margin-left: auto; color: #6fe38a; font-size: 13px; }
        .share-topo { display: flex; gap: 8px; flex-wrap: wrap; }
        .share-topo button { background: #272a4d; border: 0; color: #fff; border-radius: 14px; padding: 10px 14px; cursor: pointer; font-size: 14px; }
        .modal-novo { position: fixed; inset: 0; z-index: 3000; background: rgba(0,0,0,.7); display: none; align-items: center; justify-content: center; padding: 16px; }
        .modal-novo.aberto { display: flex; }
        .modal-novo form { background: #15162b; border-radius: 18px; padding: 20px; width: 100%; max-width: 400px; display: flex; flex-direction: column; gap: 10px; }
        .modal-novo input[type=text] { border-radius: 12px; border: 0; padding: 10px 12px; background: #272a4d; color: #fff; }
        .modal-novo small { color: #aaa; }
        .modal-novo .linha-bt { display: flex; gap: 8px; justify-content: flex-end; }
        .modal-novo button { border: 0; border-radius: 12px; padding: 10px 16px; cursor: pointer; color: #fff; background: #2844e2; }
        .modal-novo button.sec { background: #3a3d63; }
        .msg-erro { color: #ff7777; font-size: 14px; margin: 0; }
        @media (max-width: 768px) {
            body { padding-bottom: 0; }
            .reels-coluna { max-width: none; height: calc(100dvh - 76px); }
            .reel-acoes { bottom: 22px; }
        }
    </style>
</head>
<body>

<?php include "nav.php"; ?>

<div class="conteudo reels-pagina">
  <div class="reels-coluna" id="coluna">
    <div class="reels-topo">
        <h1>Reels</h1>
        <div>
            <button class="som" id="btn-som" type="button" aria-label="Som">🔇</button>
            <button type="button" id="btn-novo">＋ Novo reel</button>
        </div>
    </div>

    <?php if ($erro): ?><p class="msg-erro" style="position:absolute;z-index:6;top:58px;left:14px;right:14px;background:rgba(0,0,0,.7);padding:8px 12px;border-radius:10px;"><?= htmlspecialchars($erro, ENT_QUOTES, "UTF-8") ?></p><?php endif; ?>

    <div class="reels-feed" id="feed"><div class="reels-carregando" id="carregando">Carregando reels…</div></div>

    <div class="painel-fundo" id="share-fundo">
        <div class="painel">
            <div class="painel-cab"><span>Compartilhar reel</span><button type="button" id="share-fechar" aria-label="Fechar">×</button></div>
            <div style="margin-top:4px;font-size:14px;color:#bbb;">Enviar para quem você segue:</div>
            <div class="share-lista" id="share-lista"></div>
            <div id="share-aviso" style="font-size:13px;color:#aaa;min-height:18px;margin-top:6px;"></div>
        </div>
    </div>

    <div class="painel-fundo" id="painel-fundo">
        <div class="painel">
            <div class="painel-cab"><span>Comentários</span><button type="button" id="painel-fechar" aria-label="Fechar">×</button></div>
            <div class="painel-lista" id="painel-lista"></div>
            <form class="painel-form" id="painel-form">
                <input type="text" id="painel-texto" maxlength="500" placeholder="Adicione um comentário…" autocomplete="off">
                <button type="submit">➤</button>
            </form>
        </div>
    </div>
  </div>
</div>

<div class="modal-novo<?= $erro ? " aberto" : "" ?>" id="modal-novo">
    <form method="POST" enctype="multipart/form-data" id="form-novo">
        <strong>Novo reel</strong>
        <input type="text" name="titulo" maxlength="150" placeholder="Legenda" required>
        <input type="file" name="arquivo" id="arq-reel" accept="video/mp4,video/webm,video/quicktime,video/x-matroska" required>
        <small>Até <?= REELS_MAX_SEGUNDOS ?>s, melhor em pé (vertical). MP4, WEBM, MOV ou MKV. Tamanho máximo: <?= htmlspecialchars($limite_texto) ?>.</small>
        <p class="msg-erro" id="erro-novo"></p>
        <div class="linha-bt">
            <button type="button" class="sec" id="cancelar-novo">Cancelar</button>
            <button type="submit" id="publicar-novo">Publicar</button>
        </div>
    </form>
</div>

<script>
(function () {
    const MAX_SEG = <?= REELS_MAX_SEGUNDOS ?>;
    const INICIAL = <?= $id_inicial ?>;
    const feed = document.getElementById("feed");
    const coluna = document.getElementById("coluna");
    let ultimoId = 0, fim = false, carregando = false, mudo = true, ativo = null;
    const reels = []; // {el, video, dados}

    function el(tag, cls, txt) { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
    function avatar(id, temFoto, pos, cls) {
        if (temFoto) { const i = el("img", cls); i.src = "avatar.php?id=" + id; i.alt = ""; i.style.objectPosition = pos; return i; }
        return el("span", cls, "👤");
    }
    async function api(acao, dados) {
        const opt = dados ? { method: "POST", body: new URLSearchParams(Object.assign({ acao }, dados)) } : {};
        const url = "reels_api.php?acao=" + acao + (dados ? "" : (opt.q || ""));
        const r = await fetch(dados ? "reels_api.php" : url, opt);
        let j; try { j = await r.json(); } catch (e) { window.location.href = "login.php"; throw e; }
        if (!r.ok) throw new Error(j.erro || "Erro");
        return j;
    }

    // ---------- montar um reel ----------
    function montar(d) {
        const reel = el("div", "reel"); reel.dataset.id = d.id;
        const video = el("video");
        video.loop = true; video.muted = mudo; video.playsInline = true; video.preload = "none";
        video.setAttribute("playsinline", ""); video.setAttribute("webkit-playsinline", "");
        video.addEventListener("loadedmetadata", () => { if (video.videoHeight > video.videoWidth * 1.2) video.classList.add("cheio"); });
        reel.appendChild(video);
        reel.appendChild(el("div", "reel-sombra"));
        const pausa = el("div", "reel-pause", "▶"); reel.appendChild(pausa);
        const barra = el("div", "reel-barra"); reel.appendChild(barra);
        video.addEventListener("timeupdate", () => { if (video.duration) barra.style.width = (video.currentTime / video.duration * 100) + "%"; });
        reel.addEventListener("click", (e) => {
            if (e.target.closest("button, a")) return;
            if (video.paused) { video.play().catch(() => {}); pausa.classList.remove("mostra"); }
            else { video.pause(); pausa.classList.add("mostra"); }
        });

        const info = el("div", "reel-info");
        const a = el("a", "reel-autor"); a.href = "perfil-usuario.php?id=" + d.autor_id;
        a.appendChild(avatar(d.autor_id, d.tem_foto, d.foto_pos, "avatar-reel"));
        a.appendChild(el("span", null, d.autor));
        info.appendChild(a); info.appendChild(el("div", "legenda", d.titulo));
        reel.appendChild(info);

        const acoes = el("div", "reel-acoes");
        const bLike = el("button", d.curti ? "curtido" : "", d.curti ? "♥" : "♡");
        const nLike = el("span", "n", d.curtidas);
        const wLike = el("div"); wLike.append(bLike, nLike);
        bLike.addEventListener("click", async () => {
            try { const r = await api("curtir", { video_id: d.id });
                d.curti = r.curti; d.curtidas = r.curtidas;
                bLike.textContent = r.curti ? "♥" : "♡"; bLike.classList.toggle("curtido", r.curti); nLike.textContent = r.curtidas;
            } catch (e) { alert(e.message); }
        });
        const bCom = el("button", "", "💬");
        const nCom = el("span", "n", d.comentarios);
        const wCom = el("div"); wCom.append(bCom, nCom);
        bCom.addEventListener("click", () => abrirComentarios(d, nCom));
        const bShare = el("button", "", "↗");
        bShare.setAttribute("aria-label", "Compartilhar");
        bShare.addEventListener("click", () => abrirCompartilhar(d));
        const wShare = el("div"); wShare.append(bShare, el("span", "n", "Enviar"));
        acoes.append(wLike, wCom, wShare);
        if (d.meu) {
            const bDel = el("button", "", "🗑️");
            bDel.addEventListener("click", async () => {
                if (!confirm("Excluir este reel? Essa ação não pode ser desfeita.")) return;
                try { await api("excluir", { video_id: d.id }); remover(reel); } catch (e) { alert(e.message); }
            });
            acoes.appendChild(bDel);
        }
        reel.appendChild(acoes);
        return { el: reel, video, d };
    }

    function remover(reelEl) {
        const i = reels.findIndex(r => r.el === reelEl);
        if (i >= 0) { reels[i].video.pause(); reels.splice(i, 1); }
        reelEl.remove();
        if (!reels.length) mostrarVazio();
    }
    function mostrarVazio() {
        if (feed.querySelector(".reels-vazio")) return;
        const v = el("div", "reels-vazio", "Nenhum reel ainda. Seja o primeiro: toque em “＋ Novo reel”.");
        feed.appendChild(v);
    }

    // ---------- carregar ----------
    async function carregar() {
        if (carregando || fim) return;
        carregando = true;
        try {
            let url = "reels_api.php?acao=lista";
            if (ultimoId) url += "&depois=" + ultimoId; else if (INICIAL) url += "&inicial=" + INICIAL;
            const r = await (await fetch(url)).json().catch(() => { window.location.href = "login.php"; });
            if (!r) return;
            if (r.erro) { document.getElementById("carregando").textContent = r.erro; return; }
            const c = document.getElementById("carregando"); if (c) c.remove();
            r.itens.forEach(d => { const m = montar(d); reels.push(m); feed.appendChild(m.el); obs.observe(m.el); ultimoId = d.id; });
            fim = r.fim;
            if (!reels.length) mostrarVazio();
        } finally { carregando = false; }
    }

    // ---------- autoplay do reel visível ----------
    function ativar(reelObj) {
        reels.forEach((r, i) => {
            const perto = reelObj && Math.abs(i - reels.indexOf(reelObj)) <= 1;
            if (r === reelObj) {
                if (!r.video.src) r.video.src = r.d.src;
                r.video.muted = mudo;
                r.video.play().catch(() => {});
            } else {
                r.video.pause();
                if (r.video.currentTime > 0.1 && r !== reelObj) r.video.currentTime = 0;
                if (perto) { if (!r.video.src) { r.video.preload = "metadata"; r.video.src = r.d.src; } }
                else if (r.video.getAttribute("src")) { r.video.removeAttribute("src"); r.video.load(); }
            }
            const p = r.el.querySelector(".reel-pause"); if (p) p.classList.remove("mostra");
        });
        ativo = reelObj;
        if (reelObj && reels.indexOf(reelObj) >= reels.length - 2) carregar();
    }
    const obs = new IntersectionObserver((entradas) => {
        entradas.forEach(en => { if (en.isIntersecting && en.intersectionRatio >= 0.6) { const o = reels.find(r => r.el === en.target); if (o && o !== ativo) ativar(o); } });
    }, { root: feed, threshold: [0.6] });

    document.addEventListener("visibilitychange", () => { if (document.hidden && ativo) ativo.video.pause(); else if (ativo) ativo.video.play().catch(() => {}); });

    // teclado (PC)
    document.addEventListener("keydown", (e) => {
        if (/INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
        if (e.key === "ArrowDown") { feed.scrollBy({ top: feed.clientHeight, behavior: "smooth" }); e.preventDefault(); }
        if (e.key === "ArrowUp") { feed.scrollBy({ top: -feed.clientHeight, behavior: "smooth" }); e.preventDefault(); }
    });

    // som
    const btnSom = document.getElementById("btn-som");
    btnSom.addEventListener("click", () => { mudo = !mudo; btnSom.textContent = mudo ? "🔇" : "🔊"; reels.forEach(r => r.video.muted = mudo); });

    // ---------- comentários ----------
    const fundo = document.getElementById("painel-fundo"), lista = document.getElementById("painel-lista");
    const form = document.getElementById("painel-form"), texto = document.getElementById("painel-texto");
    let videoAberto = null, contadorAberto = null;
    async function abrirComentarios(d, nEl) {
        videoAberto = d; contadorAberto = nEl;
        lista.replaceChildren(el("div", "", "Carregando…")); fundo.classList.add("aberto");
        try {
            const r = await (await fetch("reels_api.php?acao=comentarios&video_id=" + d.id)).json();
            lista.replaceChildren();
            if (!r.comentarios.length) lista.appendChild(el("div", "", "Seja o primeiro a comentar."));
            r.comentarios.forEach(c => lista.appendChild(linhaComentario(c)));
        } catch (e) { lista.replaceChildren(el("div", "", "Não foi possível carregar.")); }
    }
    function linhaComentario(c) {
        const l = el("div", "coment");
        const a = el("a"); a.href = "perfil-usuario.php?id=" + c.autor_id; a.appendChild(avatar(c.autor_id, c.tem_foto, c.foto_pos, "avatar-reel"));
        a.firstChild.style.width = a.firstChild.style.height = "28px"; a.firstChild.style.border = "0";
        const t = el("div"); t.append(el("strong", "", c.autor + " "), document.createTextNode(c.texto));
        l.append(a, t); return l;
    }
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const t = texto.value.trim(); if (!t || !videoAberto) return;
        try {
            const r = await api("comentar", { video_id: videoAberto.id, texto: t });
            texto.value = ""; videoAberto.comentarios = r.comentarios; contadorAberto.textContent = r.comentarios;
            abrirComentarios(videoAberto, contadorAberto);
        } catch (err) { alert(err.message); }
    });
    document.getElementById("painel-fechar").addEventListener("click", () => fundo.classList.remove("aberto"));
    fundo.addEventListener("click", (e) => { if (e.target === fundo) fundo.classList.remove("aberto"); });

    // ---------- compartilhar ----------
    const shareFundo = document.getElementById("share-fundo"), shareLista = document.getElementById("share-lista"), shareAviso = document.getElementById("share-aviso");
    let shareReel = null, pessoasCache = null;
    function textoDoReel(d) { return "[[reel:" + d.id + "]]"; } // vira um cartão do reel na conversa
    async function abrirCompartilhar(d) {
        shareReel = d; shareAviso.textContent = ""; shareFundo.classList.add("aberto");
        if (!pessoasCache) {
            shareLista.replaceChildren(el("div", "", "Carregando…"));
            try { pessoasCache = (await (await fetch("reels_api.php?acao=seguidos")).json()).pessoas || []; }
            catch (e) { shareLista.replaceChildren(el("div", "", "Não foi possível carregar.")); return; }
        }
        shareLista.replaceChildren();
        if (!pessoasCache.length) { shareLista.appendChild(el("div", "", "Você ainda não segue ninguém. Siga alguém para enviar mensagens.")); return; }
        pessoasCache.forEach(p => {
            const b = el("button", "share-pessoa"); b.type = "button";
            b.appendChild(avatar(p.id, p.tem_foto, p.foto_pos, "avatar-reel")); b.appendChild(el("span", "", p.nome));
            b.addEventListener("click", async () => {
                if (b.dataset.enviado) return;
                try {
                    const r = await fetch("mensagem_api.php", { method: "POST", body: new URLSearchParams({ acao: "enviar", destinatario_id: p.id, conteudo: textoDoReel(shareReel) }) });
                    const j = await r.json();
                    if (!r.ok) throw new Error(j.erro || "Erro ao enviar");
                    b.dataset.enviado = "1"; b.appendChild(el("span", "ok", "✓ Enviado"));
                } catch (e) { shareAviso.textContent = e.message; }
            });
            shareLista.appendChild(b);
        });
    }
    document.getElementById("share-fechar").addEventListener("click", () => shareFundo.classList.remove("aberto"));
    shareFundo.addEventListener("click", (e) => { if (e.target === shareFundo) shareFundo.classList.remove("aberto"); });

    // ---------- novo reel ----------
    const modal = document.getElementById("modal-novo"), arq = document.getElementById("arq-reel"), erroNovo = document.getElementById("erro-novo");
    document.getElementById("btn-novo").addEventListener("click", () => modal.classList.add("aberto"));
    document.getElementById("cancelar-novo").addEventListener("click", () => { modal.classList.remove("aberto"); erroNovo.textContent = ""; });
    document.getElementById("form-novo").addEventListener("submit", (e) => {
        const f = arq.files[0]; if (!f) return;
        if (arq.dataset.ok === "1") { document.getElementById("publicar-novo").disabled = true; document.getElementById("publicar-novo").textContent = "Enviando…"; return; }
        e.preventDefault(); erroNovo.textContent = "Verificando vídeo…";
        const v = document.createElement("video"); v.preload = "metadata"; const url = URL.createObjectURL(f);
        const liberar = () => { URL.revokeObjectURL(url); };
        v.onloadedmetadata = () => {
            liberar();
            if (v.duration > MAX_SEG + 1) { erroNovo.textContent = "Reels podem ter no máximo " + MAX_SEG + " segundos."; return; }
            arq.dataset.ok = "1"; e.target.requestSubmit();
        };
        // formatos que o navegador não lê (ex.: MKV): deixa o servidor validar
        v.onerror = () => { liberar(); arq.dataset.ok = "1"; e.target.requestSubmit(); };
        v.src = url;
    });
    arq.addEventListener("change", () => { arq.dataset.ok = ""; erroNovo.textContent = ""; });

    carregar();
})();
</script>
</body>
</html>
