// Ampliar postagem ao clicar (lightbox)
function abrirLightbox(src) {
    var overlay = document.getElementById("lightbox-overlay");
    var img = document.getElementById("lightbox-img");
    if (!overlay || !img) return;
    img.src = src;
    overlay.classList.add("aberto");
}

function fecharLightbox() {
    var overlay = document.getElementById("lightbox-overlay");
    var img = document.getElementById("lightbox-img");
    if (!overlay) return;
    overlay.classList.remove("aberto");
    if (img) img.src = "";
}

document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") fecharLightbox();
});

// Escolher onde a foto de perfil vai mostrar (posição dentro do círculo)
function atualizarPosicaoFoto() {
    var posX = document.getElementById("pos_x");
    var posY = document.getElementById("pos_y");
    var preview = document.getElementById("posicao-preview");
    if (!posX || !posY || !preview) return;
    preview.style.objectPosition = posX.value + "% " + posY.value + "%";
}
