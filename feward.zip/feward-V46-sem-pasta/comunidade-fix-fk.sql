ALTER TABLE posts MODIFY COLUMN comunidade_id INT NULL;
ALTER TABLE posts ADD CONSTRAINT fk_posts_comunidade FOREIGN KEY (comunidade_id) REFERENCES comunidades(id) ON DELETE CASCADE;
ALTER TABLE posts ADD KEY idx_posts_comunidade (comunidade_id, criado_em);
